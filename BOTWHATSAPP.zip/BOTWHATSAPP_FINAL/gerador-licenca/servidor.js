#!/usr/bin/env node
/**
 * ============================================
 *  🔑 SERVIDOR DO GERADOR DE LICENÇAS
 *  Abre a interface web no navegador
 * ============================================
 * 
 * USO: node servidor.js
 * Acesse: http://localhost:3001
 * 
 * CORREÇÃO: Agora a geração de licença é feita server-side
 * usando Node.js crypto.scryptSync (mesmo algoritmo do validador).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = 3001;

// ─── MESMA CHAVE SECRETA DO MÓDULO DE LICENÇA DO BOT ───────────
const SECRET_KEY = 'FFB@2024#S3cR3t!K3y$LiC3nS3';
const CIPHER_ALGO = 'aes-256-cbc';

function derivarChave(whid) {
  return crypto.scryptSync(SECRET_KEY + whid, 'fastfood-bot-salt', 32);
}

function gerarContraChaveEsperada(whid) {
  const hash = crypto.createHmac('sha256', SECRET_KEY)
    .update(whid)
    .update('CONTRA-CHAVE')
    .digest('hex');
  return hash.substring(0, 8).toUpperCase();
}

function gerarLicenca(whid, contraChave, dataExpiracao) {
  // Validar WHID
  const whidRegex = /^[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$/;
  if (!whidRegex.test(whid.toUpperCase())) {
    throw new Error('WHID inválido. Formato esperado: XXXX-XXXX-XXXX-XXXX (hexadecimal)');
  }
  whid = whid.toUpperCase();

  // Validar contra-chave
  const contraChaveEsperada = gerarContraChaveEsperada(whid);
  if (contraChave.toUpperCase() !== contraChaveEsperada) {
    throw new Error(`Contra-chave inválida para este WHID!\nEsperada: ${contraChaveEsperada}\nRecebida: ${contraChave.toUpperCase()}`);
  }

  // Validar data
  const expira = new Date(dataExpiracao + 'T23:59:59');
  if (isNaN(expira.getTime())) {
    throw new Error('Data inválida. Use o formato AAAA-MM-DD');
  }

  const agora = new Date();
  if (expira <= agora) {
    throw new Error('A data de expiração deve ser no futuro!');
  }

  // Montar payload
  const payload = JSON.stringify({
    whid: whid,
    contraChave: contraChave.toUpperCase(),
    expiraEm: expira.toISOString(),
    criadoEm: agora.toISOString(),
    versao: '1.0',
  });

  // Criptografar usando scrypt (mesmo do license.js)
  const key = derivarChave(whid);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(CIPHER_ALGO, key, iv);
  let encrypted = cipher.update(payload, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const licenseKey = `${iv.toString('hex')}:${encrypted}`;

  const diffMs = expira - agora;
  const dias = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  return {
    licenca: licenseKey,
    whid,
    expiraEm: dataExpiracao,
    diasValidade: dias,
  };
}

const server = http.createServer((req, res) => {
  // API para gerar licença (server-side com scrypt)
  if (req.method === 'POST' && req.url === '/api/gerar-licenca') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { whid, contraChave, dataExpiracao } = JSON.parse(body);
        const resultado = gerarLicenca(whid, contraChave, dataExpiracao);
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ sucesso: true, ...resultado }));
      } catch (err) {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ sucesso: false, erro: err.message }));
      }
    });
    return;
  }

  // Servir página HTML
  const filePath = path.join(__dirname, 'index.html');
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500);
      res.end('Erro ao carregar a página');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║   🔑 GERADOR DE LICENÇAS - Fast Food Bot    ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║   Acesse: http://localhost:${PORT}              ║`);
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');
});
