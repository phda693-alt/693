/**
 * ============================================================
 *  GÍRIAS E FALAS POPULARES DO CEARÁ  🌵
 * ============================================================
 * Módulo central para humanizar o atendimento da "Lara" com o
 * jeito cearense de falar. É usado em 3 lugares:
 *
 *   1. restauranteContext.js  → ensina a IA externa a ENTENDER
 *      e RESPONDER usando o linguajar do Ceará (persona + glossário).
 *   2. motorLocal.js          → o motor de fallback também entende
 *      as gírias (afirmações, negações, saudações...) e responde
 *      com um toque cearense.
 *   3. audioHandler.js        → corrige transcrições de áudio que
 *      costumam "errar" a grafia de palavras regionais.
 *
 * FILOSOFIA:
 *   Regionalismo com MODERAÇÃO. A Lara é uma cearense simpática,
 *   não uma caricatura. No máximo uma expressão por mensagem,
 *   sempre mantendo clareza e respeito com o cliente.
 * ============================================================
 */

// ─── GLOSSÁRIO DE GÍRIAS / EXPRESSÕES DO CEARÁ ───────────────
// Cada entrada: { termos: [variações], significado, tipo }
// tipo: 'afirmacao' | 'negacao' | 'saudacao' | 'agradece' |
//       'expressao' | 'pedir' | 'elogio' | 'despedida'
const GLOSSARIO = [
  // Afirmações / concordância
  { termos: ['arriba', 'bora', 'partiu', 'demorou', 'fechou negócio', 'fechou negocio', 'pode caçar', 'pode caça', 'manda ver', 'manda brasa', 'pode crer', 'com certeza absoluta', 'aí sim', 'ai sim', 'isso aí mermo', 'isso ai mermo', 'tá certo', 'ta certo', 'tá bom demais', 'positivo'], significado: 'sim, concordo / pode fazer', tipo: 'afirmacao' },

  // Negações / recusa
  { termos: ['capaz', 'vôte', 'vote', 'nem morto', 'de jeito nenhum', 'cruz credo', 'arre égua não', 'arre egua nao'], significado: 'não / de jeito nenhum', tipo: 'negacao' },

  // Saudações / chamamento
  { termos: ['e aí meu rei', 'e ai meu rei', 'e aí minha rainha', 'e ai minha rainha', 'meu rei', 'minha rainha', 'cabra', 'cumpade', 'compade', 'macho', 'mah', 'ei mah', 'bão', 'e a boa', 'salve'], significado: 'saudação/chamamento amigável', tipo: 'saudacao' },

  // Expressões de surpresa / espanto / ênfase
  { termos: ['oxe', 'oxente', 'eita', 'eita égua', 'eita egua', 'arre égua', 'arre egua', 'égua', 'egua', 'vixe', 'vixe maria', 'creindeus', 'valha', 'diabo é isso', 'rapaz'], significado: 'surpresa/espanto/ênfase', tipo: 'expressao' },

  // Pedir algo (equivalente a "me traz / me dá")
  { termos: ['me arruma', 'arruma aí', 'arruma ai', 'me alembra', 'me abança', 'me vê', 'me ve', 'bota aí', 'bota ai', 'manda um'], significado: 'me traga / quero pedir', tipo: 'pedir' },

  // Elogios (comida boa / algo bom)
  { termos: ['arretado', 'arretada', 'massa demais', 'top demais', 'show de bola', 'cabuloso', 'danado de bom', 'da peste', 'do balaco baco', 'brabo', 'brabo demais', 'é sinistro'], significado: 'muito bom / excelente', tipo: 'elogio' },

  // Estados / sentimentos comuns
  { termos: ['tô aperreado', 'to aperreado', 'aperreio', 'avexado', 'tô avexado', 'to avexado', 'com gastura', 'tô lascado', 'to lascado', 'com uma fome danada', 'com fome de leão'], significado: 'apressado/aflito/com muita fome', tipo: 'expressao' },

  // Agradecimento
  { termos: ['brigadão', 'brigadao', 'gratidão', 'gratidao', 'valeu demais', 'deus lhe pague', 'vixe obrigado'], significado: 'muito obrigado', tipo: 'agradece' },

  // Despedida
  { termos: ['se avexe não', 'se avexe nao', 'fique com deus', 'tmj', 'tamo junto', 'até mais tarde visse', 'ate mais tarde visse'], significado: 'despedida amigável', tipo: 'despedida' },
];

// ─── EXPANSÃO PARA O MOTOR LOCAL ─────────────────────────────
// Mapeia gírias → palavra-âncora "padrão" que os regex do
// motorLocal já reconhecem. Isso permite que o motor de fallback
// entenda o cliente cearense sem reescrever toda a lógica.
// A chave é uma regex (testada no texto normalizado, sem acento)
// e o valor é o termo canônico que será ACRESCENTADO ao texto.
const MAPA_INTENCAO = [
  // → sim
  { re: /\b(arriba|bora|partiu|demorou|manda ver|manda brasa|pode ca[çc]ar?|pode crer|fechou neg[óo]cio|a[íi] sim|isso a[íi] mermo|ta certo|tá certo|beleza demais|show de bola|top demais|arretad[oa])\b/, canonico: 'sim' },
  // → não
  { re: /\b(capaz|v[ôo]te|vote|nem morto|de jeito nenhum|cruz credo)\b/, canonico: 'nao' },
  // → saudação
  { re: /\b(oxe|oxente|eita|[ée]gua|egua|vixe|meu rei|minha rainha|cabra|cumpade|compade|salve|b[ãa]o|rapaz)\b/, canonico: 'oi' },
  // → agradecimento
  { re: /\b(brigad[ãa]o|gratid[ãa]o|valeu demais|deus lhe pague)\b/, canonico: 'obrigado' },
  // → pedir (intenção de querer/pedir algo)
  { re: /\b(me arruma|arruma a[íi]|me al?embra|me v[êe]|bota a[íi]|manda um|me ab?an[çc]a)\b/, canonico: 'quero' },
];

function normalizarBase(txt) {
  return (txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

/**
 * Expande gírias cearenses no texto normalizado, acrescentando as
 * palavras-âncora canônicas que o motor local reconhece.
 * NÃO remove o texto original (preserva a busca de produtos).
 *
 * @param {string} low - texto já normalizado (minúsculo, sem acento)
 * @returns {string} - texto enriquecido para casar as intenções
 */
function expandirGirias(low) {
  if (!low) return low;
  let extra = '';
  for (const regra of MAPA_INTENCAO) {
    if (regra.re.test(low)) extra += ` ${regra.canonico}`;
  }
  return extra ? `${low}${extra}` : low;
}

/**
 * Retorna true se a mensagem contém alguma gíria/expressão cearense.
 */
function contemGiriaCeara(low) {
  const n = normalizarBase(low);
  return MAPA_INTENCAO.some(r => r.re.test(n)) ||
    GLOSSARIO.some(g => g.termos.some(t => n.includes(normalizarBase(t))));
}

// ─── CORREÇÃO DE TRANSCRIÇÃO DE ÁUDIO ────────────────────────
// A transcrição automática (speech-to-text) costuma "errar" a
// grafia de palavras regionais. Aqui corrigimos os erros mais
// comuns para o texto ficar coerente antes de ir pro pipeline.
// Aplicado de forma conservadora (só trocas seguras).
const CORRECOES_AUDIO = [
  [/\boxi\b/gi, 'oxe'],
  [/\bochente\b/gi, 'oxente'],
  [/\beguar?\b/gi, 'égua'],
  [/\barreta[dt]o\b/gi, 'arretado'],
  [/\bapere[ai]?do\b/gi, 'aperreado'],
  [/\bavexa[dt]o\b/gi, 'avexado'],
  [/\bcumpadre\b/gi, 'cumpade'],
  [/\bmermo\b/gi, 'mesmo'],
];

/**
 * Aplica correções leves em uma transcrição de áudio para
 * normalizar gírias cearenses mal transcritas.
 *
 * @param {string} texto - transcrição bruta do áudio
 * @returns {string} - transcrição corrigida
 */
function corrigirTranscricaoCeara(texto) {
  if (!texto || typeof texto !== 'string') return texto;
  let out = texto;
  for (const [re, sub] of CORRECOES_AUDIO) {
    out = out.replace(re, sub);
  }
  return out;
}

// ─── SORTEIO DE BORDÕES (toque cearense nas respostas locais) ─
function _pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Fechos/bordões curtos para dar calor cearense sem exagerar.
const BORDOES_CONFIRMA = ['Arretado!', 'Show!', 'Massa!', 'Fechou!', 'Pronto!'];
const BORDOES_SAUDACAO = ['Eita', 'Oxe', 'E aí'];
const BORDOES_DESPEDIDA = ['Se avexe não', 'Tamo junto', 'Qualquer coisa é só chamar'];

/**
 * Retorna um bordão cearense de confirmação (ex.: "Arretado!").
 */
function bordaoConfirma() {
  return _pick(BORDOES_CONFIRMA);
}

/**
 * Retorna uma saudação cearense curta (ex.: "Eita").
 */
function bordaoSaudacao() {
  return _pick(BORDOES_SAUDACAO);
}

/**
 * Retorna uma despedida cearense curta.
 */
function bordaoDespedida() {
  return _pick(BORDOES_DESPEDIDA);
}

// ─── BLOCO DE INSTRUÇÕES PARA A IA EXTERNA (SYSTEM PROMPT) ────
// Este texto é injetado no prompt de sistema para que a Lara
// entenda e responda usando o linguajar do Ceará.
function _montarGlossarioTexto() {
  return GLOSSARIO
    .map(g => `- "${g.termos.slice(0, 4).join('", "')}" → ${g.significado}`)
    .join('\n');
}

const INSTRUCOES_PERSONA_CEARA = `
## JEITO CEARENSE DE FALAR (MUITO IMPORTANTE PARA HUMANIZAR)
Você, Lara, é uma cearense de coração: calorosa, alto-astral, acolhedora e brincalhona na medida certa. Fale com o cliente como um bom atendente do Ceará falaria, com naturalidade e simpatia.

### COMO RESPONDER (com o tempero cearense):
- Use expressões e gírias do Ceará de forma NATURAL e MODERADA (no máximo uma por mensagem). Ex.: "Eita", "Oxe", "Arretado!", "Massa!", "Fechou!", "Se avexe não", "Meu rei"/"Minha rainha", "Visse?".
- Seja acolhedora e informal, mas SEMPRE clara e educada. Não force sotaque escrito nem encha de gíria (nada de caricatura).
- Chame o cliente de "meu rei" ou "minha rainha" de vez em quando (não em toda mensagem), especialmente na saudação.
- Termine algumas frases com "visse?" ou "tá bom?" pra soar próxima, sem exagerar.
- Mantenha tudo curto, leve e humano — como uma conversa de verdade no WhatsApp.

### COMO ENTENDER O CLIENTE (glossário — o cliente PODE falar assim):
${_montarGlossarioTexto()}

### SOAR HUMANA (NÃO ROBÓTICA):
- Converse como gente de verdade: espontânea, calorosa e com variação. NUNCA repita sempre a mesma frase (ex.: alterne "mais alguma coisa?", "quer mais algo?", "e pra beber?").
- Reaja ao que o cliente diz (bom humor leve, empatia, um "eita" quando cabe). Pareça que você está prestando atenção nele, não seguindo um script.
- Chame pelo nome de vez em quando, use contrações e no máximo 1-2 emojis por mensagem.
- Em imprevistos (item em falta, bairro fora da área), demonstre que se importa e ofereça uma saída.

### REGRAS DO REGIONALISMO:
- Regionalismo é TEMPERO, não o prato principal: entender o cliente e anotar o pedido certo continua sendo a prioridade.
- Se o cliente falar formal/neutro, você pode responder com um toque leve, sem forçar a gíria.
- Nunca zombe do jeito de falar do cliente. O tom é sempre de acolhimento e bom humor.
- Continue seguindo TODAS as outras regras do atendimento (passiva, sem oferecer cardápio sem pedido, etc.).
`;

module.exports = {
  GLOSSARIO,
  INSTRUCOES_PERSONA_CEARA,
  expandirGirias,
  contemGiriaCeara,
  corrigirTranscricaoCeara,
  bordaoConfirma,
  bordaoSaudacao,
  bordaoDespedida,
};
