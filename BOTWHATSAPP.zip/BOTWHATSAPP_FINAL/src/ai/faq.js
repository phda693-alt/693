/**
 * ============================================================
 *  DICIONÁRIO DE PERGUNTAS FREQUENTES (FAQ)  ❓
 * ============================================================
 * Dicionário extenso e variado com sinônimos das perguntas mais
 * comuns que o cliente faz durante o atendimento. Serve para o bot
 * responder na hora — inclusive no meio do pedido — sem "sair da rota".
 *
 * Cada intenção tem:
 *   - chave: identificador
 *   - re: regex com MUITAS variações/sinônimos (texto já normalizado:
 *          minúsculo e SEM acentos)
 *   - resposta: função(config) que devolve o texto, OU null quando a
 *               resposta é dinâmica (ex.: total do pedido) e é montada
 *               no motor local.
 *
 * Observação: os padrões são testados contra o texto normalizado
 * (sem acento), então escreva "voce", "horario", "promocao", etc.
 * ============================================================
 */

const FAQ = [
  // ─── TOTAL / VALOR DO PEDIDO (dinâmico) ──────────────────
  {
    chave: 'total_pedido',
    re: /\b(quanto (deu|ficou|fica|vai dar|vai ser|ficaria|da no total|deu no total)|deu quanto|ficou quanto|qual (o |e o )?total|valor total|total do pedido|total ate agora|quanto (e|eh) tudo|quanto (e|eh) no total|soma (deu|ficou)|qual o valor( do pedido)?)\b/,
    resposta: null,
  },
  // ─── RESUMO / CONFERIR O PEDIDO (dinâmico) ───────────────
  {
    chave: 'resumo_pedido',
    re: /\b(o que (eu )?pedi|o que (eu )?ja pedi|meu pedido (ta|esta|ficou)|como (ta|esta) (o )?meu pedido|resumo do pedido|resumir o pedido|conferir o pedido|revisar o pedido|meu carrinho|o que ta no (carrinho|pedido)|repete o pedido|me mostra o pedido)\b/,
    resposta: null,
  },

  // ─── TEMPO DE ENTREGA ────────────────────────────────────
  {
    chave: 'tempo_entrega',
    re: /\b(quanto tempo|demora quanto|quanto demora|quanto (vai |vai se )?demora(r)?|vai demorar|demora muito|leva quanto tempo|em quanto tempo|tempo de (entrega|espera|preparo)|tempo estimado|prazo de entrega|que horas (chega|entrega|sai)|quando (chega|sai|fica pronto)|daqui a quanto|ta muito demorado|e rapido|tempo pra chegar)\b/,
    resposta: (c) => `A entrega leva em média *${c.loja.tempoEstimadoMin} a ${c.loja.tempoEstimadoMax} minutos* depois que o pedido é confirmado. 🛵`,
  },

  // ─── TAXA DE ENTREGA / FRETE ─────────────────────────────
  {
    chave: 'taxa_entrega',
    re: /\b(quanto (e|eh|fica|custa|sai) (a )?(entrega|taxa|frete)|qual (e |eh )?(a )?taxa( de entrega)?|valor (da|de) entrega|preco (da|de) entrega|quanto (e|eh) o frete|tem taxa de entrega|cobra(m)? (taxa|entrega|frete))\b/,
    resposta: () => `A taxa de entrega varia conforme o *bairro*. Me passa seu endereço ou o bairro que eu já te falo o valor certinho! 🛵`,
  },

  // ─── FORMAS DE PAGAMENTO ─────────────────────────────────
  {
    chave: 'formas_pagamento',
    re: /\b(formas? de pagamento|meios de pagamento|opcoes de pagamento|como (posso |eu |que )?pago|como (e|eh) (o )?pagamento|paga(r)? como|quais (as )?formas|aceita(m)? (cartao|pix|dinheiro|credito|debito|vale)|pode (ser|pagar) (cartao|pix|dinheiro|no cartao)|tem (maquininha|maquina de cartao)|passa cartao)\b/,
    resposta: (c) => {
      const nomes = (c.formasPagamento || []).map(f => f.nome);
      if (!nomes.some(n => /pix/i.test(n))) nomes.push('PIX');
      return `Aceitamos ${nomes.join(', ')}. 💳 Se quiser, dá pra dividir em mais de uma forma!`;
    },
  },

  // ─── CHAVE PIX ───────────────────────────────────────────
  {
    chave: 'chave_pix',
    re: /\b(chave (do )?pix|qual (o |a |e o |e a )?pix|manda(r)? (o |a )?(pix|chave)|numero do pix|cnpj do pix|cpf do pix|qual (a )?chave|me passa o pix|pix de voces)\b/,
    resposta: (c) => (c.pix && c.pix.chave)
      ? `Nossa chave PIX é *${c.pix.chave}*${c.pix.titular ? ` (${c.pix.titular})` : ''}. 💠 Depois é só mandar o comprovante aqui!`
      : `Quando você escolher PIX no fechamento, eu já te mando a chave certinha. 💠`,
  },

  // ─── HORÁRIO DE FUNCIONAMENTO ────────────────────────────
  {
    chave: 'horario',
    re: /\b(que horas? (abre|fecha|abrem|fecham)|horario de (funcionamento|atendimento|voces)|ta(o)? aberto|estao? aberto(s)?|ta(o)? funcionando|abre que horas|ate que horas (vai|abre|funciona)|funciona(m)? ate|voces (abrem|fecham)|ainda (ta|esta) aberto|ta aberto agora)\b/,
    resposta: (c) => `Funcionamos das *${c.loja.horarioAbertura} às ${c.loja.horarioFechamento}*. 🕐`,
  },

  // ─── ONDE FICA / RETIRADA ────────────────────────────────
  {
    chave: 'endereco_loja',
    re: /\b(onde (voces |vcs )?(fica(m)?|estao|ficam localizados|e|eh)|qual (o )?endereco de (voces|vcs)|endereco da loja|localizacao de voces|onde (e|eh) (a loja|voces|ai)|posso retirar|pode retirar|retirar no (local|balcao)|buscar (no local|ai)|voces tem (loja fisica|ponto))\b/,
    resposta: (c) => `Ficamos em *${c.loja.endereco}*. 📍 Pode retirar aqui ou pedir entrega, como preferir!`,
  },

  // ─── CONTATO / FALAR COM HUMANO ──────────────────────────
  {
    chave: 'contato',
    re: /\b(telefone de (voces|vcs)|numero de (voces|vcs)|contato de voces|falar com (um )?(atendente|humano|pessoa|gerente|responsavel)|atendente (humano|de verdade)|quero falar com alguem|tem alguem ai)\b/,
    resposta: (c) => `Nosso contato é *${c.loja.telefone}*. ☎️ Mas pode resolver tudo comigo por aqui mesmo, viu? 😊`,
  },

  // ─── DESCONTO / PROMOÇÃO / CUPOM ─────────────────────────
  {
    chave: 'desconto',
    re: /\b(tem desconto|algum desconto|tem promocao|ta em promocao|tem cupom|cupom de desconto|codigo de desconto|tem oferta|ta em oferta|faz (um )?precinho|faz por menos|da um desconto|desconta|abate|tem combo|combo promocional)\b/,
    resposta: () => `No momento não temos cupom de desconto, mas pode ficar tranquilo que o preço já é camarada! 😉 Qualquer promoção a gente avisa por aqui.`,
  },

  // ─── FAZ ENTREGA / DELIVERY ──────────────────────────────
  {
    chave: 'faz_entrega',
    re: /\b(voces? entrega(m)?|vcs entrega(m)?|faz(em)? (entrega|delivery)|tem (entrega|delivery|tele ?entrega)|entrega(m)? (em|na|no|ai|aqui)|voces vao ate|leva(m)? (ai|em casa)|entrega em domicilio)\b/,
    resposta: () => `Fazemos entrega sim! 🛵 A taxa depende do seu bairro — me diz onde você tá que eu confirmo o valor.`,
  },

  // ─── PEDIDO MÍNIMO ───────────────────────────────────────
  {
    chave: 'pedido_minimo',
    re: /\b(pedido minimo|valor minimo|minimo (pra|para) (pedir|entrega)|tem minimo|precisa (pedir|gastar) (um )?minimo)\b/,
    resposta: () => `Não temos valor mínimo, não! Pode pedir o que quiser. 😊`,
  },

  // ─── EMBALAGEM / TALHERES ────────────────────────────────
  {
    chave: 'embalagem',
    re: /\b(vem (talher|guardanapo|canudo)|manda(r)? talher|tem talher|embalado|vem embalado|embalagem)\b/,
    resposta: () => `Mandamos tudo bem embalado e com os itens necessários pra você. 😉 Se precisar de algo específico, é só avisar!`,
  },

  // ─── IDENTIDADE DO BOT ───────────────────────────────────
  {
    chave: 'bot_identidade',
    re: /\b(voce (e|eh) (um |uma )?(robo|bot|humano|humana|pessoa|maquina|atendente)|(e|eh) um robo|qual (seu|o teu|o seu) nome|quem (e|eh) voce|com quem (eu )?falo|voce (e|eh) real|isso (e|eh) um robo|to falando com (um robo|uma pessoa))\b/,
    resposta: () => `Eu sou a *Lara*, atendente virtual daqui! 😊 Pode fazer seu pedido comigo que eu cuido de tudo, visse?`,
  },
];

/**
 * Detecta se a mensagem é uma pergunta frequente.
 * @param {string} low - texto normalizado (minúsculo, sem acentos)
 * @returns {object|null} a intenção correspondente, ou null
 */
function detectarFAQ(low) {
  if (!low) return null;
  for (const item of FAQ) {
    if (item.re.test(low)) return item;
  }
  return null;
}

module.exports = { FAQ, detectarFAQ };
