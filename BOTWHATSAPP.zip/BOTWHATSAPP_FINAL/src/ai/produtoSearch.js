/**
 * ============================================================
 *  BUSCA INTELIGENTE DE PRODUTOS
 * ============================================================
 * Lógica para encontrar produtos no cardápio com base
 * em termos de busca do cliente, usando similaridade
 * de strings e palavras-chave.
 * ============================================================
 */

const { produtos, categorias } = require('../database/db');

/**
 * Busca produtos que correspondam ao desejo do cliente
 *
 * @param {string} termo - O que o cliente está procurando
 * @returns {Array} - Lista de produtos encontrados com categoria
 */
function buscarProdutosNoCardapio(termo) {
  if (!termo || termo.length < 2) return [];

  const termoLower = termo.toLowerCase().trim();
  const todosProdutos = produtos.listar(); // Já traz produtos com categoria_nome e categoria_emoji

  // 1. Tentar busca exata por nome
  let resultados = todosProdutos.filter(p =>
    p.nome.toLowerCase().includes(termoLower) ||
    (p.descricao && p.descricao.toLowerCase().includes(termoLower))
  );

  // 2. Se não achou nada, tentar quebrar o termo em palavras
  if (resultados.length === 0) {
    const palavras = termoLower.split(/\s+/).filter(p => p.length > 3);
    if (palavras.length > 0) {
      resultados = todosProdutos.filter(p =>
        palavras.some(pal => p.nome.toLowerCase().includes(pal))
      );
    }
  }

  // 3. Tentar busca por categoria
  if (resultados.length === 0) {
    const todasCategorias = categorias.listar();
    const catEncontrada = todasCategorias.find(c =>
      c.nome.toLowerCase().includes(termoLower) ||
      termoLower.includes(c.nome.toLowerCase())
    );

    if (catEncontrada) {
      resultados = produtos.buscarPorCategoria(catEncontrada.id).map(p => ({
        ...p,
        categoria_nome: catEncontrada.nome,
        categoria_emoji: catEncontrada.emoji
      }));
    }
  }

  // Limitar a 5 resultados e formatar para a IA
  return resultados.slice(0, 5).map(p => ({
    id: p.id,
    nome: p.nome,
    preco: p.preco,
    descricao: p.descricao,
    categoria: p.categoria_nome,
    emoji: p.categoria_emoji
  }));
}

/**
 * Formata a lista de produtos que "parecem" com o que o cliente falou.
 * Estes itens servem APENAS para a Lara confirmar por escuta —
 * nunca para ela oferecer ou listar por conta própria.
 */
function formatarProdutosParaIA(encontrados) {
  if (!encontrados || encontrados.length === 0) return "";

  let texto = "\n## POSSÍVEL CORRESPONDÊNCIA COM O QUE O CLIENTE ACABOU DE FALAR:\n";
  texto += "(A fala do cliente lembra os itens abaixo. Isto é uso interno para você RECONHECER — não é uma lista para mostrar.)\n";
  encontrados.forEach(p => {
    texto += `- ${p.emoji || ''} ${p.nome} (R$ ${p.preco.toFixed(2)})${p.descricao ? ' - ' + p.descricao : ''}\n`;
  });
  texto += `
COMO AGIR:
- Se UM item parecer claramente o que o cliente quis dizer, PERGUNTE se é isso. Ex: "Você quer dizer o *${encontrados[0].nome}*, certo? 😊"
- Se houver mais de uma possibilidade real, pergunte qual delas ele quer (com naturalidade, sem parecer um menu).
- NÃO ofereça esses itens se o cliente não deu nenhum indício de querê-los. NÃO faça upsell.
- Só coloque no carrinho DEPOIS que o cliente confirmar. Depois, pergunte de leve se ele quer mais alguma coisa.
`;

  return texto;
}

module.exports = {
  buscarProdutosNoCardapio,
  formatarProdutosParaIA
};
