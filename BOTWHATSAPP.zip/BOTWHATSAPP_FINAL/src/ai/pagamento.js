/**
 * ============================================================
 *  INTERPRETADOR DE FORMAS DE PAGAMENTO  💳
 * ============================================================
 * Entende quando o cliente quer pagar de UMA ou de VÁRIAS formas,
 * com ou sem valores. Exemplos que passam a ser entendidos:
 *
 *   "pix"                          → PIX
 *   "metade no pix e metade em dinheiro"
 *   "20 no pix e o resto no cartão"
 *   "R$30 no débito e 9,90 em dinheiro"
 *   "pix e dinheiro"               → PIX + Dinheiro (sem valores)
 *
 * Retorna uma descrição pronta para gravar em forma_pagamento e
 * um detalhamento estruturado (partes) para quem quiser usar.
 * ============================================================
 */

function normalizar(txt) {
  return (txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function formatarBRL(v) {
  return `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
}

// Métodos reconhecidos (ordem importa: débito/crédito antes de "cartão" genérico)
// Regexes tolerantes a erros de digitação comuns (ex.: "pox" -> pix).
const METODOS = [
  { chave: 'pix', nome: 'PIX', re: /\b(p[ioaey]x+|chave pix|pcx|pikx)\b/ },
  { chave: 'debito', nome: 'Cartão de Débito', re: /\b(debito|devito|debto|no debito|cartao de debito|maquininha.*debito)\b/ },
  { chave: 'credito', nome: 'Cartão de Crédito', re: /\b(credito|no credito|cartao de credito|maquininha.*credito)\b/ },
  { chave: 'dinheiro', nome: 'Dinheiro', re: /\b(dinh?\w*|especie|grana|trocado|em maos|na hora|vivo|cash)\b/ },
];

// Detecta um valor/fração dentro de um trecho (decimais já normalizados com ponto)
function extrairValorTrecho(seg) {
  if (/\b(metade|meia|meio a meio)\b/.test(seg)) return { tipo: 'metade' };
  if (/\b(resto|restante|o que faltar|o que sobrar|diferenca|complemento)\b/.test(seg)) return { tipo: 'resto' };
  // valor monetário: "20", "9.90", "r$ 30", "30 reais"
  const m = seg.match(/(?:r\$\s*)?(\d+(?:\.\d{1,2})?)\s*(?:reais|conto)?/);
  if (m) return { tipo: 'valor', valor: parseFloat(m[1]) };
  return null;
}

/**
 * Interpreta o texto de pagamento.
 * @param {string} texto - o que o cliente digitou
 * @param {number} total - total do pedido (para calcular metade/resto)
 * @returns {{ descricao: string, multiplo: boolean, partes: Array, reconhecido: boolean }}
 */
function interpretarPagamento(texto, total = 0, formasAceitas = null) {
  // formasAceitas: lista opcional de chaves aceitas (['pix','dinheiro','debito',
  // 'credito','cartao']). Se informada, SÓ reconhece essas formas.
  const aceita = (chave) => !formasAceitas || formasAceitas.includes(chave);

  // Protege vírgulas decimais ("9,90" -> "9.90") ANTES de dividir por conectores,
  // senão a vírgula do decimal seria confundida com separador de formas.
  const low = normalizar(texto).replace(/(\d),(\d{1,2})(?=\D|$)/g, '$1.$2');

  // Quebra em trechos por conectores comuns ("e", "+", ",", ";", "mais")
  const trechos = low.split(/\s*(?:,|;|\+|\be\b|\bmais\b)\s*/).filter(t => t && t.trim());

  const partes = [];
  const usados = new Set();

  const analisar = (seg) => {
    let achouMetodoEspecifico = false;
    for (const m of METODOS) {
      if (m.re.test(seg) && !usados.has(m.chave) && aceita(m.chave)) {
        usados.add(m.chave);
        achouMetodoEspecifico = true;
        partes.push({ chave: m.chave, nome: m.nome, valorInfo: extrairValorTrecho(seg), valor: null });
      }
    }
    // "cartão" genérico (sem dizer débito/crédito)
    if (!achouMetodoEspecifico && /\b(cartao|maquininha|maquina)\b/.test(seg)
        && !usados.has('cartao') && !usados.has('debito') && !usados.has('credito')
        && (aceita('cartao') || aceita('debito') || aceita('credito'))) {
      usados.add('cartao');
      partes.push({ chave: 'cartao', nome: 'Cartão', valorInfo: extrairValorTrecho(seg), valor: null });
    }
  };

  trechos.forEach(analisar);
  // Se a quebra por trechos não achou nada, tenta o texto inteiro
  if (partes.length === 0) analisar(low);

  // Nada reconhecido → devolve o texto cru (mantém comportamento antigo)
  if (partes.length === 0) {
    const cru = (texto || '').trim();
    return { descricao: cru, multiplo: false, partes: [], reconhecido: false };
  }

  // ─── Resolve valores (metade / resto / valor fixo) ───
  const t = Number(total) || 0;
  let somaConhecida = 0;
  for (const p of partes) {
    const info = p.valorInfo;
    if (info && info.tipo === 'valor') { p.valor = info.valor; somaConhecida += info.valor; }
    else if (info && info.tipo === 'metade' && t > 0) { p.valor = Number((t / 2).toFixed(2)); somaConhecida += p.valor; }
  }
  // partes marcadas como "resto" (ou sem valor, quando há valores em outras)
  const resolverResto = () => {
    const restante = Number((t - somaConhecida).toFixed(2));
    return restante > 0 ? restante : 0;
  };
  for (const p of partes) {
    if (p.valor != null) continue;
    const info = p.valorInfo;
    if (info && info.tipo === 'resto') { p.valor = resolverResto(); somaConhecida += p.valor; }
  }
  // Se sobrou exatamente UMA parte sem valor e as outras já têm, ela leva o resto
  const semValor = partes.filter(p => p.valor == null);
  if (semValor.length === 1 && partes.length > 1 && t > 0 && somaConhecida > 0) {
    semValor[0].valor = resolverResto();
  }

  const multiplo = partes.length > 1;

  // ─── Monta a descrição legível ───
  let descricao;
  if (!multiplo) {
    // Uma forma só: mostra o valor apenas se o cliente informou explicitamente
    const p = partes[0];
    descricao = (p.valorInfo && p.valorInfo.tipo === 'valor')
      ? `${p.nome} (${formatarBRL(p.valor)})`
      : p.nome;
  } else {
    descricao = partes
      .map(p => (p.valor != null ? `${p.nome} (${formatarBRL(p.valor)})` : p.nome))
      .join(' + ');
  }

  return { descricao, multiplo, partes, reconhecido: true };
}

/**
 * Diz se a forma de pagamento envolve PIX (inclusive pagamento dividido).
 */
function pagamentoTemPix(forma) {
  return /\bpix\b/i.test(forma || '');
}

/**
 * Monta a mensagem "estamos aguardando o PIX" com a chave da loja.
 * @param {object} pixConfig - config.pix ({ chave, tipo, titular })
 * @param {number} [valor] - valor a exibir (opcional)
 */
function textoAguardandoPix(pixConfig, valor) {
  const chave = pixConfig && pixConfig.chave ? pixConfig.chave : '';
  const titular = pixConfig && pixConfig.titular ? pixConfig.titular : '';
  let msg = `💠 *Pagamento via PIX*`;
  if (valor) msg += `\nValor: ${formatarBRL(valor)}`;
  if (chave) msg += `\n🔑 Chave PIX: ${chave}${titular ? `\n👤 ${titular}` : ''}`;
  msg += `\n\n⏳ *Estamos aguardando o seu PIX!* Assim que você enviar, é só mandar o comprovante aqui que a gente confirma o pedido e manda pra cozinha. 🍳`;
  return msg;
}

/**
 * Deriva as "chaves" de forma de pagamento aceitas a partir da lista
 * configurada na loja (config.formasPagamento). Ex.: [{nome:'PIX'}, ...].
 */
function chavesAceitas(formasPagamento) {
  const chaves = new Set(['pix']); // PIX é sempre oferecido pelo sistema
  for (const f of (formasPagamento || [])) {
    const n = normalizar(f && f.nome);
    if (/pix/.test(n)) chaves.add('pix');
    else if (/dinheiro|especie/.test(n)) chaves.add('dinheiro');
    else if (/debito/.test(n)) { chaves.add('debito'); chaves.add('cartao'); }
    else if (/credito/.test(n)) { chaves.add('credito'); chaves.add('cartao'); }
    else if (/cartao|maquin/.test(n)) chaves.add('cartao');
  }
  return [...chaves];
}

module.exports = { interpretarPagamento, formatarBRL, pagamentoTemPix, textoAguardandoPix, chavesAceitas };
