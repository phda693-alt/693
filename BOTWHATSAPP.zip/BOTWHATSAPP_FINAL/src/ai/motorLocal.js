/**
 * ============================================================
 *  MOTOR CONVERSACIONAL LOCAL (SEM DEPENDÊNCIA DE IA EXTERNA)
 * ============================================================
 * Usado como cérebro do bot quando NENHUM provedor de IA
 * (OpenAI/Mistral/etc.) está disponível.
 *
 * Reproduz de forma determinística o comportamento pedido:
 *   - NUNCA oferece o cardápio nem pede para "digitar" nada.
 *   - Escuta as palavras do cliente e, se lembrarem um item do
 *     cardápio, PERGUNTA se é aquilo.
 *   - Só coloca no carrinho quando o cliente CONFIRMA.
 *   - Depois pergunta se ele quer mais alguma coisa.
 *   - Só mostra o cardápio se o cliente PEDIR explicitamente.
 * ============================================================
 */

const config = require('../config');
const { produtos, categorias } = require('../database/db');

// ─── DICIONÁRIOS DE INTENÇÃO ─────────────────────────────────
const RE_SIM = /\b(sim|isso|isso mesmo|é isso|e isso|eh isso|isso ai|isso aí|pode ser|pode|aham|ahan|claro|exato|exatamente|isso mesmo|correto|positivo|ok|okay|blz|beleza|com certeza|perfeito|quero sim|esse|essa|esse mesmo)\b/i;
const RE_NAO = /\b(n[ãa]o|nao|nops|nem|negativo|errado|esquece|deixa|outro|outra|nada disso|nenhum|nenhuma|nenum|nem um)\b/i;
const RE_CARDAPIO = /(card[aá]pio|cardapio|\bmenu\b|o que (voc[êe]s?\s*)?(t[eê]m|tem|servem|vende[m]?|possuem)|op[çc][õo]es|o que tem|quais (s[ãa]o|as op)|lista de pre[çc]o|tabela|manda o card)/i;
const RE_FINALIZAR = /(s[óo] isso|so isso|é s[óo]|eh so|e so|fechar( a conta| o pedido)?|fechou|finalizar|pode fechar|encerrar|mais nada|nada mais|era s[óo]|era so|pode enviar|manda(r)? o pedido|s[óo] is'?so|to satisfeito|chega)/i;
const RE_SAUDACAO = /\b(oi+|ol[áa]|ola|e a[íi]|eai|opa|bom dia|boa tarde|boa noite|tudo bem|tudo bom|fala|salve|boa)\b/i;
const RE_AGRADECE = /\b(obrigad[oa]|valeu|vlw|agrade[çc]o|grato|brigad[oa])\b/i;

// Remoção de item do carrinho ("retira", "tira", "cancela", "não quero mais")
const RE_REMOVER = /\b(retir\w*|remov\w*|cancel\w*|exclu\w*|apag\w*)\b|\btir(a|e|ar|ei|ou|em|o|amos)?\b|n[ãa]o quero (mais|ela|ele|isso|esse|essa)/i;
// Intenção de adicionar/trocar ("coloca/coloque", "poe", "quero", "troca por")
const RE_ADD = /\b(colo\w*|bot\w*|p[õo]e\w*|adicion\w*|acrescent\w*|inclu\w*|met[ae]\w*|troc\w*|quero|manda\w*)\b|\b(por|pelo|pela)\b/i;
// Observação / personalização do item ("sem cebola", "bem passada", "capricha", "fritar bem")
const RE_COOK = /bem\s*passad|mal\s*passad|ao\s*ponto|no\s*ponto|caprich\w*|frit\w*\s*bem|bem\s*frit\w*|bem\s*assad|pe[çc]a\s+(pra|para)|pede\s+(pra|para)|manda\s+(fazer|frit|assa|caprich)|\bsem\s+\w+|\bcom\s+(muito|mais|extra)\b|\bextra\b|bem\s+quente|\btirar?\s+(a|o|as|os)\s+\w+/i;

// Palavras que NÃO devem disparar busca de produto
const STOPWORDS = new Set([
  'oi','ola','ola','opa','eai','salve','bom','boa','dia','tarde','noite','tudo','bem','bom',
  'sim','nao','isso','esse','essa','pode','ser','aham','claro','exato','ok','okay','blz','beleza',
  'quero','queria','gostaria','vou','var','uma','um','uns','umas','dois','duas','tres','quero',
  'de','da','do','das','dos','com','sem','por','favor','pra','para','me','ve','ver','manda','mandar',
  'que','tem','ai','aqui','entao','tipo','acho','talvez','e','ou','ta','to','estou','com','fome',
  'obrigado','obrigada','valeu','vlw','entrega','pedido','conta','fechar','isso','mesmo','the','and',
]);

// Palavras genéricas que não devem, sozinhas, casar remoção de item
const GENERICOS = new Set(['lata', 'latas', 'garrafa', 'ml', 'litro', 'litros', 'natural', 'frita', 'fritas', 'porcao', 'porcoes', 'mineral']);

function normalizar(txt) {
  return (txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function saudacaoHora() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return 'Bom dia';
  if (h >= 12 && h < 18) return 'Boa tarde';
  return 'Boa noite';
}

/**
 * Reconhece afirmações curtas como "e", "é", "eh", "aa", "isso", "sim".
 * (o cliente costuma responder só "e"/"é" para dizer sim)
 */
function ehAfirmacaoCurta(low) {
  return /^(e|eh|ea|aa+|ah|isso|sim|s|ss|ok|okay|uhum|aham|claro|positivo|exato|blz|beleza)$/.test((low || '').trim());
}

function extrairQuantidade(texto) {
  const norm = normalizar(texto);
  const m = norm.match(/\b(\d{1,2})\b/);
  if (m) {
    const q = parseInt(m[1], 10);
    if (q >= 1 && q <= 50) return q;
  }
  if (/\bmeia\s+d[uú]zia\b/.test(norm)) return 6;
  if (/\b(uma\s+)?d[uú]zia\b/.test(norm)) return 12;
  const mapa = {
    um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5,
    seis: 6, sete: 7, oito: 8, nove: 9, dez: 10,
  };
  for (const [k, v] of Object.entries(mapa)) {
    if (new RegExp(`\\b${k}\\b`).test(norm)) return v;
  }
  return 1;
}

/**
 * Busca itens do cardápio por PALAVRAS INTEIRAS no NOME do produto
 * (ignora descrição para evitar falsos positivos como "ola" em "cebola").
 * Retorna lista ordenada por relevância.
 */
function procurarItens(texto) {
  const norm = normalizar(texto);
  const alvo = norm.replace(/[^a-z0-9]+/g, ' ').trim();
  const msgCompact = norm.replace(/[^a-z0-9]/g, '');
  const lista = produtos.listar();

  // Nome "compacto" embutido na frase é sinal MUITO forte
  // (ex.: "x-tudo" → X-Tudo; "coca cola lata" → Coca-Cola Lata),
  // mesmo quando as demais palavras são stopwords (quero, tudo...).
  const compactHits = lista.filter(p => {
    const pc = normalizar(p.nome).replace(/[^a-z0-9]/g, '');
    return pc.length >= 5 && msgCompact.includes(pc);
  });
  if (compactHits.length >= 1) return compactHits;

  const tokens = alvo.split(/\s+/).filter(t => t.length >= 3 && !STOPWORDS.has(t));
  if (tokens.length === 0) return [];

  const nomesCategorias = (categorias.listar() || []).map(c => ({ id: c.id, nome: normalizar(c.nome) }));

  const scored = lista.map(p => {
    const pnome = normalizar(p.nome);
    const pwords = pnome.split(/[^a-z0-9]+/).filter(Boolean);
    let score = 0;

    for (const t of tokens) {
      if (pwords.includes(t)) score += 3;             // palavra inteira no nome
      else if (t.length >= 4 && pnome.includes(t)) score += 1; // parte relevante
    }
    // bônus por correspondência exata de nome
    const pnomeAlvo = pnome.replace(/[^a-z0-9]+/g, ' ').trim();
    if (pnomeAlvo === alvo) score += 10;
    // bônus por nome "compacto" embutido na frase (ex.: "x-bacon" → X-Bacon)
    const pcompact = pnome.replace(/[^a-z0-9]/g, '');
    if (pcompact.length >= 4 && msgCompact.includes(pcompact)) score += 10;
    // bônus por categoria citada (ex.: "pizza", "batata", "refrigerante")
    const cat = nomesCategorias.find(c => tokens.includes(c.nome) || c.nome.split(/\s+/).some(w => tokens.includes(w)));
    if (cat && p.categoria_id === cat.id) score += 1;

    return { p, score };
  }).filter(x => x.score > 0);

  scored.sort((a, b) => b.score - a.score);

  if (scored.length === 0) return [];
  // Correspondência exata / nome compacto → só ela
  if (scored[0].score >= 10) return [scored[0].p];
  // Líder claro de pontuação (ex.: "coca lata" casa 2 palavras) → só ele
  if (scored.length === 1) return [scored[0].p];
  if (scored[0].score >= 6 && scored[0].score > scored[1].score) return [scored[0].p];
  return scored.slice(0, 4).map(x => x.p);
}

/**
 * Mapa de SINÔNIMOS / termos genéricos → itens do cardápio.
 * Permite entender palavras que NÃO estão no nome dos produtos.
 * Ex.: "refrigerante" → Coca-Cola/Guaraná; "hambúrguer/lanche/xis" → linha X-.
 * `re` é testado no texto do cliente; `nome` filtra pelo nome do produto e
 * `categoria` filtra pela categoria (nome normalizado).
 */
const REGRAS_SINONIMOS = [
  { re: /x[\s-]?tudo|xtudo/, nome: /x-?\s*tudo/ },
  { re: /refri(gerante)?s?|\bsoda\b|coca\s*-?\s*cola|coquinha|coca|cola\b|guaran|guaracamp|pepsi|fanta|sprite|tub[aа][ií]na|tubaina/, nome: /coca|guaran|pepsi|fanta|sprite/ },
  { re: /cheese\s*-?\s*burgu?er|cheeseburg|h?amb[uú]rgu?er|hamburg|burgu?er|\bxis\b|\bx-?burg|sandu[ií]ch?e?|sandub|lanch/, categoria: 'hamburgueres' },
  { re: /batat(a|inha|as)|fritas?|frita/, nome: /batata|frita/ },
  { re: /por[çc][aã]o|porcao|porcoes|petisco|aperitivo|acompanhament/, categoria: 'porcoes' },
  { re: /nugget|empanad|frango\s*(frito|empanad)/, nome: /nugget/ },
  { re: /onion|cebola|an[eé]is|anel/, nome: /onion/ },
  { re: /sobremesa|doce|milk\s*-?\s*shake|milkshake|shake|sorvete|sundae|a[çc]a[íi]/, categoria: 'sobremesas' },
  { re: /combo|promo[çc]?[aã]?o?|promo/, categoria: 'combos' },
  { re: /\bsucos?\b/, nome: /suco/ },
  { re: /[áa]gua|agua/, nome: /agua/ },
  { re: /\bpizzas?\b/, categoria: 'pizzas' },
  { re: /bebida|beber|tomar|algo\s+gelad|refresco/, categoria: 'bebidas' },
];

/**
 * Busca por sinônimo/termo genérico (usada quando a busca por nome falha).
 * @returns {Array} lista de produtos candidatos
 */
function buscarPorSinonimo(low) {
  const lista = produtos.listar();
  for (const regra of REGRAS_SINONIMOS) {
    if (!regra.re.test(low)) continue;
    const res = lista.filter(p => {
      const pn = normalizar(p.nome);
      const cn = normalizar(p.categoria_nome || p.categoria || '');
      if (regra.nome && regra.nome.test(pn)) return true;
      if (regra.categoria && cn === regra.categoria) return true;
      return false;
    });
    if (res.length > 0) return res.slice(0, 5);
  }
  return [];
}

/**
 * Encontra produtos combinando busca por nome + sinônimos.
 * Prioriza o nome exato; só recorre a sinônimos quando o nome não casa.
 */
function encontrarProdutos(texto) {
  const diretos = procurarItens(texto);
  if (diretos.length > 0) return diretos;
  return buscarPorSinonimo(normalizar(texto));
}

/**
 * Detecta VÁRIOS itens numa mesma mensagem (ex.: "2 coca e um x-burguer").
 * Divide por conectores e resolve cada parte. Retorna:
 *   { resolvidos: [{produto, quantidade}], ambiguas: [{opcoes, quantidade}] }
 * ou null se não parecer um pedido com múltiplos itens.
 */
function segmentarPedido(texto) {
  const norm = normalizar(texto);
  const partes = norm
    .split(/\s*(?:,|\+|\/|\bmais\b|\btambem\b|\bcom\b(?=\s+\d)|\be\b)\s*/)
    .map(s => s.trim())
    .filter(Boolean);
  if (partes.length < 2) return null;

  const resolvidos = [];
  const ambiguas = [];
  for (const parte of partes) {
    const achados = encontrarProdutos(parte);
    if (achados.length === 1) {
      resolvidos.push({ produto: achados[0], quantidade: extrairQuantidade(parte) });
    } else if (achados.length > 1) {
      ambiguas.push({ opcoes: achados, quantidade: extrairQuantidade(parte) });
    }
  }
  if (resolvidos.length + ambiguas.length < 2) return null;
  return { resolvidos, ambiguas };
}

function resumoCarrinho(carrinho) {
  if (!carrinho || carrinho.length === 0) return '';
  let total = 0;
  const linhas = carrinho.map(i => {
    const sub = (i.preco || 0) * (i.quantidade || 1);
    total += sub;
    const obs = i.observacao ? ` _(${i.observacao})_` : '';
    return `• ${i.quantidade}x ${i.nome}${obs} — R$ ${sub.toFixed(2)}`;
  });
  return `${linhas.join('\n')}\n*Total: R$ ${total.toFixed(2)}*`;
}

function montarCardapio() {
  try {
    const cats = categorias.listar();
    if (!cats || cats.length === 0) return 'No momento estou sem o cardápio à mão, mas me diz o que você tem vontade de comer que eu vejo pra você! 😊';
    let txt = 'Claro! Olha o que temos:\n';
    for (const c of cats) {
      const prods = produtos.buscarPorCategoria(c.id);
      if (!prods || prods.length === 0) continue;
      txt += `\n*${c.nome}*\n`;
      prods.forEach(p => { txt += `• ${p.nome} — R$ ${p.preco.toFixed(2)}\n`; });
    }
    txt += '\nÉ só me dizer o que você quer que eu já anoto! 😊';
    return txt.trim();
  } catch (e) {
    return 'Me diz o que você tem vontade de comer que eu confiro pra você! 😊';
  }
}

/**
 * Processa a mensagem do cliente de forma local (sem IA externa).
 *
 * @param {string} mensagem - Texto do cliente
 * @param {Object} session - Sessão do cliente (mutável)
 * @returns {{ texto: string, finalizar: boolean, dadosPedido: (Object|null) }}
 */
function responder(mensagem, session) {
  const texto = (mensagem || '').trim();
  const low = normalizar(texto);

  if (!session.carrinho) session.carrinho = [];
  if (session.aguardandoConfirmacao === undefined) session.aguardandoConfirmacao = null;
  if (session.aguardandoEscolha === undefined) session.aguardandoEscolha = null;
  if (!session.faseFinalizacao) session.faseFinalizacao = null;

  const nome = (session.nomeCliente || '').split(' ')[0];
  const trata = nome ? `, ${nome}` : '';

  // ─── FASE DE FINALIZAÇÃO (endereço → pagamento) ───────────
  if (session.faseFinalizacao === 'endereco') {
    session.pedidoAtual = session.pedidoAtual || {};
    session.pedidoAtual.endereco = texto;
    session.faseFinalizacao = 'pagamento';
    const formas = config.formasPagamento.map(f => f.nome).join(', ');
    return R(`Anotei o endereço! E como você prefere pagar? (${formas})`);
  }
  if (session.faseFinalizacao === 'pagamento') {
    session.pedidoAtual = session.pedidoAtual || {};
    session.pedidoAtual.formaPagamento = texto;
    const carrinho = session.carrinho;
    const totalItens = carrinho.reduce((a, i) => a + (i.preco || 0) * (i.quantidade || 1), 0);
    const total = totalItens + config.loja.taxaEntrega;
    const dadosPedido = {
      itens: carrinho.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0, observacao: i.observacao || '' })),
      endereco: session.pedidoAtual.endereco || 'A combinar',
      forma_pagamento: texto,
      total,
    };
    session.faseFinalizacao = null;
    session.aguardandoConfirmacao = null;
    session.aguardandoEscolha = null;
    return {
      texto: `Perfeito${trata}! Seu pedido ficou assim:\n\n${resumoCarrinho(carrinho)}\n_(+ taxa de entrega R$ ${config.loja.taxaEntrega.toFixed(2)})_\n\nPedido confirmado e enviado para a cozinha! 🍳 Chega em torno de ${config.loja.tempoEstimadoMin}-${config.loja.tempoEstimadoMax} min. Obrigado! 🙏`,
      finalizar: true,
      dadosPedido,
    };
  }
  // ─── CLIENTE PEDIU O CARDÁPIO EXPLICITAMENTE ──────────────
  if (RE_CARDAPIO.test(low)) {
    return R(montarCardapio());
  }

  // ─── CLIENTE QUER FECHAR O PEDIDO ─────────────────────────
  if (RE_FINALIZAR.test(low)) {
    // Se havia um item aguardando confirmação e o cliente disse algo
    // afirmativo junto (ex.: "isso, só isso"), adiciona antes de fechar.
    if (session.aguardandoConfirmacao && !RE_NAO.test(low)) {
      const it = session.aguardandoConfirmacao;
      session.carrinho.push({ nome: it.nome, quantidade: it.quantidade || 1, preco: it.preco });
      session.aguardandoConfirmacao = null;
    }
    session.aguardandoEscolha = null;
    if (session.carrinho.length === 0) {
      return R(`Você ainda não escolheu nada${trata}. Me diz o que você gostaria? 😊`);
    }
    session.faseFinalizacao = 'endereco';
    return R(`Show! Seu pedido até agora:\n\n${resumoCarrinho(session.carrinho)}\n\nPra onde eu mando a entrega? (me passa o endereço) 🛵`);
  }

  // ─── CLIENTE QUER REMOVER / TROCAR UM ITEM ────────────────
  if (RE_REMOVER.test(low) && (session.carrinho.length > 0 || session.aguardandoConfirmacao)) {
    // cancelar/limpar o pedido inteiro
    if (/\b(cancel|limp|zer|apag)\w*\b/.test(low) && /\b(tudo|pedido|carrinho|conta|todos|geral)\b/.test(low)) {
      session.carrinho = [];
      session.aguardandoConfirmacao = null;
      session.aguardandoEscolha = null;
      return R(`Cancelei o pedido${trata}. Quando quiser recomeçar é só falar. 😊`);
    }
    const cand = encontrarProdutos(texto);
    const removidos = [];
    if (cand.length > 0) {
      for (let i = session.carrinho.length - 1; i >= 0; i--) {
        const ci = normalizar(session.carrinho[i].nome);
        const bate = cand.some(p => {
          const pn = normalizar(p.nome);
          return pn === ci
            || (session.carrinho[i].id && p.id === session.carrinho[i].id)
            || ci.split(/[^a-z0-9]+/).some(w => w.length >= 3 && !GENERICOS.has(w) && pn.includes(w));
        });
        if (bate) { removidos.push(session.carrinho[i].nome); session.carrinho.splice(i, 1); }
      }
    }
    // pronome ("ela/ele/isso") ou "tira" sem citar produto → remove o último
    if (removidos.length === 0 && session.carrinho.length > 0 &&
        (/\b(ela|ele|isso|esse|essa|ultim[oa]|últim[oa])\b/.test(low) || cand.length === 0)) {
      removidos.push(session.carrinho[session.carrinho.length - 1].nome);
      session.carrinho.pop();
    }
    if (removidos.length > 0) {
      // possível item para adicionar logo após remover (ex.: "tira a coca e poe guaraná")
      const removidosNorm = removidos.map(normalizar);
      const addCands = cand.filter(p => !removidosNorm.includes(normalizar(p.nome)) &&
        !session.carrinho.some(ci => normalizar(ci.nome) === normalizar(p.nome)));
      if (RE_ADD.test(low) && addCands.length >= 1) {
        if (addCands.length === 1) {
          const p = addCands[0];
          session.aguardandoConfirmacao = { id: p.id, nome: p.nome, preco: p.preco, quantidade: extrairQuantidade(low) };
          return R(`Tirei ${removidos.join(', ')} do pedido! E você quer o *${p.nome}* (R$ ${p.preco.toFixed(2)})? 😊`);
        }
        session.aguardandoEscolha = addCands;
        const nomes = addCands.slice(0, 4).map(p => `*${p.nome}* (R$ ${p.preco.toFixed(2)})`).join(' ou ');
        return R(`Tirei ${removidos.join(', ')}! E você quer ${nomes}? Qual deles? 😊`);
      }
      const resumo = session.carrinho.length > 0 ? `\n\nSeu pedido agora:\n${resumoCarrinho(session.carrinho)}` : '';
      return R(`Pronto, tirei ${removidos.join(', ')} do pedido! 😊 Mais alguma coisa?${resumo}`);
    }
    // nada removido: pode ser observação ("tira a cebola") → cai para o bloco abaixo
  }

  // ─── OBSERVAÇÃO / PERSONALIZAÇÃO DE UM ITEM ───────────────
  if (RE_COOK.test(low) && (session.carrinho.length > 0 || session.aguardandoConfirmacao)) {
    if (session.aguardandoConfirmacao) {
      const it = session.aguardandoConfirmacao;
      const qtd = it.quantidade || 1;
      session.carrinho.push({ id: it.id, nome: it.nome, quantidade: qtd, preco: it.preco, observacao: texto });
      session.aguardandoConfirmacao = null;
      return R(`Anotado, ${qtd}x ${it.nome} _(${texto})_! 😊 Mais alguma coisa?`);
    }
    let idx = -1;
    for (let i = session.carrinho.length - 1; i >= 0; i--) {
      const words = normalizar(session.carrinho[i].nome).split(/[^a-z0-9]+/).filter(w => w.length >= 3);
      if (words.some(w => low.includes(w))) { idx = i; break; }
    }
    if (idx === -1) idx = session.carrinho.length - 1; // padrão: último item pedido
    const item = session.carrinho[idx];
    item.observacao = item.observacao ? `${item.observacao}; ${texto}` : texto;
    return R(`Beleza! Anotei pro *${item.nome}*: _${texto}_. 😊 Mais alguma coisa?`);
  }

  // ─── AGUARDANDO CONFIRMAÇÃO DE UM ITEM (sim/não) ──────────
  if (session.aguardandoConfirmacao) {
    const item = session.aguardandoConfirmacao;
    if ((RE_SIM.test(low) || ehAfirmacaoCurta(low)) && !RE_NAO.test(low)) {
      const qtd = item.quantidade || extrairQuantidade(low);
      session.carrinho.push({ id: item.id, nome: item.nome, quantidade: qtd, preco: item.preco });
      session.aguardandoConfirmacao = null;
      return R(`Anotado, ${qtd}x ${item.nome}! 😊 Mais alguma coisa?`);
    }
    if (RE_NAO.test(low)) {
      session.aguardandoConfirmacao = null;
      const outros = encontrarProdutos(texto);
      if (outros.length === 0) return R(`Sem problema! Me diz o que você gostaria então. 😊`);
      // se ele já citou outro item, cai no fluxo de busca abaixo
    } else if (!RE_SIM.test(low) && !ehAfirmacaoCurta(low)) {
      const outros = encontrarProdutos(texto);
      if (outros.length === 0) {
        return R(`Só pra confirmar: você quer o *${item.nome}* (R$ ${item.preco.toFixed(2)})? 😊`);
      }
      session.aguardandoConfirmacao = null; // ele citou outra coisa
    }
  }

  // ─── AGUARDANDO ESCOLHA ENTRE VÁRIAS OPÇÕES ───────────────
  if (session.aguardandoEscolha && session.aguardandoEscolha.length > 0) {
    const escolhido = session.aguardandoEscolha.find(p => {
      const pn = normalizar(p.nome);
      const pwords = pn.split(/[^a-z0-9]+/).filter(w => w.length >= 3);
      return low.includes(pn) || pwords.some(w => new RegExp(`\\b${w}\\b`).test(low));
    });
    if (escolhido) {
      let qtd = extrairQuantidade(low);
      if (qtd === 1 && session.aguardandoEscolhaQtd) qtd = session.aguardandoEscolhaQtd;
      session.carrinho.push({ id: escolhido.id, nome: escolhido.nome, quantidade: qtd, preco: escolhido.preco });
      session.aguardandoEscolha = null;
      session.aguardandoEscolhaQtd = null;
      session.aguardandoConfirmacao = null;
      return R(`Anotado, ${qtd}x ${escolhido.nome}! 😊 Mais alguma coisa?`);
    }
    // Se disse só "sim/e" genérico (sem indicar qual), pede pra especificar
    if ((RE_SIM.test(low) || ehAfirmacaoCurta(low)) && !RE_FINALIZAR.test(low)) {
      const nomes = session.aguardandoEscolha.slice(0, 4).map(p => `*${p.nome}*`).join(' ou ');
      return R(`Qual deles${trata}: ${nomes}? 😊`);
    }
    session.aguardandoEscolha = null; // não identificou; segue fluxo normal
  }

  // ─── MÚLTIPLOS ITENS NA MESMA MENSAGEM ────────────────────
  const lote = segmentarPedido(texto);
  if (lote) {
    lote.resolvidos.forEach(it => session.carrinho.push({
      id: it.produto.id, nome: it.produto.nome, quantidade: it.quantidade, preco: it.produto.preco,
    }));
    const addedDesc = lote.resolvidos.map(it => `${it.quantidade}x ${it.produto.nome}`).join(', ');
    if (lote.ambiguas.length > 0) {
      const amb = lote.ambiguas[0];
      session.aguardandoEscolha = amb.opcoes;
      session.aguardandoEscolhaQtd = amb.quantidade || 1;
      session.aguardandoConfirmacao = null;
      const nomes = amb.opcoes.slice(0, 4).map(p => `*${p.nome}* (R$ ${p.preco.toFixed(2)})`).join(' ou ');
      const prefix = addedDesc ? `Anotado: ${addedDesc}! ` : '';
      return R(`${prefix}E o outro, você quer ${nomes}? Qual deles? 😊`);
    }
    session.aguardandoConfirmacao = null;
    session.aguardandoEscolha = null;
    return R(`Anotado: ${addedDesc}! 😊 Mais alguma coisa?`);
  }

  // ─── BUSCA POR ITENS NO QUE O CLIENTE FALOU ───────────────
  const encontrados = encontrarProdutos(texto);

  if (encontrados.length === 1) {
    const p = encontrados[0];
    const qtd = extrairQuantidade(low);
    session.aguardandoConfirmacao = { id: p.id, nome: p.nome, preco: p.preco, quantidade: qtd };
    const qtdTxt = qtd > 1 ? `${qtd}x ` : '';
    return R(`Você quer dizer o *${qtdTxt}${p.nome}* (R$ ${p.preco.toFixed(2)})? 😊`);
  }
  if (encontrados.length > 1) {
    session.aguardandoEscolha = encontrados;
    const nomes = encontrados.slice(0, 4).map(p => `*${p.nome}* (R$ ${p.preco.toFixed(2)})`).join(' ou ');
    return R(`Você quer dizer ${nomes}? Qual deles? 😊`);
  }

  // ─── NENHUM ITEM RECONHECIDO: CONVERSA NATURAL ────────────
  if (RE_AGRADECE.test(low)) return R(`Imagina${trata}! Precisando é só chamar. 😊`);
  if (RE_SAUDACAO.test(low)) return R(`${saudacaoHora()}${trata}! Como posso te ajudar? 😊`);

  // Fallback final: passivo, sem oferecer cardápio nem mandar digitar
  return R(`Pode me dizer o que você tem vontade de pedir que eu vejo pra você${trata}. 😊`);
}

// helper para resposta simples
function R(texto) {
  return { texto, finalizar: false, dadosPedido: null };
}

module.exports = { responder, procurarItens };
