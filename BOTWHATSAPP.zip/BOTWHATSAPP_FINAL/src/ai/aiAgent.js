/**
 * ============================================================
 *  AGENTE DE IA CONVERSACIONAL (function-calling)  🤖
 * ============================================================
 * Em vez de seguir um roteiro fixo, a IA ENTENDE o que o cliente
 * quer a qualquer momento e DECIDE as ações chamando ferramentas
 * (tools). O código executa as ações de forma determinística
 * (preços reais do cardápio, taxa por bairro, etc.) e a IA apenas
 * conversa de forma natural e humana.
 *
 * Requer um endpoint compatível com a API OpenAI (chat/completions
 * com suporte a "tools"). Configure a chave no painel (aba
 * Configurações → IA) ou via variável de ambiente OPENAI_API_KEY.
 * Se não houver chave, o sistema cai no motor local (fallback).
 * ============================================================
 */

const axios = require('axios');
const config = require('../config');
const { produtos, categorias, bairros } = require('../database/db');
const { buscarProdutosNoCardapio } = require('./produtoSearch');
const {
  interpretarPagamento,
  pagamentoTemPix,
  textoAguardandoPix,
  chavesAceitas,
} = require('./pagamento');
const { INSTRUCOES_PERSONA_CEARA } = require('./giriasCeara');

const TIMEOUT_MS = 20000;
const MAX_ITERACOES = 6;   // limite de rodadas de tool-calls por mensagem
const MAX_HISTORICO = 16;  // mensagens mantidas por sessão

// ─── CONFIG DINÂMICA (lê do config cifrado / .env) ───────────
function cfgIA() {
  const ai = (config.ai) || {};
  const o = ai.openai || {};
  return {
    habilitado: ai.habilitado !== false,
    apiKey: o.apiKey || process.env.OPENAI_API_KEY || '',
    apiBase: (o.apiBase || process.env.OPENAI_API_BASE || 'https://api.openai.com/v1').replace(/\/$/, ''),
    modelo: o.modelo || process.env.OPENAI_MODEL || 'gpt-4o-mini',
    temperatura: o.temperatura != null ? o.temperatura : 0.6,
    personaNome: (ai.persona && ai.persona.nome) || 'Lara',
  };
}

/** Diz se o agente de IA pode ser usado (habilitado + chave presente). */
function disponivel() {
  const c = cfgIA();
  return !!(c.habilitado && c.apiKey);
}

// ─── UTILITÁRIOS ─────────────────────────────────────────────
function norm(t) {
  return (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}
function brl(v) { return `R$ ${(Number(v) || 0).toFixed(2)}`; }

function totalCarrinho(session) {
  return (session.carrinho || []).reduce((a, i) => a + (i.preco || 0) * (i.quantidade || 1), 0);
}
function taxaAtual(session) {
  const pa = session.pedidoAtual || {};
  return pa.taxaEntrega != null ? Number(pa.taxaEntrega) : Number(config.loja.taxaEntrega) || 0;
}
function resumoCarrinho(session) {
  const c = session.carrinho || [];
  if (!c.length) return { itens: [], subtotal: 0 };
  return {
    itens: c.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0, subtotal: Number(((i.preco || 0) * (i.quantidade || 1)).toFixed(2)), observacao: i.observacao || '' })),
    subtotal: Number(totalCarrinho(session).toFixed(2)),
  };
}

// Acha um produto único a partir de um nome livre
function acharProduto(nome) {
  const res = buscarProdutosNoCardapio(nome) || [];
  if (!res.length) return { status: 'nenhum' };
  const alvo = norm(nome);
  const exato = res.find(p => norm(p.nome) === alvo);
  if (exato) return { status: 'ok', produto: exato };
  if (res.length === 1) return { status: 'ok', produto: res[0] };
  return { status: 'varios', opcoes: res };
}

function acharBairro(texto) {
  const t = norm(texto);
  if (!t) return null;
  let lista = [];
  try { lista = bairros.listarAtivos() || []; } catch (e) { lista = []; }
  let melhor = null;
  for (const b of lista) {
    const bn = norm(b.nome);
    if (!bn) continue;
    if (t === bn) return b;
    if (t.includes(bn) || bn.includes(t)) {
      if (!melhor || bn.length > norm(melhor.nome).length) melhor = b;
    }
  }
  return melhor;
}

// ─── DEFINIÇÃO DAS FERRAMENTAS (tools) ───────────────────────
const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'ver_cardapio',
      description: 'Lista os produtos do cardápio (opcionalmente filtrando por um termo/categoria). Use quando o cliente pedir o cardápio ou perguntar o que tem.',
      parameters: {
        type: 'object',
        properties: { termo: { type: 'string', description: 'Filtro opcional (ex.: "bebidas", "burguer")' } },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'adicionar_item',
      description: 'Adiciona um item ao pedido do cliente. Informe o nome do produto e a quantidade.',
      parameters: {
        type: 'object',
        properties: {
          nome: { type: 'string', description: 'Nome do produto (como o cliente falou)' },
          quantidade: { type: 'integer', description: 'Quantidade (padrão 1)' },
          observacao: { type: 'string', description: 'Observação opcional (ex.: "sem cebola")' },
        },
        required: ['nome'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'remover_item',
      description: 'Remove um item do pedido pelo nome.',
      parameters: { type: 'object', properties: { nome: { type: 'string' } }, required: ['nome'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'ver_pedido',
      description: 'Retorna os itens atuais do pedido com subtotal, taxa de entrega e total.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'definir_entrega',
      description: 'Registra os dados de entrega. Pode enviar endereço, ponto de referência e/ou bairro. A taxa é calculada pelo bairro.',
      parameters: {
        type: 'object',
        properties: {
          endereco: { type: 'string' },
          referencia: { type: 'string' },
          bairro: { type: 'string' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'definir_pagamento',
      description: 'Registra a forma de pagamento. Aceita uma ou mais formas (ex.: "pix", "metade no pix e metade em dinheiro"). Só aceita as formas oferecidas pela loja.',
      parameters: { type: 'object', properties: { texto: { type: 'string' } }, required: ['texto'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'finalizar_pedido',
      description: 'Fecha o pedido. Só funcione quando houver itens, endereço e forma de pagamento definidos.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'info_loja',
      description: 'Retorna informações da loja: horário, endereço, taxa, formas de pagamento, chave PIX, tempo de entrega.',
      parameters: { type: 'object', properties: {} },
    },
  },
];

// ─── EXECUTORES DAS FERRAMENTAS ──────────────────────────────
// Cada um recebe (args, session) e retorna um objeto (será serializado
// como resultado da tool para a IA). Alguns setam session.__finalizar.
const EXECUTORES = {
  ver_cardapio(args, session) {
    const termo = args && args.termo;
    let lista;
    if (termo) {
      lista = buscarProdutosNoCardapio(termo) || [];
    } else {
      lista = (produtos.listar() || []);
    }
    const itens = lista.slice(0, 30).map(p => ({ nome: p.nome, preco: Number(p.preco) || 0, categoria: p.categoria_nome }));
    return { itens };
  },

  adicionar_item(args, session) {
    const nome = args && args.nome;
    const qtd = Math.max(1, parseInt(args && args.quantidade) || 1);
    const obs = (args && args.observacao) || '';
    if (!nome) return { ok: false, erro: 'informe o nome do item' };
    const r = acharProduto(nome);
    if (r.status === 'nenhum') return { ok: false, motivo: 'nao_encontrado', mensagem: `Não encontrei "${nome}" no cardápio.` };
    if (r.status === 'varios') {
      return { ok: false, motivo: 'ambiguo', opcoes: r.opcoes.map(p => ({ nome: p.nome, preco: Number(p.preco) || 0 })) };
    }
    const p = r.produto;
    session.carrinho = session.carrinho || [];
    session.carrinho.push({ id: p.id, nome: p.nome, quantidade: qtd, preco: Number(p.preco) || 0, observacao: obs });
    return { ok: true, adicionado: { nome: p.nome, quantidade: qtd, preco: Number(p.preco) || 0 }, pedido: resumoCarrinho(session) };
  },

  remover_item(args, session) {
    const nome = norm(args && args.nome);
    session.carrinho = session.carrinho || [];
    const idx = session.carrinho.findIndex(i => norm(i.nome).includes(nome) || nome.includes(norm(i.nome)));
    if (idx === -1) return { ok: false, motivo: 'nao_esta_no_pedido' };
    const removido = session.carrinho.splice(idx, 1)[0];
    return { ok: true, removido: removido.nome, pedido: resumoCarrinho(session) };
  },

  ver_pedido(args, session) {
    const r = resumoCarrinho(session);
    const taxa = taxaAtual(session);
    return {
      itens: r.itens,
      subtotal: r.subtotal,
      taxa_entrega: Number(taxa.toFixed(2)),
      total: Number((r.subtotal + taxa).toFixed(2)),
      bairro: (session.pedidoAtual && session.pedidoAtual.bairro) || null,
    };
  },

  definir_entrega(args, session) {
    const pa = session.pedidoAtual = session.pedidoAtual || {};
    if (args && args.endereco) pa.endereco = args.endereco;
    if (args && args.referencia != null) { pa.referencia = args.referencia; pa.referenciaColetada = true; }

    let lista = [];
    try { lista = bairros.listarAtivos() || []; } catch (e) { lista = []; }

    // Bairro informado explicitamente OU detectado no endereço
    let b = null;
    if (args && args.bairro) b = acharBairro(args.bairro);
    if (!b && args && args.endereco) b = acharBairro(`${args.endereco} ${args.referencia || ''}`);

    if (lista.length === 0) {
      pa.taxaEntrega = Number(config.loja.taxaEntrega) || 0;
      pa.bairro = pa.bairro || '';
    } else if (lista.length === 1) {
      pa.taxaEntrega = Number(lista[0].taxa) || 0;
      pa.bairro = lista[0].nome;
    } else if (b) {
      pa.taxaEntrega = Number(b.taxa) || 0;
      pa.bairro = b.nome;
    }

    const precisaBairro = lista.length > 1 && !pa.bairro;
    return {
      ok: true,
      endereco: pa.endereco || null,
      referencia: pa.referencia || null,
      bairro: pa.bairro || null,
      taxa_entrega: pa.taxaEntrega != null ? Number(pa.taxaEntrega) : null,
      precisa_perguntar_bairro: precisaBairro,
      bairros_disponiveis: precisaBairro ? lista.map(x => x.nome) : undefined,
    };
  },

  definir_pagamento(args, session) {
    const texto = (args && args.texto) || '';
    const pa = session.pedidoAtual = session.pedidoAtual || {};
    const total = Number((totalCarrinho(session) + taxaAtual(session)).toFixed(2));
    const aceitas = chavesAceitas(config.formasPagamento);
    const pg = interpretarPagamento(texto, total, aceitas.length ? aceitas : null);
    if (!pg.reconhecido) {
      return { ok: false, motivo: 'forma_invalida', formas_aceitas: (config.formasPagamento || []).map(f => f.nome) };
    }
    pa.formaPagamento = pg.descricao;
    return { ok: true, forma_pagamento: pg.descricao, tem_pix: pagamentoTemPix(pg.descricao) };
  },

  finalizar_pedido(args, session) {
    const pa = session.pedidoAtual = session.pedidoAtual || {};
    if (!session.carrinho || session.carrinho.length === 0) return { ok: false, motivo: 'carrinho_vazio' };
    if (!pa.endereco) return { ok: false, motivo: 'falta_endereco' };
    if (!pa.formaPagamento) return { ok: false, motivo: 'falta_pagamento' };

    const subtotal = Number(totalCarrinho(session).toFixed(2));
    const taxa = taxaAtual(session);
    const total = Number((subtotal + taxa).toFixed(2));
    const dadosPedido = {
      itens: session.carrinho.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0, observacao: i.observacao || '' })),
      endereco: pa.endereco,
      referencia: pa.referencia || '',
      bairro: pa.bairro || '',
      taxa_entrega: taxa,
      forma_pagamento: pa.formaPagamento,
      total,
    };
    // Sinaliza para o handler salvar o pedido
    session.__finalizar = dadosPedido;

    const resp = { ok: true, total, tem_pix: pagamentoTemPix(pa.formaPagamento) };
    if (resp.tem_pix) {
      resp.aviso_pix = textoAguardandoPix(config.pix, total);
    }
    return resp;
  },

  info_loja() {
    const l = config.loja || {};
    return {
      nome: l.nome,
      endereco: l.endereco,
      telefone: l.telefone,
      horario: `${l.horarioAbertura} às ${l.horarioFechamento}`,
      tempo_entrega: `${l.tempoEstimadoMin} a ${l.tempoEstimadoMax} min`,
      taxa_padrao: Number(l.taxaEntrega) || 0,
      formas_pagamento: (config.formasPagamento || []).map(f => f.nome),
      pix: (config.pix && config.pix.chave) || null,
    };
  },
};

// ─── PROMPT DO SISTEMA ───────────────────────────────────────
function montarSystemPrompt(nomeCliente) {
  const c = cfgIA();
  const l = config.loja || {};
  let bairrosTxt = '';
  try {
    const lb = bairros.listarAtivos() || [];
    if (lb.length === 1) bairrosTxt = `Só atende o bairro "${lb[0].nome}" (taxa ${brl(lb[0].taxa)}). NÃO pergunte o bairro.`;
    else if (lb.length > 1) bairrosTxt = `Bairros atendidos e taxas: ${lb.map(b => `${b.nome} (${brl(b.taxa)})`).join(', ')}. Tente identificar o bairro pelo endereço e só confirme.`;
    else bairrosTxt = `Taxa de entrega padrão: ${brl(l.taxaEntrega)}.`;
  } catch (e) { /* ignore */ }

  return `Você é a ${c.personaNome}, atendente virtual do restaurante "${l.nome}" no WhatsApp.
Seu objetivo é conversar de forma NATURAL e HUMANA e anotar o pedido do cliente, fazendo o que ele pedir a qualquer momento (adicionar/remover itens, mudar endereço, tirar dúvidas, fechar o pedido).

REGRAS IMPORTANTES:
- Use SEMPRE as ferramentas (tools) para agir: adicionar_item, remover_item, ver_pedido, definir_entrega, definir_pagamento, finalizar_pedido, ver_cardapio, info_loja. NUNCA invente preços, itens do cardápio ou totais — pegue das ferramentas.
- O cliente pode falar de tudo em qualquer ordem. Entenda a intenção e aja. Se ele adicionar itens no meio do fechamento, adicione normalmente.
- Para fechar: precisa ter itens, endereço e forma de pagamento. Peça o que faltar, de forma leve.
- Pagamento: só aceite as formas oferecidas pela loja (a ferramenta valida). Aceita dividido (ex.: metade pix, metade dinheiro).
- ${bairrosTxt}
- Se uma ferramenta retornar erro/ambiguidade (ex.: item ambíguo), pergunte ao cliente de forma natural com as opções.
- Ao finalizar com PIX, informe que estamos aguardando o PIX (a ferramenta te dá o texto).
- Respostas curtas, calorosas e diretas, como um bom atendente. Cliente: ${nomeCliente || 'sem nome'}.
${INSTRUCOES_PERSONA_CEARA}`;
}

// ─── CHAMADA AO LLM ──────────────────────────────────────────
async function chamarLLM(messages) {
  const c = cfgIA();
  const resp = await axios.post(
    `${c.apiBase}/chat/completions`,
    { model: c.modelo, messages, tools: TOOLS, tool_choice: 'auto', temperature: c.temperatura },
    { headers: { Authorization: `Bearer ${c.apiKey}`, 'Content-Type': 'application/json' }, timeout: TIMEOUT_MS }
  );
  return resp.data && resp.data.choices && resp.data.choices[0] && resp.data.choices[0].message;
}

/**
 * Conversa com o agente. Executa as ferramentas que a IA decidir e
 * devolve a resposta final em texto.
 *
 * @returns {Promise<{texto:string, finalizar:boolean, dadosPedido:(object|null)}>}
 */
async function conversar(mensagem, session, ctx = {}) {
  session.msgsAgent = session.msgsAgent || [];
  session.carrinho = session.carrinho || [];
  session.__finalizar = null;

  // Histórico (sem system; ele é remontado a cada chamada com o estado atual)
  session.msgsAgent.push({ role: 'user', content: mensagem });

  const system = { role: 'system', content: montarSystemPrompt(ctx.nomeCliente) };

  let textoFinal = '';
  for (let i = 0; i < MAX_ITERACOES; i++) {
    const messages = [system, ...session.msgsAgent];
    const msg = await chamarLLM(messages);
    if (!msg) break;

    // A IA quer chamar ferramentas?
    if (msg.tool_calls && msg.tool_calls.length) {
      session.msgsAgent.push({ role: 'assistant', content: msg.content || '', tool_calls: msg.tool_calls });
      for (const tc of msg.tool_calls) {
        const nomeFn = tc.function && tc.function.name;
        let args = {};
        try { args = tc.function && tc.function.arguments ? JSON.parse(tc.function.arguments) : {}; } catch (e) { args = {}; }
        let resultado;
        try {
          const exec = EXECUTORES[nomeFn];
          resultado = exec ? exec(args, session) : { erro: `ferramenta desconhecida: ${nomeFn}` };
        } catch (e) {
          resultado = { erro: e.message };
        }
        session.msgsAgent.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(resultado) });
      }
      continue; // volta ao modelo com os resultados das ferramentas
    }

    // Resposta final em texto
    textoFinal = (msg.content || '').trim();
    session.msgsAgent.push({ role: 'assistant', content: textoFinal });
    break;
  }

  // Limita o histórico
  if (session.msgsAgent.length > MAX_HISTORICO) {
    session.msgsAgent = session.msgsAgent.slice(-MAX_HISTORICO);
  }

  const dadosPedido = session.__finalizar || null;
  if (dadosPedido) session.__finalizar = null;

  if (!textoFinal) {
    textoFinal = dadosPedido
      ? 'Pedido registrado! 🍳'
      : 'Desculpa, pode repetir? 😊';
  }

  return { texto: textoFinal, finalizar: !!dadosPedido, dadosPedido };
}

module.exports = { disponivel, conversar, TOOLS, EXECUTORES, cfgIA };
