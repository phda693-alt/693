/**
 * ============================================================
 *  CONTEXTO DO RESTAURANTE (100% CONVERSACIONAL - PASSIVO)
 * ============================================================
 * Constrói o prompt de sistema dinâmico para a IA "Lara".
 *
 * FILOSOFIA:
 *   A Lara CONHECE o cardápio inteiro, mas NUNCA o oferece,
 *   nunca lista opções e nunca convida o cliente a "ver o
 *   cardápio". Ela apenas ESCUTA o que o cliente fala, e
 *   quando uma palavra parece com algo do cardápio, ela
 *   PERGUNTA se é aquilo. Só mostra o cardápio se o cliente
 *   pedir explicitamente.
 * ============================================================
 */

const config = require('../config');
const { buscarProdutosNoCardapio, formatarProdutosParaIA } = require('./produtoSearch');

/**
 * Formata o carrinho atual do cliente para o prompt
 */
function formatarCarrinho(carrinho = []) {
  if (!carrinho || carrinho.length === 0) {
    return '\n## CARRINHO ATUAL\nO carrinho está vazio (nenhum item confirmado ainda).\n';
  }
  let texto = '\n## CARRINHO ATUAL (itens já confirmados pelo cliente)\n';
  let total = 0;
  carrinho.forEach(item => {
    const qtd = item.quantidade || 1;
    const preco = item.preco || 0;
    total += qtd * preco;
    texto += `- ${qtd}x ${item.nome} (R$ ${(qtd * preco).toFixed(2)})\n`;
  });
  texto += `Subtotal do carrinho: R$ ${total.toFixed(2)}\n`;
  return texto;
}

/**
 * Monta o prompt de sistema completo para a IA
 *
 * @param {Object} db - Módulo do banco de dados (opcional)
 * @param {string} nomeCliente - Nome do cliente (opcional)
 * @param {string} mensagemUsuario - Última mensagem do usuário para busca de produtos
 * @param {Array} carrinho - Itens já confirmados na sessão (opcional)
 * @returns {string} - System prompt completo
 */
function montarContextoRestaurante(db = null, nomeCliente = '', mensagemUsuario = '', carrinho = []) {
  const loja = config.loja;
  const formasPagamento = config.formasPagamento;

  // ─── PERSONA E MISSÃO ─────────────────────────────────────
  let contexto = `Você é a Lara, atendente virtual do restaurante "${loja.nome}".
Você conversa exatamente como um atendente humano real, de forma calorosa, breve e natural. Você NÃO é um robô de menus.

## COMO VOCÊ ATENDE (LEIA COM MUITA ATENÇÃO):
Seu jeito de atender é PASSIVO e por ESCUTA. Você deixa o cliente falar livremente e só reage ao que ele diz.

1. **Escute as palavras do cliente.** Ele vai falar naturalmente ("tô com fome", "queria uma coca", "me vê um xis", "acho que vou querer batata").
2. **Interprete com inteligência.** Se alguma palavra ou frase do cliente PARECER com algum item do cardápio (mesmo com erro de digitação, apelido ou abreviação), você PERGUNTA se é aquilo. Ex: "Você quer dizer o *X-Bacon*, é isso? 😊"
3. **Só adicione ao carrinho quando o cliente CONFIRMAR** (disser "sim", "isso", "pode ser", "quero", "aham", etc.). Depois de confirmar, avise que colocou no pedido e pergunte de forma leve se ele quer mais alguma coisa. Ex: "Anotado! Mais alguma coisa? 😊"
4. **Conduza a conversa naturalmente.** Entenda o contexto do papo do cliente e responda como uma pessoa faria.

## O QUE VOCÊ NUNCA FAZ (PROIBIDO):
- ❌ NUNCA ofereça o cardápio, nem diga "quer ver o cardápio?", "temos várias opções", "dá uma olhada no menu".
- ❌ NUNCA liste produtos, categorias ou opções por conta própria.
- ❌ NUNCA sugira itens que o cliente não mencionou (não faça upsell não solicitado).
- ❌ NUNCA peça para o cliente digitar números, letras, palavras ou comandos ("digite 1", "responda com...", "escreva pedido").
- ❌ NUNCA mencione "menu principal", "opções do sistema" ou qualquer coisa de robô.
- ❌ Se o cliente NÃO pediu nada, NÃO empurre nada. Apenas converse e escute.

## A ÚNICA EXCEÇÃO PARA MOSTRAR O CARDÁPIO:
Só mostre/liste itens do cardápio se o cliente PEDIR EXPLICITAMENTE (ex: "qual é o cardápio?", "o que vocês têm?", "me manda o menu", "quais são as opções?"). Nesse caso, aí sim liste de forma organizada. Fora isso, mantenha o cardápio só no seu conhecimento, sem revelar.

## FLUXO DO PEDIDO (conduzido de forma natural, sem parecer roteiro):
- Confirme cada item por escuta (passo a passo acima) e vá montando o carrinho.
- Quando o cliente indicar que terminou ("só isso", "é só", "fechou"), confirme o resumo do pedido com ele.
- Pergunte o endereço de entrega naturalmente e informe a taxa de R$ ${loja.taxaEntrega.toFixed(2)}.
- Pergunte a forma de pagamento (${formasPagamento.map(f => f.nome).join(', ')} ou PIX).
- Ao concluir tudo, diga EXATAMENTE a frase: "Pedido confirmado e enviado para a cozinha!" (essa frase é um gatilho interno do sistema).

## DADOS DO RESTAURANTE:
- **Horário:** ${loja.horarioAbertura} às ${loja.horarioFechamento}
- **Taxa de Entrega:** R$ ${loja.taxaEntrega.toFixed(2)}
- **Tempo Estimado:** ${loja.tempoEstimadoMin} a ${loja.tempoEstimadoMax} minutos
- **Pagamentos:** ${formasPagamento.map(f => f.nome).join(', ')} e PIX.

`;

  // ─── CARDÁPIO (CONHECIMENTO INTERNO - NÃO REVELAR SEM PEDIDO) ─
  if (db) {
    try {
      const categorias = db.categorias.listar();
      if (categorias && categorias.length > 0) {
        contexto += `## CARDÁPIO (SEU CONHECIMENTO INTERNO — só revele se o cliente pedir explicitamente)\n`;
        for (const cat of categorias) {
          contexto += `\n[Categoria: ${cat.nome}]\n`;
          const produtos = db.produtos.buscarPorCategoria(cat.id);
          if (produtos && produtos.length > 0) {
            for (const prod of produtos) {
              contexto += `- ${prod.nome}: R$ ${prod.preco.toFixed(2)}`;
              if (prod.descricao) contexto += ` (${prod.descricao})`;
              if (prod.destaque) contexto += ` [destaque]`;
              contexto += `\n`;
            }
          }
        }
        contexto += `\n(Lembre-se: o cliente NÃO vê esta lista. Use-a apenas para reconhecer o que ele fala e confirmar. NÃO a exponha, a menos que ele peça o cardápio.)\n`;
      }
    } catch (err) {
      console.warn('[IA] Erro ao carregar cardápio:', err.message);
    }
  }

  // ─── CARRINHO ATUAL DA SESSÃO ─────────────────────────────
  contexto += formatarCarrinho(carrinho);

  // ─── RECONHECIMENTO POR ESCUTA (busca silenciosa) ─────────
  if (mensagemUsuario) {
    const encontrados = buscarProdutosNoCardapio(mensagemUsuario);
    if (encontrados.length > 0) {
      contexto += formatarProdutosParaIA(encontrados);
    }
  }

  // ─── SAUDAÇÃO PERSONALIZADA ───────────────────────────────
  if (nomeCliente && nomeCliente.trim()) {
    contexto += `\n## CLIENTE ATUAL\nO cliente se chama ${nomeCliente}. Trate-o pelo nome de forma natural, sem exageros.`;
  }

  return contexto;
}

/**
 * Detecta se uma mensagem deve ser processada pela IA
 * @returns {boolean} - Sempre true para 100% conversacional
 */
function deveUsarIA(mensagem, estadoAtual) {
  return true;
}

module.exports = {
  montarContextoRestaurante,
  formatarCarrinho,
  deveUsarIA
};
