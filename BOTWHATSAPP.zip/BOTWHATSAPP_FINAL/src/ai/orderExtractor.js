/**
 * ============================================================
 *  EXTRATOR DE PEDIDOS + CARRINHO (CONVERSACIONAL)
 * ============================================================
 * Analisa o histórico da conversa para:
 *   1. Manter o CARRINHO atualizado a cada turno (itens que o
 *      cliente já confirmou por escuta).
 *   2. Detectar quando o pedido foi FINALIZADO e extrair os
 *      dados estruturados para salvar no banco de dados.
 * ============================================================
 */

const { pedidos, clientes, bairros } = require('../database/db');
const { buscarProdutosNoCardapio } = require('./produtoSearch');
const { obterRespostaIA } = require('./aiEngine');
const { pagamentoTemPix } = require('./pagamento');
const config = require('../config');

/**
 * Resolve a taxa de entrega e o bairro de um pedido.
 *  - Se o motor local já calculou (dadosPedido.taxa_entrega), respeita.
 *  - Senão (via IA externa), tenta casar um bairro cadastrado pelo
 *    nome informado ou pelo endereço; se houver só um bairro, usa ele.
 *  - Fallback: taxa padrão da loja.
 */
function resolverEntrega(dadosPedido) {
  if (dadosPedido.taxa_entrega != null && dadosPedido.taxa_entrega !== '') {
    return { taxa: Number(dadosPedido.taxa_entrega) || 0, bairro: dadosPedido.bairro || '' };
  }

  const norm = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  let lista = [];
  try { lista = bairros.listarAtivos() || []; } catch (e) { lista = []; }

  if (lista.length > 0) {
    const alvo = norm(`${dadosPedido.bairro || ''} ${dadosPedido.endereco || ''}`);
    let achou = null;
    for (const b of lista) {
      const bn = norm(b.nome);
      if (bn && alvo.includes(bn) && (!achou || bn.length > norm(achou.nome).length)) achou = b;
    }
    if (achou) return { taxa: Number(achou.taxa) || 0, bairro: achou.nome };
    if (lista.length === 1) return { taxa: Number(lista[0].taxa) || 0, bairro: lista[0].nome };
  }

  return { taxa: Number((config.loja && config.loja.taxaEntrega) || 0), bairro: dadosPedido.bairro || '' };
}

// Frase-gatilho que a Lara diz ao finalizar (definida no system prompt)
const GATILHO_FINALIZACAO = 'enviado para a cozinha';

/**
 * Sincroniza o carrinho a partir do histórico da conversa.
 * Retorna a lista de itens que o cliente JÁ confirmou até agora.
 *
 * Estratégia: usa a IA para extrair apenas os itens confirmados,
 * validando cada um contra o cardápio real (para pegar o preço).
 *
 * @param {Array} historico - Histórico completo da conversa
 * @returns {Promise<Array|null>} - [{nome, quantidade, preco}] ou null
 */
async function sincronizarCarrinho(historico) {
  if (!historico || historico.length === 0) return null;

  const promptCarrinho = `
Você é um extrator de dados. Analise a conversa e devolva APENAS os itens que o
CLIENTE JÁ CONFIRMOU explicitamente que quer (disse "sim", "isso", "quero", "pode ser" etc.).
NÃO inclua itens que a atendente apenas perguntou e o cliente ainda não confirmou.
NÃO invente itens. Se nada foi confirmado, responda exatamente: NULL

Responda somente com JSON no formato:
{"itens":[{"nome":"Nome do item","quantidade":1}]}

CONVERSA:
${historico.map(m => `${m.role === 'user' ? 'CLIENTE' : 'ATENDENTE'}: ${m.content}`).join('\n')}
`;

  try {
    const resposta = await obterRespostaIA(promptCarrinho, [], 'Você é um extrator de dados JSON preciso. Responda só com JSON ou NULL.');
    if (!resposta || resposta.toUpperCase().includes('NULL')) return [];

    const jsonMatch = resposta.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return [];

    const dados = JSON.parse(jsonMatch[0]);
    if (!dados.itens || !Array.isArray(dados.itens)) return [];

    // Validar cada item contra o cardápio real para obter preço correto
    const carrinho = [];
    for (const item of dados.itens) {
      if (!item.nome) continue;
      const matches = buscarProdutosNoCardapio(item.nome);
      const produto = matches && matches.length > 0 ? matches[0] : null;
      carrinho.push({
        nome: produto ? produto.nome : item.nome,
        quantidade: Number(item.quantidade) > 0 ? Number(item.quantidade) : 1,
        preco: produto ? produto.preco : (Number(item.preco) || 0),
      });
    }
    return carrinho;
  } catch (err) {
    console.error('[Extractor] Erro ao sincronizar carrinho:', err.message);
    return null;
  }
}

/**
 * Verifica se a última mensagem da Lara contém o gatilho de finalização
 */
function pedidoFoiFinalizado(historico) {
  const ultimaLara = [...historico].reverse().find(m => m.role === 'assistant');
  if (!ultimaLara) return false;
  const texto = ultimaLara.content.toLowerCase();
  return texto.includes(GATILHO_FINALIZACAO) || texto.includes('pedido confirmado');
}

/**
 * Tenta extrair um pedido FINALIZADO da conversa usando a IA.
 * Só roda quando a Lara já disparou o gatilho de finalização.
 *
 * @param {Array} historico - Histórico completo da conversa
 * @param {Array} carrinho - Carrinho atual da sessão (fallback)
 * @returns {Promise<Object|null>} - Dados do pedido ou null
 */
async function extrairPedidoDaConversa(historico, carrinho = []) {
  if (!pedidoFoiFinalizado(historico)) return null;

  const promptExtracao = `
Analise o histórico de conversa abaixo e extraia os dados do pedido FINALIZADO no formato JSON.
Se não houver um pedido claro e confirmado, responda apenas "NULL".

FORMATO JSON ESPERADO:
{
  "itens": [
    {"nome": "Nome do Produto", "quantidade": 1, "preco": 10.00}
  ],
  "endereco": "Endereço completo (ou 'Retirada' se não informado)",
  "forma_pagamento": "Forma(s) de pagamento. Pode ser combinada, ex: 'PIX' ou 'PIX (R$ 20,00) + Dinheiro (R$ 9,90)'",
  "total": 0.00
}

HISTÓRICO:
${historico.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n')}
`;

  try {
    const resposta = await obterRespostaIA(promptExtracao, [], 'Você é um extrator de dados JSON preciso.');
    if (resposta && resposta.toUpperCase().includes('NULL')) {
      return montarPedidoDoCarrinho(carrinho);
    }

    const jsonMatch = resposta.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const dados = JSON.parse(jsonMatch[0]);
      if (dados.itens && dados.itens.length > 0) return dados;
    }
    // Fallback: usar o carrinho da sessão
    return montarPedidoDoCarrinho(carrinho);
  } catch (err) {
    console.error('[Extractor] Erro ao extrair pedido:', err.message);
    return montarPedidoDoCarrinho(carrinho);
  }
}

/**
 * Monta um pedido a partir do carrinho da sessão (fallback confiável)
 */
function montarPedidoDoCarrinho(carrinho) {
  if (!carrinho || carrinho.length === 0) return null;
  const total = carrinho.reduce((acc, i) => acc + (i.preco || 0) * (i.quantidade || 1), 0);
  return {
    itens: carrinho.map(i => ({ nome: i.nome, quantidade: i.quantidade || 1, preco: i.preco || 0 })),
    endereco: 'A combinar',
    forma_pagamento: 'A combinar',
    total,
  };
}

/**
 * Salva o pedido extraído no banco de dados
 */
async function salvarPedidoConversacional(telefone, dadosPedido, nomeCliente) {
  try {
    const cliente = clientes.criarOuAtualizar(telefone, { nome: nomeCliente });

    // Normaliza os itens garantindo preço/quantidade/subtotal em cada um
    // (o subtotal por item é obrigatório para a impressão e o painel).
    const itens = (dadosPedido.itens || []).map(i => {
      const preco = Number(i.preco) || 0;
      const quantidade = Number(i.quantidade) > 0 ? Number(i.quantidade) : 1;
      return {
        nome: i.nome,
        quantidade,
        preco,
        subtotal: Number((preco * quantidade).toFixed(2)),
        observacao: i.observacao || '',
      };
    });

    const subtotal = Number(itens.reduce((acc, i) => acc + i.subtotal, 0).toFixed(2));
    // Taxa e bairro (motor local já resolve; IA externa é resolvida aqui)
    const { taxa: taxaEntrega, bairro } = resolverEntrega(dadosPedido);
    // Usa o total já calculado pela conversa; senão soma itens + taxa.
    const total = Number(dadosPedido.total) > 0
      ? Number(dadosPedido.total)
      : Number((subtotal + taxaEntrega).toFixed(2));

    const pedidoFinal = {
      cliente_id: cliente.id,
      telefone: telefone,
      nome_cliente: nomeCliente,
      endereco: dadosPedido.endereco || 'Retirada / A combinar',
      complemento: dadosPedido.complemento || '',
      referencia: dadosPedido.referencia || '',
      bairro: bairro || '',
      itens: itens,
      subtotal: subtotal,
      taxa_entrega: taxaEntrega,
      total: total,
      forma_pagamento: dadosPedido.forma_pagamento || 'A combinar',
      status: 'pendente'
    };

    const novoPedido = pedidos.criar(pedidoFinal);

    // Se o pagamento envolve PIX, o pedido fica "aguardando" o recebimento
    // (o operador confirma no painel, o que dispara a confirmação ao cliente).
    if (pagamentoTemPix(pedidoFinal.forma_pagamento)) {
      pedidos.setPixStatus(novoPedido.id, 'aguardando');
      novoPedido.pix_status = 'aguardando';
    }

    console.log(`✅ [${telefone}] Pedido conversacional registrado: ${novoPedido.codigo}`);
    return novoPedido;
  } catch (err) {
    console.error('[Extractor] Erro ao salvar pedido:', err.message);
    return null;
  }
}

module.exports = {
  sincronizarCarrinho,
  pedidoFoiFinalizado,
  extrairPedidoDaConversa,
  salvarPedidoConversacional
};
