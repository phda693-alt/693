/**
 * ============================================
 *  CONFIGURAÇÕES DO BOT - FAST FOOD WHATSAPP
 *  (Com IA Humanizada "Lara" Integrada)
 * ============================================
 *
 *  🔐 IMPORTANTE: a configuração agora fica CRIPTOGRAFADA no arquivo
 *  "config.secure" (ao lado deste). Os valores abaixo são apenas os
 *  PADRÕES DE FÁBRICA usados na primeira execução (semente).
 *
 *  ➜ Para alterar QUALQUER configuração, use o PAINEL WEB
 *    (aba "Configurações"). Editar este arquivo à mão NÃO tem efeito
 *    quando o "config.secure" já existe — ele é a fonte da verdade.
 * ============================================
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const { encrypt, decrypt } = require('./cryptoConfig');

/**
 * Detecta automaticamente a interface da impressora
 * com base no sistema operacional.
 */
function detectarInterfaceImpressora() {
  if (os.platform() === 'win32') {
    return '//localhost/MP-4200 TH';
  }
  return '/dev/usb/lp0';
}

// Arquivo cifrado com a configuração efetiva (fonte da verdade)
const ARQUIVO_SEGURO = path.join(__dirname, 'config.secure');

// ─── PADRÕES DE FÁBRICA (semente da 1ª execução) ─────────────
const defaults = {
  // ─── DADOS DA LOJA ───────────────────────────
  loja: {
    nome: '🍔 Fast Food Delivery',
    endereco: 'Rua Exemplo, 123 - Centro',
    telefone: '(00) 00000-0000',
    horarioAbertura: '10:00',
    horarioFechamento: '23:00',
    taxaEntrega: 5.00,
    tempoEstimadoMin: 30,
    tempoEstimadoMax: 50,
    pedidoMinimo: 15.00,
  },

  // ─── FORMAS DE PAGAMENTO ─────────────────────
  formasPagamento: [
    { id: 1, nome: 'Dinheiro', emoji: '💵', aceitaTroco: true },
    { id: 2, nome: 'PIX', emoji: '📱', aceitaTroco: false },
    { id: 3, nome: 'Cartão de Débito', emoji: '💳', aceitaTroco: false },
    { id: 4, nome: 'Cartão de Crédito', emoji: '💳', aceitaTroco: false },
  ],

  // ─── PIX ─────────────────────────────────────
  pix: {
    chave: '00.000.000/0001-00',
    tipo: 'CNPJ',
    titular: 'Fast Food Delivery LTDA',
  },

  // ─── IMPRESSORA TÉRMICA ──────────────────────
  impressora: {
    tipo: 'epson',
    interface: detectarInterfaceImpressora(),
    largura: 48,
    habilitada: true,
  },

  // ─── SERVIDOR WEB (PAINEL ADMIN) ─────────────
  servidor: {
    porta: 3000,
    senhaAdmin: '2394',
  },

  // ─── CONFIGURAÇÕES DE IA ─────────────────────
  ai: {
    habilitado: true,
    persona: {
      nome: 'Lara',
      descricao: 'Atendente virtual simpática e prestativa',
    },
    openai: {
      habilitado: true,
      modelo: 'claude-haiku-4-5',
      maxTokens: 500,
      temperatura: 0.7,
    },
    syphnosys: {
      habilitado: true,
      endpoint: 'https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov',
      authToken: 'LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S',
      appVersion: '77',
    },
    begamob: {
      habilitado: true,
      endpoint: 'https://chat-ai.begamob.com/api/v2/chatStream',
      clientId: 'stteam-ikameglobal-chatapiopenai',
      userAgent: 'ChatOn_Android/1.87.697',
    },
    emojikeyboard: {
      habilitado: true,
      endpoint: 'https://chat.emoji-keyboard.com/api/v2/Chat',
      secretKey: '03790257ca9d3ed1',
    },
  },

  // ─── MENSAGENS PERSONALIZÁVEIS ───────────────
  mensagens: {
    boasVindas: `🍔 *Olá! Bem-vindo(a) ao {NOME_LOJA}!* 🍔

Estamos prontos para atender você! 😊

📋 *MENU PRINCIPAL:*
━━━━━━━━━━━━━━━━━━━━
*1* - 📖 Ver Cardápio
*2* - 🛒 Fazer Pedido
*3* - 📦 Acompanhar Pedido
*4* - 💰 Formas de Pagamento
*5* - 📍 Nosso Endereço
*6* - ⏰ Horário de Funcionamento
*7* - 📞 Falar com Atendente
━━━━━━━━━━━━━━━━━━━━

_Ou simplesmente me diga o que você precisa! 😊_`,

    lojaFechada: `⚠️ *Ops! Estamos fechados no momento.*

🕐 Nosso horário de funcionamento:
📅 *{HORARIO_ABERTURA} às {HORARIO_FECHAMENTO}*

Volte no nosso horário! 😊`,

    pedidoConfirmado: `✅ *PEDIDO CONFIRMADO!*

📋 Pedido: *#{NUMERO_PEDIDO}*
⏰ Previsão de entrega: *{TEMPO_ESTIMADO}*

Seu pedido está sendo preparado! 🍳
Avisaremos quando sair para entrega! 🏍️`,

    pedidoSaiuEntrega: `🏍️ *SEU PEDIDO SAIU PARA ENTREGA!*

📋 Pedido: *#{NUMERO_PEDIDO}*
⏰ Previsão de chegada: *{TEMPO_ESTIMADO}*

Aguarde em seu endereço! 😊`,

    pedidoEntregue: `✅ *PEDIDO ENTREGUE!*

📋 Pedido: *#{NUMERO_PEDIDO}*

Obrigado pela preferência! 🙏
Esperamos que goste! 😋

⭐ Avalie nosso atendimento de 1 a 5!`,
  },
};

// ─── UTIL: merge profundo (preserva identidade dos objetos aninhados) ─
function deepMerge(alvo, patch) {
  if (!patch || typeof patch !== 'object') return alvo;
  for (const chave of Object.keys(patch)) {
    const valor = patch[chave];
    if (valor && typeof valor === 'object' && !Array.isArray(valor)
        && alvo[chave] && typeof alvo[chave] === 'object' && !Array.isArray(alvo[chave])) {
      deepMerge(alvo[chave], valor);
    } else {
      alvo[chave] = valor;
    }
  }
  return alvo;
}

// Objeto de configuração efetivo (começa com os padrões)
const config = deepMerge({}, defaults);

// ─── Carrega a configuração cifrada (fonte da verdade) ───────
try {
  if (fs.existsSync(ARQUIVO_SEGURO)) {
    const armazenado = decrypt(fs.readFileSync(ARQUIVO_SEGURO, 'utf8'));
    deepMerge(config, armazenado); // valores salvos têm prioridade
  } else {
    // Primeira execução: semeia o arquivo cifrado a partir dos padrões
    fs.writeFileSync(ARQUIVO_SEGURO, encrypt(config), 'utf8');
  }
} catch (e) {
  console.error('[Config] Não foi possível ler config.secure, usando padrões:', e.message);
}

// ─── Métodos (não-enumeráveis, não são serializados) ─────────

// Salva a configuração atual de forma cifrada no disco.
Object.defineProperty(config, 'salvar', {
  value: function salvar() {
    try {
      const somenteDados = JSON.parse(JSON.stringify(config)); // ignora métodos
      fs.writeFileSync(ARQUIVO_SEGURO, encrypt(somenteDados), 'utf8');
      return true;
    } catch (e) {
      console.error('[Config] Erro ao salvar config.secure:', e.message);
      return false;
    }
  },
  enumerable: false,
});

// Aplica um patch (parcial ou completo) e persiste cifrado.
Object.defineProperty(config, 'atualizar', {
  value: function atualizar(patch) {
    deepMerge(config, patch || {});
    return config.salvar();
  },
  enumerable: false,
});

module.exports = config;
