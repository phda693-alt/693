/**
 * ============================================================
 *  HANDLERS DE MENSAGENS (100% CONVERSACIONAL)
 * ============================================================
 * Gerencia o fluxo de mensagens roteando tudo para a IA Lara.
 * O menu estruturado foi removido para uma experiência humana.
 * ============================================================
 */

const dayjs = require('dayjs');
const sessionManager = require('./session');
const { tentarProvedoresIA } = require('../ai/aiEngine');
const { montarContextoRestaurante } = require('../ai/restauranteContext');
const motorLocal = require('../ai/motorLocal');
const aiAgent = require('../ai/aiAgent');
const { categorias, produtos, clientes, pedidos } = require('../database/db');
const EventEmitter = require('events');

const botEvents = new EventEmitter();

/**
 * Processador principal de mensagens
 */
async function processarMensagem(telefone, msg, pushName) {
  const session = sessionManager.get(telefone);
  const msgLower = msg.toLowerCase().trim();

  // ─── COMANDO GLOBAL DE RESET (Útil para testes) ──────────────
  if (msgLower === 'reset' || msgLower === 'reiniciar') {
    sessionManager.reset(telefone);
    sessionManager.limparHistoricoIA(telefone);
    sessionManager.limparCarrinho(telefone);
    const s = sessionManager.get(telefone);
    s.aguardandoConfirmacao = null;
    s.aguardandoEscolha = null;
    s.faseFinalizacao = null;
    return '🔄 Conversa reiniciada! Como posso te ajudar?';
  }

  // ─── ROTA ÚNICA: 100% IA CONVERSACIONAL ─────────────────────
  // A IA Lara gerencia todo o atendimento, desde dúvidas até pedidos.
  return await processarComIA(telefone, msg, session, pushName);
}

/**
 * Processa mensagem com IA, mantendo histórico de conversa.
 * Se nenhum provedor de IA externo responder, usa o motor
 * conversacional LOCAL (mesmo comportamento, sem depender de API).
 */
async function processarComIA(telefone, mensagem, session, pushName) {
  try {
    const historico = sessionManager.obterHistoricoIA(telefone);
    const carrinho = sessionManager.obterCarrinho(telefone);
    const nomeCliente = session.nomeCliente || pushName || '';
    if (pushName && !session.nomeCliente) session.nomeCliente = pushName;

    // ─── 0) AGENTE DE IA (function-calling) — caminho primário ──
    // A IA entende e AGE a qualquer momento (adicionar, remover, endereço,
    // pagamento, fechar...). Requer chave configurada (painel ou .env).
    if (aiAgent.disponivel()) {
      try {
        const r = await aiAgent.conversar(mensagem, session, { nomeCliente, telefone });
        if (r && r.finalizar && r.dadosPedido) {
          const { salvarPedidoConversacional } = require('../ai/orderExtractor');
          const novoPedido = await salvarPedidoConversacional(telefone, r.dadosPedido, nomeCliente);
          if (novoPedido) {
            botEvents.emit('novo_pedido', novoPedido);
            sessionManager.limparCarrinho(telefone);
            session.carrinho = [];
            console.log(`[Agente IA] Pedido #${novoPedido.codigo} registrado.`);
          }
        }
        if (r && r.texto) return r.texto;
      } catch (e) {
        console.warn('[Agente IA] Falhou, usando fallback:', e.message);
      }
    }

    const db = { categorias, produtos };
    const systemPrompt = montarContextoRestaurante(db, nomeCliente, mensagem, carrinho);

    sessionManager.adicionarHistoricoIA(telefone, 'user', mensagem);

    // 1) Tenta os provedores de IA externos
    const respostaIA = await tentarProvedoresIA(mensagem, historico, systemPrompt);

    if (respostaIA) {
      // ─── MODO IA EXTERNA ───────────────────────────────────
      sessionManager.adicionarHistoricoIA(telefone, 'assistant', respostaIA);
      const historicoAtual = sessionManager.obterHistoricoIA(telefone);
      const {
        sincronizarCarrinho,
        pedidoFoiFinalizado,
        extrairPedidoDaConversa,
        salvarPedidoConversacional,
      } = require('../ai/orderExtractor');

      sincronizarCarrinho(historicoAtual)
        .then((itens) => { if (Array.isArray(itens)) sessionManager.definirCarrinho(telefone, itens); })
        .catch(e => console.error('[IA] Erro ao sincronizar carrinho:', e.message));

      if (pedidoFoiFinalizado(historicoAtual)) {
        extrairPedidoDaConversa(historicoAtual, sessionManager.obterCarrinho(telefone))
          .then(async (dados) => {
            if (dados) {
              const novoPedido = await salvarPedidoConversacional(telefone, dados, nomeCliente);
              if (novoPedido) {
                botEvents.emit('novo_pedido', novoPedido);
                sessionManager.limparCarrinho(telefone);
                console.log(`[IA] Pedido #${novoPedido.codigo} registrado via conversa.`);
              }
            }
          })
          .catch(e => console.error('[IA] Erro na extração de pedido:', e.message));
      }

      return respostaIA;
    }

    // 2) Sem IA externa → MOTOR LOCAL (determinístico e passivo)
    console.warn('[IA] Nenhum provedor externo disponível. Usando motor conversacional local.');
    const resultado = motorLocal.responder(mensagem, session);
    sessionManager.adicionarHistoricoIA(telefone, 'assistant', resultado.texto);

    if (resultado.finalizar && resultado.dadosPedido) {
      const { salvarPedidoConversacional } = require('../ai/orderExtractor');
      salvarPedidoConversacional(telefone, resultado.dadosPedido, nomeCliente)
        .then((novoPedido) => {
          if (novoPedido) {
            botEvents.emit('novo_pedido', novoPedido);
            sessionManager.limparCarrinho(telefone);
            session.carrinho = [];
            console.log(`[Local] Pedido #${novoPedido.codigo} registrado via conversa local.`);
          }
        })
        .catch(e => console.error('[Local] Erro ao salvar pedido:', e.message));
    }

    return resultado.texto;
  } catch (err) {
    console.error('[IA] Erro ao processar mensagem:', err.message);
    return "Desculpe, tive um probleminha técnico. Poderia repetir o que você deseja?";
  }
}

/**
 * Utilitário de saudação
 */
function getSaudacao() {
  const hora = dayjs().hour();
  if (hora >= 5 && hora < 12) return 'Bom dia';
  if (hora >= 12 && hora < 18) return 'Boa tarde';
  return 'Boa noite';
}

module.exports = {
  processarMensagem,
  botEvents
};
