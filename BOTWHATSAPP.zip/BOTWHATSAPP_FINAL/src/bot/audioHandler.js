/**
 * ============================================================
 *  PROCESSADOR DE ÁUDIO
 * ============================================================
 * Lógica para baixar mensagens de áudio do WhatsApp,
 * converter para formato compatível e transcrever usando
 * o utilitário manus-speech-to-text.
 * ============================================================
 */

const { downloadContentFromMessage } = require('baileys');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const TEMP_DIR = path.join(__dirname, '..', '..', 'data', 'temp_audio');

// Garantir que o diretório temporário existe
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

/**
 * Baixa e transcreve uma mensagem de áudio
 *
 * @param {Object} message - Objeto de mensagem do Baileys
 * @returns {Promise<string|null>} - Texto transcrito ou null
 */
async function processarAudio(message) {
  const audioMessage = message.message.audioMessage;
  if (!audioMessage) return null;

  const fileName = `${uuidv4()}.ogg`;
  const filePath = path.join(TEMP_DIR, fileName);

  try {
    // 1. Baixar o conteúdo do áudio
    const stream = await downloadContentFromMessage(audioMessage, 'audio');
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    fs.writeFileSync(filePath, buffer);

    // 2. Transcrever usando manus-speech-to-text
    // O utilitário manus-speech-to-text imprime a transcrição no stdout
    const transcricao = await new Promise((resolve, reject) => {
      exec(`manus-speech-to-text "${filePath}"`, (error, stdout, stderr) => {
        if (error) {
          console.error('[Áudio] Erro na transcrição:', error.message);
          return resolve(null);
        }
        resolve(stdout.trim());
      });
    });

    // 3. Limpar arquivo temporário
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    if (transcricao) {
      console.log(`[Áudio] Transcrição concluída: "${transcricao}"`);
    }

    return transcricao;
  } catch (err) {
    console.error('[Áudio] Falha ao processar áudio:', err.message);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    return null;
  }
}

module.exports = {
  processarAudio
};
