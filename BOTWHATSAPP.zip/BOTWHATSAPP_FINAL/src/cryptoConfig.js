/**
 * ============================================================
 *  CRIPTOGRAFIA DA CONFIGURAÇÃO  🔐
 * ============================================================
 * Cifra/decifra o objeto de configuração para que os valores NÃO
 * fiquem em texto puro no disco. Assim, a configuração só pode ser
 * alterada de forma prática pelo painel web (que grava o arquivo
 * cifrado), e não editando um arquivo à mão.
 *
 * Algoritmo: AES-256-GCM (autenticado).
 * A chave é derivada de um segredo (variável de ambiente CONFIG_SECRET
 * ou um segredo embutido). Formato do blob: base64(IV | TAG | CIPHER).
 * ============================================================
 */

const crypto = require('crypto');

// Segredo usado para derivar a chave. Pode ser sobrescrito por ambiente.
const SEGREDO = process.env.CONFIG_SECRET || 'FastFoodBot::v1::c0nf1g-s3cr3t::9b2f7a13e4';
const CHAVE = crypto.createHash('sha256').update(SEGREDO).digest(); // 32 bytes

/**
 * Cifra um objeto (ou string) e retorna um blob base64.
 */
function encrypt(dados) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', CHAVE, iv);
  const texto = typeof dados === 'string' ? dados : JSON.stringify(dados);
  const cifrado = Buffer.concat([cipher.update(Buffer.from(texto, 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, cifrado]).toString('base64');
}

/**
 * Decifra um blob base64 e devolve o objeto (JSON.parse).
 */
function decrypt(blob) {
  const dados = Buffer.from(blob, 'base64');
  const iv = dados.subarray(0, 12);
  const tag = dados.subarray(12, 28);
  const cifrado = dados.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', CHAVE, iv);
  decipher.setAuthTag(tag);
  const claro = Buffer.concat([decipher.update(cifrado), decipher.final()]).toString('utf8');
  return JSON.parse(claro);
}

module.exports = { encrypt, decrypt };
