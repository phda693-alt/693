/**
 * ============================================
 *  FAST FOOD BOT - PAINEL ADMIN JS
 * ============================================
 */

// ─── ESTADO GLOBAL ──────────────────────────────
let authToken = localStorage.getItem('authToken') || '';
let currentPage = 'dashboard';
let socket = null;
let refreshInterval = null;
let qrCodeInstance = null;
let licencaValida = false;

// ─── INICIALIZAÇÃO ──────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  if (authToken) {
    showAdmin();
  }
  setupEventListeners();
  startClock();
  // Carregar status da licença (sem autenticação necessária)
  carregarLicenca();
  // Carregar HWID e Contra-Chave na tela de login
  carregarLicencaLogin();
});

function setupEventListeners() {
  // Login
  document.getElementById('loginForm').addEventListener('submit', handleLogin);

  // Navegação
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });

  // Menu mobile
  document.getElementById('menuToggle').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('open');
  });

  // Logout
  document.getElementById('btnLogout').addEventListener('click', () => {
    localStorage.removeItem('authToken');
    authToken = '';
    location.reload();
  });

  // Modal
  document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('modal')) closeModal();
  });

  // Cardápio
  document.getElementById('btnNovaCategoria').addEventListener('click', () => openCategoriaModal());
  document.getElementById('btnNovoProduto').addEventListener('click', () => openProdutoModal());

  // Bairros
  document.getElementById('btnNovoBairro')?.addEventListener('click', () => openBairroModal());

  // Filtros pedidos
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadPedidos(btn.dataset.filtro);
    });
  });

  // Config
  document.getElementById('formLoja').addEventListener('submit', handleSaveConfig);

  // Desconectar WhatsApp
  document.getElementById('btnDesconectar')?.addEventListener('click', handleDesconectar);
}

// ─── AUTH ────────────────────────────────────────

async function handleLogin(e) {
  e.preventDefault();
  const senha = document.getElementById('loginPassword').value;
  try {
    const res = await api('/api/status', { token: senha });
    authToken = senha;
    localStorage.setItem('authToken', authToken);
    showAdmin();
  } catch (err) {
    showToast('Senha incorreta!', 'error');
  }
}

function showAdmin() {
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('adminPanel').style.display = 'flex';
  initSocket();
  loadDashboard();
  refreshInterval = setInterval(loadDashboard, 10000);
}

// ─── API ────────────────────────────────────────

async function api(url, params = {}, options = {}) {
  const queryParams = new URLSearchParams(params).toString();
  const fullUrl = queryParams ? `${url}?${queryParams}` : url;

  const config = {
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Token': authToken,
    },
    ...options,
  };

  const res = await fetch(fullUrl, config);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Erro desconhecido' }));
    throw new Error(err.error || 'Erro na requisição');
  }
  return res.json();
}

// ─── SOCKET.IO ──────────────────────────────────

function initSocket() {
  socket = io();

  socket.on('qr', (qr) => {
    updateQRCode(qr);
    updateStatusIndicator('qr_ready', 'QR Code pronto');
  });

  socket.on('status', (data) => {
    updateStatusIndicator(data.status, data.message);
    if (data.status === 'connected') {
      showConnected();
    }
  });

  socket.on('novo_pedido', (pedido) => {
    showToast(`Novo pedido #${pedido.codigo}!`, 'warning');
    playNotification();
    loadDashboard();
    if (currentPage === 'pedidos') loadPedidos();
    updateBadge();
  });

  socket.on('pedido_atualizado', () => {
    loadDashboard();
    if (currentPage === 'pedidos') loadPedidos();
  });

  socket.on('licenca_status', (data) => {
    atualizarUILicenca(data);
  });

  socket.on('licenca_ativada', (data) => {
    licencaValida = true;
    showToast('Licença ativada com sucesso!', 'success');
    carregarLicenca();
    removerOverlayBloqueio();
  });

  socket.on('licenca_expirada', (data) => {
    licencaValida = false;
    showToast('Licença expirada! Contate o administrador.', 'error');
    carregarLicenca();
    mostrarOverlayBloqueio();
  });
}

// ─── NAVEGAÇÃO ──────────────────────────────────

function navigateTo(page) {
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(`page${capitalize(page)}`).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector(`[data-page="${page}"]`).classList.add('active');
  document.getElementById('pageTitle').textContent = getPageTitle(page);
  document.querySelector('.sidebar').classList.remove('open');

  // Carregar dados da página
  switch (page) {
    case 'dashboard': loadDashboard(); break;
    case 'pedidos': loadPedidos('pendentes'); break;
    case 'cardapio': loadCardapio(); break;
    case 'bairros': loadBairros(); break;
    case 'clientes': loadClientes(); break;
    case 'whatsapp': loadWhatsappStatus(); break;
    case 'config': loadConfig(); break;
    case 'licenca': carregarLicenca(); break;
  }
}

function getPageTitle(page) {
  const titles = {
    dashboard: 'Dashboard',
    pedidos: 'Pedidos',
    cardapio: 'Cardápio',
    bairros: 'Taxas por Bairro',
    clientes: 'Clientes',
    whatsapp: 'WhatsApp',
    config: 'Configurações',
    licenca: 'Licença',
  };
  return titles[page] || page;
}

// ─── DASHBOARD ──────────────────────────────────

async function loadDashboard() {
  try {
    const [status, pendentes] = await Promise.all([
      api('/api/status'),
      api('/api/pedidos', { filtro: 'pendentes' }),
    ]);

    const stats = status.estatisticas;
    document.getElementById('statPedidos').textContent = stats.total_pedidos;
    document.getElementById('statFaturamento').textContent = `R$ ${stats.faturamento.toFixed(2)}`;
    document.getElementById('statAndamento').textContent = stats.em_andamento;
    document.getElementById('statEntregues').textContent = stats.entregues;

    updateStatusIndicator(status.status);

    // Pedidos pendentes
    const pendentesDiv = document.getElementById('pedidosPendentesLista');
    const pedidosPendentes = pendentes.filter(p => ['pendente', 'confirmado', 'em_preparo'].includes(p.status));
    if (pedidosPendentes.length === 0) {
      pendentesDiv.innerHTML = '<p class="empty-state">Nenhum pedido pendente</p>';
    } else {
      pendentesDiv.innerHTML = pedidosPendentes.map(p => renderPedidoCard(p, true)).join('');
    }

    // Em entrega
    const entregaDiv = document.getElementById('pedidosEntregaLista');
    const emEntrega = pendentes.filter(p => p.status === 'saiu_entrega');
    if (emEntrega.length === 0) {
      entregaDiv.innerHTML = '<p class="empty-state">Nenhum pedido em entrega</p>';
    } else {
      entregaDiv.innerHTML = emEntrega.map(p => renderPedidoCard(p, true)).join('');
    }

    // Badge
    const badge = document.getElementById('badgePedidos');
    if (pedidosPendentes.length > 0) {
      badge.style.display = 'inline';
      badge.textContent = pedidosPendentes.length;
    } else {
      badge.style.display = 'none';
    }
  } catch (err) {
    console.error('Erro ao carregar dashboard:', err);
  }
}

// ─── PEDIDOS ────────────────────────────────────

async function loadPedidos(filtro = 'pendentes') {
  try {
    const pedidosData = await api('/api/pedidos', { filtro });
    const container = document.getElementById('pedidosLista');

    if (pedidosData.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhum pedido encontrado</p>';
      return;
    }

    container.innerHTML = pedidosData.map(p => renderPedidoCard(p)).join('');
  } catch (err) {
    console.error('Erro ao carregar pedidos:', err);
  }
}

function renderPedidoCard(pedido, compact = false) {
  const itens = Array.isArray(pedido.itens) ? pedido.itens : JSON.parse(pedido.itens);
  const statusLabels = {
    pendente: 'Pendente',
    confirmado: 'Confirmado',
    em_preparo: 'Em Preparo',
    saiu_entrega: 'Saiu Entrega',
    entregue: 'Entregue',
    cancelado: 'Cancelado',
  };

  const hora = pedido.hora_pedido ? new Date(pedido.hora_pedido).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '';

  let actionsHtml = '';
  switch (pedido.status) {
    case 'pendente':
      if (pedido.pix_status === 'aguardando') {
        // Pedido via PIX aguardando pagamento: operador confirma o recebimento
        actionsHtml = `
          <button class="btn btn-sm btn-success" onclick="confirmarPix(${pedido.id})"><i class="fas fa-check-circle"></i> PIX Recebido</button>
          <button class="btn btn-sm btn-danger" onclick="updatePedidoStatus(${pedido.id}, 'cancelado')"><i class="fas fa-times"></i> Cancelar</button>
        `;
      } else {
        actionsHtml = `
          <button class="btn btn-sm btn-success" onclick="updatePedidoStatus(${pedido.id}, 'confirmado')"><i class="fas fa-check"></i> Confirmar</button>
          <button class="btn btn-sm btn-danger" onclick="updatePedidoStatus(${pedido.id}, 'cancelado')"><i class="fas fa-times"></i> Cancelar</button>
        `;
      }
      break;
    case 'confirmado':
      actionsHtml = `<button class="btn btn-sm btn-primary" onclick="updatePedidoStatus(${pedido.id}, 'em_preparo')"><i class="fas fa-fire"></i> Em Preparo</button>`;
      break;
    case 'em_preparo':
      actionsHtml = `<button class="btn btn-sm btn-info" onclick="updatePedidoStatus(${pedido.id}, 'saiu_entrega')"><i class="fas fa-motorcycle"></i> Saiu Entrega</button>`;
      break;
    case 'saiu_entrega':
      actionsHtml = `<button class="btn btn-sm btn-success" onclick="updatePedidoStatus(${pedido.id}, 'entregue')"><i class="fas fa-check-double"></i> Entregue</button>`;
      break;
  }

  actionsHtml += `<button class="btn btn-sm btn-outline" onclick="imprimirPedido('${pedido.codigo}')"><i class="fas fa-print"></i></button>`;

  return `
    <div class="pedido-card status-${pedido.status}">
      <div class="pedido-header">
        <span class="pedido-codigo">#${pedido.codigo}</span>
        <span class="pedido-status ${pedido.status}">${statusLabels[pedido.status]}</span>
      </div>
      <div class="pedido-info">
        <strong><i class="fas fa-user"></i> ${pedido.nome_cliente || 'Sem nome'}</strong> &bull;
        <i class="fas fa-phone"></i> ${formatPhone(pedido.telefone)} &bull;
        <i class="fas fa-clock"></i> ${hora}
      </div>
      <div class="pedido-info">
        <i class="fas fa-map-marker-alt"></i> ${pedido.endereco || 'Sem endereço'}
        ${pedido.complemento ? ' - ' + pedido.complemento : ''}
        ${pedido.bairro ? ' - Bairro: ' + pedido.bairro : ''}
        ${pedido.referencia ? ' (Ref: ' + pedido.referencia + ')' : ''}
      </div>
      <div class="pedido-itens">
        ${itens.map(i => `<div class="item-line"><span>${i.quantidade}x ${i.nome}</span><span>R$ ${Number(i.subtotal != null ? i.subtotal : (i.preco || 0) * (i.quantidade || 1)).toFixed(2)}</span></div>`).join('')}
      </div>
      ${pedido.observacao ? `<div class="pedido-info" style="color:var(--danger);font-weight:600"><i class="fas fa-exclamation-circle"></i> OBS: ${pedido.observacao}</div>` : ''}
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div class="pedido-total">R$ ${Number(pedido.total || 0).toFixed(2)}</div>
        <div class="pedido-info" style="margin:0"><i class="fas fa-credit-card"></i> ${pedido.forma_pagamento}${pedido.troco_para > 0 ? ` (Troco p/ R$${Number(pedido.troco_para).toFixed(2)})` : ''}${pedido.pix_status === 'aguardando' ? ' <span style="color:#e67e22;font-weight:700">⏳ Aguardando PIX</span>' : ''}${pedido.pix_status === 'recebido' ? ' <span style="color:#28a745;font-weight:700">✅ PIX recebido</span>' : ''}</div>
      </div>
      <div class="pedido-actions">${actionsHtml}</div>
    </div>
  `;
}

async function updatePedidoStatus(id, status) {
  try {
    await api(`/api/pedidos/${id}/status`, {}, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
    showToast(`Pedido atualizado para: ${status}`, 'success');
    loadDashboard();
    if (currentPage === 'pedidos') loadPedidos();
  } catch (err) {
    showToast('Erro ao atualizar pedido: ' + err.message, 'error');
  }
}

async function confirmarPix(id) {
  if (!confirm('Confirmar que o PIX foi recebido? O cliente será avisado e o pedido será confirmado.')) return;
  try {
    await api(`/api/pedidos/${id}/pix-recebido`, {}, { method: 'POST' });
    showToast('PIX confirmado! Cliente avisado e pedido confirmado.', 'success');
    loadDashboard();
    if (currentPage === 'pedidos') loadPedidos();
  } catch (err) {
    showToast('Erro ao confirmar PIX: ' + err.message, 'error');
  }
}

async function imprimirPedido(codigo) {
  try {
    await api(`/api/pedidos/${codigo}/imprimir`, {}, { method: 'POST' });
    showToast('Pedido enviado para impressão!', 'success');
  } catch (err) {
    showToast('Erro ao imprimir: ' + err.message, 'error');
  }
}

// ─── CARDÁPIO ───────────────────────────────────

async function loadCardapio() {
  try {
    const [cats, prods] = await Promise.all([
      api('/api/categorias'),
      api('/api/produtos'),
    ]);

    const container = document.getElementById('cardapioLista');

    if (cats.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhuma categoria cadastrada. Clique em "Nova Categoria" para começar.</p>';
      return;
    }

    container.innerHTML = cats.map(cat => {
      const catProds = prods.filter(p => p.categoria_id === cat.id);
      return `
        <div class="categoria-section">
          <div class="categoria-header">
            <h3>${cat.emoji} ${cat.nome} ${!cat.ativa ? '<span style="color:var(--danger)">(Inativa)</span>' : ''}</h3>
            <div>
              <button class="btn btn-xs btn-outline" onclick='openCategoriaModal(${JSON.stringify(cat)})'>
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn btn-xs btn-danger" onclick="deleteCategoria(${cat.id})">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </div>
          ${catProds.length === 0 ? '<p class="empty-state">Nenhum produto nesta categoria</p>' :
            catProds.map(p => `
              <div class="produto-item ${!p.disponivel ? 'produto-indisponivel' : ''}">
                <div class="produto-info">
                  <h4>${p.nome}</h4>
                  <p>${p.descricao || 'Sem descrição'}</p>
                </div>
                <span class="produto-preco">R$ ${p.preco.toFixed(2)}</span>
                <div class="produto-actions">
                  <label class="switch">
                    <input type="checkbox" ${p.disponivel ? 'checked' : ''} onchange="toggleProduto(${p.id})">
                    <span class="slider"></span>
                  </label>
                  <button class="btn btn-xs btn-outline" onclick='openProdutoModal(${JSON.stringify(p)})'>
                    <i class="fas fa-edit"></i>
                  </button>
                  <button class="btn btn-xs btn-danger" onclick="deleteProduto(${p.id})">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            `).join('')}
        </div>
      `;
    }).join('');
  } catch (err) {
    console.error('Erro ao carregar cardápio:', err);
  }
}

function openCategoriaModal(cat = null) {
  const isEdit = cat !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Editar Categoria' : 'Nova Categoria';
  document.getElementById('modalBody').innerHTML = `
    <form id="formCategoria">
      <div class="form-group">
        <label>Nome</label>
        <input type="text" class="form-control" id="catNome" value="${isEdit ? cat.nome : ''}" required>
      </div>
      <div class="form-group">
        <label>Emoji</label>
        <input type="text" class="form-control" id="catEmoji" value="${isEdit ? cat.emoji : '🍽️'}" maxlength="4">
      </div>
      <div class="form-group">
        <label>Ordem</label>
        <input type="number" class="form-control" id="catOrdem" value="${isEdit ? cat.ordem : 0}">
      </div>
      ${isEdit ? `
        <div class="form-group">
          <label><input type="checkbox" id="catAtiva" ${cat.ativa ? 'checked' : ''}> Ativa</label>
        </div>
      ` : ''}
      <button type="submit" class="btn btn-primary btn-full">
        <i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Criar'}
      </button>
    </form>
  `;
  openModal();

  document.getElementById('formCategoria').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      nome: document.getElementById('catNome').value,
      emoji: document.getElementById('catEmoji').value,
      ordem: parseInt(document.getElementById('catOrdem').value) || 0,
      ativa: isEdit ? document.getElementById('catAtiva').checked : true,
    };
    try {
      if (isEdit) {
        await api(`/api/categorias/${cat.id}`, {}, { method: 'PUT', body: JSON.stringify(data) });
      } else {
        await api('/api/categorias', {}, { method: 'POST', body: JSON.stringify(data) });
      }
      closeModal();
      showToast('Categoria salva!', 'success');
      loadCardapio();
    } catch (err) {
      showToast('Erro: ' + err.message, 'error');
    }
  });
}

async function openProdutoModal(prod = null) {
  const isEdit = prod !== null;
  const cats = await api('/api/categorias');

  document.getElementById('modalTitle').textContent = isEdit ? 'Editar Produto' : 'Novo Produto';
  document.getElementById('modalBody').innerHTML = `
    <form id="formProduto">
      <div class="form-group">
        <label>Categoria</label>
        <select class="form-control" id="prodCategoria" required>
          ${cats.map(c => `<option value="${c.id}" ${isEdit && prod.categoria_id === c.id ? 'selected' : ''}>${c.emoji} ${c.nome}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Nome</label>
        <input type="text" class="form-control" id="prodNome" value="${isEdit ? prod.nome : ''}" required>
      </div>
      <div class="form-group">
        <label>Descrição</label>
        <textarea class="form-control" id="prodDescricao" rows="2">${isEdit ? prod.descricao || '' : ''}</textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Preço (R$)</label>
          <input type="number" class="form-control" id="prodPreco" step="0.10" value="${isEdit ? prod.preco : ''}" required>
        </div>
        <div class="form-group">
          <label>Ordem</label>
          <input type="number" class="form-control" id="prodOrdem" value="${isEdit ? prod.ordem : 0}">
        </div>
      </div>
      ${isEdit ? `
        <div class="form-group">
          <label><input type="checkbox" id="prodDisponivel" ${prod.disponivel ? 'checked' : ''}> Disponível</label>
        </div>
        <div class="form-group">
          <label><input type="checkbox" id="prodDestaque" ${prod.destaque ? 'checked' : ''}> Destaque</label>
        </div>
      ` : ''}
      <button type="submit" class="btn btn-primary btn-full">
        <i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Criar'}
      </button>
    </form>
  `;
  openModal();

  document.getElementById('formProduto').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      categoria_id: parseInt(document.getElementById('prodCategoria').value),
      nome: document.getElementById('prodNome').value,
      descricao: document.getElementById('prodDescricao').value,
      preco: parseFloat(document.getElementById('prodPreco').value),
      ordem: parseInt(document.getElementById('prodOrdem').value) || 0,
      disponivel: isEdit ? document.getElementById('prodDisponivel').checked : true,
      destaque: isEdit ? document.getElementById('prodDestaque').checked : false,
    };
    try {
      if (isEdit) {
        await api(`/api/produtos/${prod.id}`, {}, { method: 'PUT', body: JSON.stringify(data) });
      } else {
        await api('/api/produtos', {}, { method: 'POST', body: JSON.stringify(data) });
      }
      closeModal();
      showToast('Produto salvo!', 'success');
      loadCardapio();
    } catch (err) {
      showToast('Erro: ' + err.message, 'error');
    }
  });
}

async function toggleProduto(id) {
  try {
    await api(`/api/produtos/${id}/toggle`, {}, { method: 'PUT' });
    showToast('Disponibilidade atualizada!', 'success');
  } catch (err) {
    showToast('Erro: ' + err.message, 'error');
    loadCardapio();
  }
}

async function deleteProduto(id) {
  if (!confirm('Tem certeza que deseja excluir este produto?')) return;
  try {
    await api(`/api/produtos/${id}`, {}, { method: 'DELETE' });
    showToast('Produto excluído!', 'success');
    loadCardapio();
  } catch (err) {
    showToast('Erro: ' + err.message, 'error');
  }
}

async function deleteCategoria(id) {
  if (!confirm('Tem certeza que deseja desativar esta categoria?')) return;
  try {
    await api(`/api/categorias/${id}`, {}, { method: 'DELETE' });
    showToast('Categoria desativada!', 'success');
    loadCardapio();
  } catch (err) {
    showToast('Erro: ' + err.message, 'error');
  }
}

// ─── BAIRROS (TAXA DE ENTREGA) ──────────────────

async function loadBairros() {
  try {
    const lista = await api('/api/bairros');
    const container = document.getElementById('bairrosLista');

    if (!lista || lista.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhum bairro cadastrado. Clique em "Novo Bairro" para começar. Enquanto isso, é cobrada a taxa padrão das Configurações.</p>';
      return;
    }

    container.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Bairro</th>
            <th>Taxa de Entrega</th>
            <th>Status</th>
            <th style="text-align:right">Ações</th>
          </tr>
        </thead>
        <tbody>
          ${lista.map(b => `
            <tr>
              <td><strong>${b.nome}</strong></td>
              <td>R$ ${Number(b.taxa || 0).toFixed(2)}</td>
              <td>${b.ativo ? '<span style="color:#28a745;font-weight:600">Ativo</span>' : '<span style="color:#dc3545;font-weight:600">Inativo</span>'}</td>
              <td style="text-align:right">
                <button class="btn btn-xs btn-outline" onclick='openBairroModal(${JSON.stringify(b)})'>
                  <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-xs btn-danger" onclick="deleteBairro(${b.id})">
                  <i class="fas fa-trash"></i>
                </button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (err) {
    console.error('Erro ao carregar bairros:', err);
  }
}

function openBairroModal(bairro = null) {
  const isEdit = bairro !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Editar Bairro' : 'Novo Bairro';
  document.getElementById('modalBody').innerHTML = `
    <form id="formBairro">
      <div class="form-group">
        <label>Nome do Bairro</label>
        <input type="text" class="form-control" id="bairroNome" value="${isEdit ? bairro.nome : ''}" required>
      </div>
      <div class="form-group">
        <label>Taxa de Entrega (R$)</label>
        <input type="number" class="form-control" id="bairroTaxa" step="0.50" min="0" value="${isEdit ? bairro.taxa : '5.00'}" required>
      </div>
      ${isEdit ? `
        <div class="form-group">
          <label><input type="checkbox" id="bairroAtivo" ${bairro.ativo ? 'checked' : ''}> Ativo (atende este bairro)</label>
        </div>
      ` : ''}
      <button type="submit" class="btn btn-primary btn-full">
        <i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Criar'}
      </button>
    </form>
  `;
  openModal();

  document.getElementById('formBairro').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      nome: document.getElementById('bairroNome').value.trim(),
      taxa: parseFloat(document.getElementById('bairroTaxa').value) || 0,
      ativo: isEdit ? document.getElementById('bairroAtivo').checked : true,
    };
    try {
      if (isEdit) {
        await api(`/api/bairros/${bairro.id}`, {}, { method: 'PUT', body: JSON.stringify(data) });
      } else {
        await api('/api/bairros', {}, { method: 'POST', body: JSON.stringify(data) });
      }
      closeModal();
      showToast('Bairro salvo!', 'success');
      loadBairros();
    } catch (err) {
      showToast('Erro: ' + err.message, 'error');
    }
  });
}

async function deleteBairro(id) {
  if (!confirm('Tem certeza que deseja excluir este bairro?')) return;
  try {
    await api(`/api/bairros/${id}`, {}, { method: 'DELETE' });
    showToast('Bairro excluído!', 'success');
    loadBairros();
  } catch (err) {
    showToast('Erro: ' + err.message, 'error');
  }
}

// ─── CLIENTES ───────────────────────────────────

async function loadClientes() {
  try {
    const clientesData = await api('/api/clientes');
    const container = document.getElementById('clientesLista');

    if (clientesData.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhum cliente registrado ainda</p>';
      return;
    }

    container.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Telefone</th>
            <th>Endereço</th>
            <th>Pedidos</th>
            <th>Total Gasto</th>
          </tr>
        </thead>
        <tbody>
          ${clientesData.map(c => `
            <tr>
              <td><strong>${c.nome || 'Sem nome'}</strong></td>
              <td>${formatPhone(c.telefone)}</td>
              <td>${c.endereco || '-'}</td>
              <td>${c.total_pedidos}</td>
              <td><strong>R$ ${c.total_gasto.toFixed(2)}</strong></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (err) {
    console.error('Erro ao carregar clientes:', err);
  }
}

// ─── WHATSAPP ───────────────────────────────────

async function loadWhatsappStatus() {
  try {
    const status = await api('/api/status');
    if (status.status === 'connected') {
      showConnected();
    } else if (status.status === 'qr_ready' && status.qrCode) {
      updateQRCode(status.qrCode);
    }
  } catch (err) {
    console.error('Erro ao carregar status WhatsApp:', err);
  }
}

function updateQRCode(qr) {
  const container = document.getElementById('qrContainer');
  container.innerHTML = '<p><strong>Escaneie o QR Code com seu WhatsApp:</strong></p><p class="text-muted">Abra o WhatsApp > Menu > Dispositivos conectados > Conectar dispositivo</p><div id="qrCodeDiv" style="margin:20px auto;display:inline-block"></div>';
  container.style.display = 'flex';
  document.getElementById('connectedInfo').style.display = 'none';

  const qrDiv = document.getElementById('qrCodeDiv');
  if (qrCodeInstance) {
    qrCodeInstance.clear();
    qrCodeInstance.makeCode(qr);
  } else {
    qrCodeInstance = new QRCode(qrDiv, {
      text: qr,
      width: 256,
      height: 256,
      colorDark: '#000000',
      colorLight: '#ffffff',
    });
  }
}

function showConnected() {
  document.getElementById('qrContainer').style.display = 'none';
  document.getElementById('connectedInfo').style.display = 'block';
}

async function handleDesconectar() {
  if (!confirm('Tem certeza que deseja desconectar o WhatsApp?')) return;
  showToast('Funcionalidade de desconexão via painel.', 'info');
}

// ─── CONFIG ─────────────────────────────────────

async function loadConfig() {
  try {
    const cfg = await api('/api/config');
    document.getElementById('cfgNome').value = cfg.loja.nome;
    document.getElementById('cfgEndereco').value = cfg.loja.endereco;
    document.getElementById('cfgTelefone').value = cfg.loja.telefone;
    document.getElementById('cfgAbertura').value = cfg.loja.horarioAbertura;
    document.getElementById('cfgFechamento').value = cfg.loja.horarioFechamento;
    document.getElementById('cfgTaxa').value = cfg.loja.taxaEntrega;
    document.getElementById('cfgMinimo').value = cfg.loja.pedidoMinimo;
    document.getElementById('cfgTempoMin').value = cfg.loja.tempoEstimadoMin;
    document.getElementById('cfgTempoMax').value = cfg.loja.tempoEstimadoMax;
    document.getElementById('cfgPixChave').value = cfg.pix.chave;
    document.getElementById('cfgPixTipo').value = cfg.pix.tipo;
    document.getElementById('cfgPixTitular').value = cfg.pix.titular;
  } catch (err) {
    console.error('Erro ao carregar config:', err);
  }
}

async function handleSaveConfig(e) {
  e.preventDefault();
  try {
    await api('/api/config/loja', {}, {
      method: 'PUT',
      body: JSON.stringify({
        nome: document.getElementById('cfgNome').value,
        endereco: document.getElementById('cfgEndereco').value,
        telefone: document.getElementById('cfgTelefone').value,
        horarioAbertura: document.getElementById('cfgAbertura').value,
        horarioFechamento: document.getElementById('cfgFechamento').value,
        taxaEntrega: parseFloat(document.getElementById('cfgTaxa').value),
        pedidoMinimo: parseFloat(document.getElementById('cfgMinimo').value),
        tempoEstimadoMin: parseInt(document.getElementById('cfgTempoMin').value),
        tempoEstimadoMax: parseInt(document.getElementById('cfgTempoMax').value),
      }),
    });
    showToast('Configurações salvas!', 'success');
  } catch (err) {
    showToast('Erro ao salvar: ' + err.message, 'error');
  }
}

// ─── STATUS ─────────────────────────────────────

function updateStatusIndicator(status, message) {
  const indicator = document.getElementById('statusIndicator');
  const dot = indicator.querySelector('.status-dot');
  const text = indicator.querySelector('span:last-child');

  dot.className = `status-dot ${status}`;
  const labels = {
    connected: 'Conectado',
    disconnected: 'Desconectado',
    qr_ready: 'Aguardando QR',
    error: 'Erro',
  };
  text.textContent = labels[status] || message || status;
}

// ─── LICENÇA ────────────────────────────────────

async function carregarLicenca() {
  try {
    const res = await fetch('/api/licenca/info');
    const data = await res.json();

    const whidEl = document.getElementById('licWhid');
    const contraEl = document.getElementById('licContraChave');
    if (whidEl) whidEl.value = data.whid;
    if (contraEl) contraEl.value = data.contraChave;

    atualizarUILicenca({
      valida: data.licenca.valida,
      whid: data.whid,
      contraChave: data.contraChave,
      expiraEm: data.licenca.expiraEm,
      diasRestantes: data.licenca.diasRestantes,
      semLicenca: data.licenca.semLicenca,
      erro: data.licenca.erro,
    });
  } catch (err) {
    console.error('Erro ao carregar licença:', err);
  }
}

function atualizarUILicenca(data) {
  licencaValida = data.valida;

  const banner = document.getElementById('licBanner');
  const bannerIcon = document.getElementById('licBannerIcon');
  const bannerTitle = document.getElementById('licBannerTitle');
  const bannerDesc = document.getElementById('licBannerDesc');
  const infoAtiva = document.getElementById('licInfoAtiva');
  const badgeLic = document.getElementById('badgeLicenca');

  if (!banner) return;

  if (data.valida) {
    if (data.diasRestantes <= 5) {
      banner.className = 'license-banner license-warning';
      bannerIcon.className = 'fas fa-exclamation-triangle';
      bannerTitle.textContent = `Licença expira em ${data.diasRestantes} dia(s)!`;
      bannerDesc.textContent = 'Contate o administrador para renovar sua licença.';
      if (badgeLic) { badgeLic.style.display = 'inline'; badgeLic.textContent = data.diasRestantes; }
    } else {
      banner.className = 'license-banner license-active';
      bannerIcon.className = 'fas fa-shield-alt';
      bannerTitle.textContent = 'Sistema Licenciado';
      bannerDesc.textContent = `Licença válida por mais ${data.diasRestantes} dia(s).`;
      if (badgeLic) badgeLic.style.display = 'none';
    }

    if (infoAtiva) infoAtiva.style.display = 'block';
    const detalheStatus = document.getElementById('licDetalheStatus');
    const detalheExpira = document.getElementById('licDetalheExpira');
    const detalheDias = document.getElementById('licDetalheDias');
    if (detalheStatus) { detalheStatus.textContent = 'Ativa'; detalheStatus.style.color = '#28a745'; }
    if (detalheExpira) detalheExpira.textContent = data.expiraEm ? new Date(data.expiraEm).toLocaleDateString('pt-BR') : '-';
    if (detalheDias) { detalheDias.textContent = `${data.diasRestantes} dias`; detalheDias.style.color = data.diasRestantes <= 5 ? '#dc3545' : '#28a745'; }

    removerOverlayBloqueio();
  } else {
    banner.className = 'license-banner license-blocked';
    bannerIcon.className = 'fas fa-lock';
    bannerTitle.textContent = 'Sistema Bloqueado';
    bannerDesc.textContent = data.erro || 'Ative sua licença para utilizar o sistema.';
    if (badgeLic) { badgeLic.style.display = 'inline'; badgeLic.textContent = '!'; }
    if (infoAtiva) infoAtiva.style.display = 'none';
  }
}

async function ativarLicenca() {
  const chave = document.getElementById('licChave').value.trim();
  const resultadoDiv = document.getElementById('licResultado');

  if (!chave) {
    resultadoDiv.style.display = 'block';
    resultadoDiv.innerHTML = '<div style="background:#f8d7da;color:#721c24;padding:12px;border-radius:8px;"><strong>Erro:</strong> Cole a chave de licença antes de ativar.</div>';
    return;
  }

  resultadoDiv.style.display = 'block';
  resultadoDiv.innerHTML = '<div style="background:#d1ecf1;color:#0c5460;padding:12px;border-radius:8px;"><i class="fas fa-spinner fa-spin"></i> Validando licença...</div>';

  try {
    const res = await fetch('/api/licenca/ativar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: chave }),
    });

    const data = await res.json();

    if (res.ok && data.success) {
      resultadoDiv.innerHTML = `<div style="background:#d4edda;color:#155724;padding:12px;border-radius:8px;">
        <strong>Licença ativada com sucesso!</strong><br>
        Expira em: ${new Date(data.expiraEm).toLocaleDateString('pt-BR')}<br>
        Dias restantes: ${data.diasRestantes}
      </div>`;
      showToast('Licença ativada com sucesso!', 'success');
      licencaValida = true;
      carregarLicenca();
      removerOverlayBloqueio();
    } else {
      resultadoDiv.innerHTML = `<div style="background:#f8d7da;color:#721c24;padding:12px;border-radius:8px;">
        <strong>Erro:</strong> ${data.error}
      </div>`;
      showToast('Erro ao ativar licença', 'error');
    }
  } catch (err) {
    resultadoDiv.innerHTML = `<div style="background:#f8d7da;color:#721c24;padding:12px;border-radius:8px;">
      <strong>Erro:</strong> Falha na comunicação com o servidor.
    </div>`;
  }
}

function copiarCampo(id) {
  const el = document.getElementById(id);
  el.select();
  document.execCommand('copy');
  showToast('Copiado!', 'success');
}

function copiarDadosMaquina() {
  const whid = document.getElementById('licWhid').value;
  const contra = document.getElementById('licContraChave').value;
  const texto = `WHID: ${whid}\nContra-Chave: ${contra}`;
  navigator.clipboard.writeText(texto).then(() => {
    showToast('WHID e Contra-Chave copiados!', 'success');
  }).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = texto;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast('WHID e Contra-Chave copiados!', 'success');
  });
}

function mostrarOverlayBloqueio() {
  if (document.getElementById('licenseOverlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'licenseOverlay';
  overlay.className = 'license-overlay';
  overlay.innerHTML = `
    <div class="license-overlay-content">
      <div class="lock-icon"><i class="fas fa-lock"></i></div>
      <h2>Sistema Bloqueado</h2>
      <p>Sua licença expirou ou não foi ativada.<br>Contate o administrador para obter uma nova licença.</p>
      <button class="btn btn-primary" onclick="navigateTo('licenca');removerOverlayBloqueio();">Ir para Licença</button>
    </div>
  `;
  document.body.appendChild(overlay);
}

function removerOverlayBloqueio() {
  const overlay = document.getElementById('licenseOverlay');
  if (overlay) overlay.remove();
}

// ─── HELPERS ────────────────────────────────────

function openModal() { document.getElementById('modal').style.display = 'flex'; }
function closeModal() { document.getElementById('modal').style.display = 'none'; }

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatPhone(phone) {
  if (!phone) return '';
  // Remove qualquer sufixo (@lid, @s.whatsapp.net) e mantém só dígitos
  const clean = String(phone).replace(/\D/g, '');
  if (clean.length === 13) return `(${clean.slice(2,4)}) ${clean.slice(4,5)} ${clean.slice(5,9)}-${clean.slice(9)}`;
  if (clean.length === 12) return `(${clean.slice(2,4)}) ${clean.slice(4,8)}-${clean.slice(8)}`;
  if (clean.length === 11) return `(${clean.slice(0,2)}) ${clean.slice(2,3)} ${clean.slice(3,7)}-${clean.slice(7)}`;
  if (clean.length === 10) return `(${clean.slice(0,2)}) ${clean.slice(2,6)}-${clean.slice(6)}`;
  // Não é um telefone reconhecível: mostra só os dígitos (nunca o "@lid")
  return clean || '';
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const icons = {
    success: 'fas fa-check-circle',
    error: 'fas fa-exclamation-circle',
    warning: 'fas fa-exclamation-triangle',
    info: 'fas fa-info-circle',
  };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="${icons[type]} toast-icon"></i><span class="toast-message">${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function playNotification() {
  try {
    const audio = document.getElementById('notificationSound');
    audio.currentTime = 0;
    audio.play().catch(() => {});
  } catch (e) {}
  // Fallback: Web Audio API beep
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    // Play 3 beeps
    [0, 0.3, 0.6].forEach(delay => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      osc.type = 'sine';
      gain.gain.value = 0.3;
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.2);
    });
  } catch (e) {}
}

function updateBadge() {
  // Badge will be updated on next dashboard load
}

function startClock() {
  const update = () => {
    const now = new Date();
    document.getElementById('clockDisplay').textContent = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };
  update();
  setInterval(update, 30000);
}


// ─── HWID / CONTRA-CHAVE NA TELA DE LOGIN ──────

async function carregarLicencaLogin() {
  try {
    const res = await fetch('/api/licenca/info');
    const data = await res.json();

    const whidEl = document.getElementById('loginWhid');
    const contraEl = document.getElementById('loginContraChave');
    if (whidEl) whidEl.value = data.whid || '';
    if (contraEl) contraEl.value = data.contraChave || '';
  } catch (err) {
    console.error('Erro ao carregar dados de licença no login:', err);
    const whidEl = document.getElementById('loginWhid');
    const contraEl = document.getElementById('loginContraChave');
    if (whidEl) whidEl.placeholder = 'Erro ao carregar';
    if (contraEl) contraEl.placeholder = 'Erro ao carregar';
  }
}

function copiarLoginCampo(id) {
  const el = document.getElementById(id);
  if (!el || !el.value) return;

  const texto = el.value;
  const btn = el.parentElement.querySelector('.btn-copy');

  // Tentar usar a API moderna de clipboard
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(texto).then(() => {
      mostrarCopiado(btn);
    }).catch(() => {
      copiarFallback(el, btn);
    });
  } else {
    copiarFallback(el, btn);
  }
}

function copiarFallback(el, btn) {
  el.select();
  el.setSelectionRange(0, 99999);
  document.execCommand('copy');
  mostrarCopiado(btn);
}

function mostrarCopiado(btn) {
  if (!btn) return;
  const textoOriginal = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
  btn.classList.add('copied');
  setTimeout(() => {
    btn.innerHTML = textoOriginal;
    btn.classList.remove('copied');
  }, 2000);
  showToast('Copiado para a área de transferência!', 'success');
}
