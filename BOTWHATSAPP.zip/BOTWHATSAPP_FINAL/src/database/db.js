/**
 * ============================================
 *  BANCO DE DADOS - SQLite com better-sqlite3
 *  (Otimizado para performance)
 * ============================================
 */

const Database = require('better-sqlite3');
const path = require('path');
const dayjs = require('dayjs');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', '..', 'data', 'fastfood.db');

// Garantir que o diretório data existe
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(DB_PATH);

// ─── PRAGMAS DE PERFORMANCE ───────────────────────
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');
db.pragma('cache_size = -8000');       // 8MB de cache
db.pragma('temp_store = MEMORY');
db.pragma('mmap_size = 268435456');    // 256MB mmap

// ─── CRIAR TABELAS ─────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    emoji TEXT DEFAULT '🍽️',
    ordem INTEGER DEFAULT 0,
    ativa INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    categoria_id INTEGER NOT NULL,
    nome TEXT NOT NULL,
    descricao TEXT DEFAULT '',
    preco REAL NOT NULL,
    disponivel INTEGER DEFAULT 1,
    destaque INTEGER DEFAULT 0,
    ordem INTEGER DEFAULT 0,
    criado_em TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
  );

  CREATE TABLE IF NOT EXISTS adicionais (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    preco REAL NOT NULL,
    disponivel INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telefone TEXT UNIQUE NOT NULL,
    nome TEXT DEFAULT '',
    endereco TEXT DEFAULT '',
    complemento TEXT DEFAULT '',
    referencia TEXT DEFAULT '',
    total_pedidos INTEGER DEFAULT 0,
    total_gasto REAL DEFAULT 0,
    ultimo_pedido TEXT DEFAULT '',
    criado_em TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT UNIQUE NOT NULL,
    cliente_id INTEGER NOT NULL,
    telefone TEXT NOT NULL,
    nome_cliente TEXT DEFAULT '',
    endereco TEXT DEFAULT '',
    complemento TEXT DEFAULT '',
    referencia TEXT DEFAULT '',
    itens TEXT NOT NULL,
    observacao TEXT DEFAULT '',
    subtotal REAL NOT NULL,
    taxa_entrega REAL DEFAULT 0,
    total REAL NOT NULL,
    forma_pagamento TEXT NOT NULL,
    troco_para REAL DEFAULT 0,
    status TEXT DEFAULT 'pendente',
    hora_pedido TEXT DEFAULT (datetime('now', 'localtime')),
    hora_confirmado TEXT DEFAULT '',
    hora_saiu_entrega TEXT DEFAULT '',
    hora_entregue TEXT DEFAULT '',
    avaliacao INTEGER DEFAULT 0,
    impresso INTEGER DEFAULT 0,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
  );

  CREATE TABLE IF NOT EXISTS configuracoes (
    chave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS promocoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    descricao TEXT DEFAULT '',
    desconto_percentual REAL DEFAULT 0,
    desconto_valor REAL DEFAULT 0,
    ativa INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT (datetime('now', 'localtime'))
  );
`);

// ─── ÍNDICES PARA CONSULTAS FREQUENTES ────────────
db.exec(`
  CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria_id, disponivel);
  CREATE INDEX IF NOT EXISTS idx_produtos_disponivel ON produtos(disponivel);
  CREATE INDEX IF NOT EXISTS idx_clientes_telefone ON clientes(telefone);
  CREATE INDEX IF NOT EXISTS idx_pedidos_codigo ON pedidos(codigo);
  CREATE INDEX IF NOT EXISTS idx_pedidos_telefone ON pedidos(telefone);
  CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status);
  CREATE INDEX IF NOT EXISTS idx_pedidos_hora ON pedidos(hora_pedido);
  CREATE INDEX IF NOT EXISTS idx_categorias_ativa ON categorias(ativa, ordem);
`);

// ─── PREPARED STATEMENTS (pré-compilados uma única vez) ───────

const stmts = {
  // Categorias
  categoriasListarAtivas: db.prepare('SELECT * FROM categorias WHERE ativa = 1 ORDER BY ordem, nome'),
  categoriasListarTodas: db.prepare('SELECT * FROM categorias ORDER BY ordem, nome'),
  categoriasBuscarPorId: db.prepare('SELECT * FROM categorias WHERE id = ?'),
  categoriasCriar: db.prepare('INSERT INTO categorias (nome, emoji, ordem) VALUES (?, ?, ?)'),
  categoriasAtualizar: db.prepare('UPDATE categorias SET nome = ?, emoji = ?, ordem = ?, ativa = ? WHERE id = ?'),
  categoriasExcluir: db.prepare('UPDATE categorias SET ativa = 0 WHERE id = ?'),

  // Produtos
  produtosListar: db.prepare(`
    SELECT p.*, c.nome as categoria_nome, c.emoji as categoria_emoji 
    FROM produtos p 
    JOIN categorias c ON p.categoria_id = c.id 
    WHERE p.disponivel = 1 AND c.ativa = 1
    ORDER BY c.ordem, p.ordem, p.nome
  `),
  produtosListarTodos: db.prepare(`
    SELECT p.*, c.nome as categoria_nome, c.emoji as categoria_emoji 
    FROM produtos p 
    JOIN categorias c ON p.categoria_id = c.id 
    ORDER BY c.ordem, p.ordem, p.nome
  `),
  produtosBuscarPorId: db.prepare('SELECT * FROM produtos WHERE id = ?'),
  produtosBuscarPorCategoria: db.prepare('SELECT * FROM produtos WHERE categoria_id = ? AND disponivel = 1 ORDER BY ordem, nome'),
  produtosBuscarPorNome: db.prepare("SELECT * FROM produtos WHERE disponivel = 1 AND nome LIKE ? ORDER BY nome"),
  produtosContarPorCategoria: db.prepare('SELECT COUNT(*) as total FROM produtos WHERE categoria_id = ? AND disponivel = 1'),
  produtosCriar: db.prepare('INSERT INTO produtos (categoria_id, nome, descricao, preco, ordem) VALUES (?, ?, ?, ?, ?)'),
  produtosAtualizar: db.prepare('UPDATE produtos SET categoria_id = ?, nome = ?, descricao = ?, preco = ?, disponivel = ?, destaque = ?, ordem = ? WHERE id = ?'),
  produtosBuscarDisponivel: db.prepare('SELECT disponivel FROM produtos WHERE id = ?'),
  produtosSetDisponivel: db.prepare('UPDATE produtos SET disponivel = ? WHERE id = ?'),
  produtosExcluir: db.prepare('DELETE FROM produtos WHERE id = ?'),

  // Adicionais
  adicionaisListar: db.prepare('SELECT * FROM adicionais WHERE disponivel = 1 ORDER BY nome'),
  adicionaisListarTodos: db.prepare('SELECT * FROM adicionais ORDER BY nome'),
  adicionaisCriar: db.prepare('INSERT INTO adicionais (nome, preco) VALUES (?, ?)'),
  adicionaisAtualizar: db.prepare('UPDATE adicionais SET nome = ?, preco = ?, disponivel = ? WHERE id = ?'),
  adicionaisExcluir: db.prepare('DELETE FROM adicionais WHERE id = ?'),

  // Clientes
  clientesBuscarPorTelefone: db.prepare('SELECT * FROM clientes WHERE telefone = ?'),
  clientesInserir: db.prepare('INSERT INTO clientes (telefone, nome) VALUES (?, ?)'),
  clientesAtualizarNome: db.prepare('UPDATE clientes SET nome = ? WHERE telefone = ?'),
  clientesAtualizarEndereco: db.prepare('UPDATE clientes SET endereco = ?, complemento = ?, referencia = ? WHERE telefone = ?'),
  clientesListar: db.prepare('SELECT * FROM clientes ORDER BY total_pedidos DESC'),
  clientesAtualizarEstatisticas: db.prepare(`
    UPDATE clientes SET 
      total_pedidos = total_pedidos + 1, 
      total_gasto = total_gasto + ?,
      ultimo_pedido = datetime('now', 'localtime')
    WHERE id = ?
  `),

  // Pedidos
  pedidosCriar: db.prepare(`
    INSERT INTO pedidos (codigo, cliente_id, telefone, nome_cliente, endereco, complemento, referencia, 
      itens, observacao, subtotal, taxa_entrega, total, forma_pagamento, troco_para)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `),
  pedidosBuscarPorCodigo: db.prepare('SELECT * FROM pedidos WHERE codigo = ?'),
  pedidosBuscarPorTelefone: db.prepare('SELECT * FROM pedidos WHERE telefone = ? ORDER BY id DESC'),
  pedidosBuscarUltimoPorTelefone: db.prepare('SELECT * FROM pedidos WHERE telefone = ? ORDER BY id DESC LIMIT 1'),
  pedidosListarPendentes: db.prepare("SELECT * FROM pedidos WHERE status IN ('pendente', 'confirmado', 'em_preparo', 'saiu_entrega') ORDER BY id DESC"),
  pedidosListarHoje: db.prepare("SELECT * FROM pedidos WHERE date(hora_pedido) = date('now', 'localtime') ORDER BY id DESC"),
  pedidosListarTodos: db.prepare('SELECT * FROM pedidos ORDER BY id DESC LIMIT ?'),
  pedidosAtualizarStatusComHora: {
    confirmado: db.prepare("UPDATE pedidos SET status = ?, hora_confirmado = datetime('now', 'localtime') WHERE id = ?"),
    em_preparo: db.prepare("UPDATE pedidos SET status = ?, hora_confirmado = datetime('now', 'localtime') WHERE id = ?"),
    saiu_entrega: db.prepare("UPDATE pedidos SET status = ?, hora_saiu_entrega = datetime('now', 'localtime') WHERE id = ?"),
    entregue: db.prepare("UPDATE pedidos SET status = ?, hora_entregue = datetime('now', 'localtime') WHERE id = ?"),
    cancelado: db.prepare("UPDATE pedidos SET status = ?, hora_entregue = datetime('now', 'localtime') WHERE id = ?"),
  },
  pedidosAtualizarStatus: db.prepare('UPDATE pedidos SET status = ? WHERE id = ?'),
  pedidosBuscarPorId: db.prepare('SELECT * FROM pedidos WHERE id = ?'),
  pedidosMarcarImpresso: db.prepare('UPDATE pedidos SET impresso = 1 WHERE id = ?'),
  pedidosAvaliar: db.prepare('UPDATE pedidos SET avaliacao = ? WHERE codigo = ?'),
  pedidosUltimoCodigoHoje: db.prepare("SELECT codigo FROM pedidos WHERE date(hora_pedido) = date('now', 'localtime') ORDER BY id DESC LIMIT 1"),
  pedidosEstatisticasHoje: db.prepare(`
    SELECT 
      COUNT(*) as total_pedidos,
      COALESCE(SUM(total), 0) as faturamento,
      COALESCE(AVG(total), 0) as ticket_medio,
      COUNT(CASE WHEN status = 'entregue' THEN 1 END) as entregues,
      COUNT(CASE WHEN status = 'cancelado' THEN 1 END) as cancelados,
      COUNT(CASE WHEN status IN ('pendente', 'confirmado', 'em_preparo', 'saiu_entrega') THEN 1 END) as em_andamento
    FROM pedidos WHERE date(hora_pedido) = ?
  `),

  // Configurações
  configGet: db.prepare('SELECT valor FROM configuracoes WHERE chave = ?'),
  configSet: db.prepare('INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?, ?)'),

  // Seed
  categoriasCount: db.prepare('SELECT COUNT(*) as c FROM categorias'),
};

// ─── CACHE EM MEMÓRIA PARA DADOS FREQUENTES ───────

const cache = {
  categorias: null,
  categoriasTimestamp: 0,
  produtosPorCategoria: new Map(),
  produtosTimestamp: 0,
  TTL: 30 * 1000, // 30 segundos de cache
};

function invalidarCache() {
  cache.categorias = null;
  cache.categoriasTimestamp = 0;
  cache.produtosPorCategoria.clear();
  cache.produtosTimestamp = 0;
}

// ─── FUNÇÕES DE CATEGORIAS ──────────────────────

const categorias = {
  listar: () => {
    const agora = Date.now();
    if (cache.categorias && (agora - cache.categoriasTimestamp) < cache.TTL) {
      return cache.categorias;
    }
    cache.categorias = stmts.categoriasListarAtivas.all();
    cache.categoriasTimestamp = agora;
    return cache.categorias;
  },
  listarTodas: () => stmts.categoriasListarTodas.all(),
  buscarPorId: (id) => stmts.categoriasBuscarPorId.get(id),
  criar: (dados) => {
    invalidarCache();
    return stmts.categoriasCriar.run(dados.nome, dados.emoji || '🍽️', dados.ordem || 0);
  },
  atualizar: (id, dados) => {
    invalidarCache();
    return stmts.categoriasAtualizar.run(dados.nome, dados.emoji, dados.ordem, dados.ativa ? 1 : 0, id);
  },
  excluir: (id) => {
    invalidarCache();
    return stmts.categoriasExcluir.run(id);
  },
};

// ─── FUNÇÕES DE PRODUTOS ────────────────────────

const produtos = {
  listar: () => stmts.produtosListar.all(),
  listarTodos: () => stmts.produtosListarTodos.all(),
  buscarPorId: (id) => stmts.produtosBuscarPorId.get(id),
  buscarPorCategoria: (catId) => {
    const agora = Date.now();
    const cacheKey = catId;
    const cached = cache.produtosPorCategoria.get(cacheKey);
    if (cached && (agora - cache.produtosTimestamp) < cache.TTL) {
      return cached;
    }
    const result = stmts.produtosBuscarPorCategoria.all(catId);
    cache.produtosPorCategoria.set(cacheKey, result);
    cache.produtosTimestamp = agora;
    return result;
  },
  contarPorCategoria: (catId) => stmts.produtosContarPorCategoria.get(catId).total,
  buscarPorNome: (termo) => stmts.produtosBuscarPorNome.all(`%${termo}%`),
  criar: (dados) => {
    invalidarCache();
    return stmts.produtosCriar.run(dados.categoria_id, dados.nome, dados.descricao || '', dados.preco, dados.ordem || 0);
  },
  atualizar: (id, dados) => {
    invalidarCache();
    return stmts.produtosAtualizar.run(dados.categoria_id, dados.nome, dados.descricao, dados.preco, dados.disponivel ? 1 : 0, dados.destaque ? 1 : 0, dados.ordem || 0, id);
  },
  toggleDisponivel: (id) => {
    const produto = stmts.produtosBuscarDisponivel.get(id);
    if (produto) {
      stmts.produtosSetDisponivel.run(produto.disponivel ? 0 : 1, id);
      invalidarCache();
    }
    return produto;
  },
  excluir: (id) => {
    invalidarCache();
    return stmts.produtosExcluir.run(id);
  },
};

// ─── FUNÇÕES DE ADICIONAIS ──────────────────────

const adicionais = {
  listar: () => stmts.adicionaisListar.all(),
  listarTodos: () => stmts.adicionaisListarTodos.all(),
  criar: (dados) => stmts.adicionaisCriar.run(dados.nome, dados.preco),
  atualizar: (id, dados) => stmts.adicionaisAtualizar.run(dados.nome, dados.preco, dados.disponivel ? 1 : 0, id),
  excluir: (id) => stmts.adicionaisExcluir.run(id),
};

// ─── FUNÇÕES DE CLIENTES ────────────────────────

const criarOuAtualizarCliente = db.transaction((telefone, dados) => {
  let cliente = stmts.clientesBuscarPorTelefone.get(telefone);
  if (!cliente) {
    stmts.clientesInserir.run(telefone, dados.nome || '');
    cliente = stmts.clientesBuscarPorTelefone.get(telefone);
  } else if (dados.nome && dados.nome !== cliente.nome) {
    stmts.clientesAtualizarNome.run(dados.nome, telefone);
    cliente.nome = dados.nome;
  }
  return cliente;
});

const clientes = {
  buscarPorTelefone: (telefone) => stmts.clientesBuscarPorTelefone.get(telefone),
  criarOuAtualizar: (telefone, dados = {}) => criarOuAtualizarCliente(telefone, dados),
  atualizarEndereco: (telefone, endereco, complemento, referencia) => {
    stmts.clientesAtualizarEndereco.run(endereco, complemento || '', referencia || '', telefone);
  },
  listar: () => stmts.clientesListar.all(),
  atualizarEstatisticas: (clienteId, total) => {
    stmts.clientesAtualizarEstatisticas.run(total, clienteId);
  },
};

// ─── FUNÇÕES DE PEDIDOS ─────────────────────────

const criarPedidoTransaction = db.transaction((codigo, dados) => {
  stmts.pedidosCriar.run(
    codigo, dados.cliente_id, dados.telefone, dados.nome_cliente || '',
    dados.endereco || '', dados.complemento || '', dados.referencia || '',
    JSON.stringify(dados.itens), dados.observacao || '',
    dados.subtotal, dados.taxa_entrega || 0, dados.total,
    dados.forma_pagamento, dados.troco_para || 0
  );
  stmts.clientesAtualizarEstatisticas.run(dados.total, dados.cliente_id);
  return stmts.pedidosBuscarPorCodigo.get(codigo);
});

const pedidos = {
  criar: (dados) => {
    const codigo = gerarCodigoPedido();
    return criarPedidoTransaction(codigo, dados);
  },

  buscarPorCodigo: (codigo) => stmts.pedidosBuscarPorCodigo.get(codigo),
  buscarPorTelefone: (telefone) => stmts.pedidosBuscarPorTelefone.all(telefone),
  buscarUltimoPorTelefone: (telefone) => stmts.pedidosBuscarUltimoPorTelefone.get(telefone),

  listarPendentes: () => stmts.pedidosListarPendentes.all(),
  listarHoje: () => stmts.pedidosListarHoje.all(),
  listarTodos: (limit = 50) => stmts.pedidosListarTodos.all(limit),

  atualizarStatus: (id, status) => {
    const stmtComHora = stmts.pedidosAtualizarStatusComHora[status];
    if (stmtComHora) {
      stmtComHora.run(status, id);
    } else {
      stmts.pedidosAtualizarStatus.run(status, id);
    }
    return stmts.pedidosBuscarPorId.get(id);
  },

  marcarImpresso: (id) => stmts.pedidosMarcarImpresso.run(id),
  avaliar: (codigo, nota) => stmts.pedidosAvaliar.run(nota, codigo),

  estatisticasHoje: () => {
    const hoje = dayjs().format('YYYY-MM-DD');
    return stmts.pedidosEstatisticasHoje.get(hoje);
  },
};

// ─── FUNÇÕES DE CONFIGURAÇÕES ───────────────────

const configuracoes = {
  get: (chave, padrao = '') => {
    const row = stmts.configGet.get(chave);
    return row ? row.valor : padrao;
  },
  set: (chave, valor) => {
    stmts.configSet.run(chave, String(valor));
  },
};

// ─── HELPERS ────────────────────────────────────

function gerarCodigoPedido() {
  const hoje = dayjs().format('DDMM');
  const ultimo = stmts.pedidosUltimoCodigoHoje.get();
  let seq = 1;
  if (ultimo && ultimo.codigo) {
    const parts = ultimo.codigo.split('-');
    if (parts.length === 2) {
      seq = parseInt(parts[1]) + 1;
    }
  }
  return `${hoje}-${String(seq).padStart(3, '0')}`;
}

// ─── SEED INICIAL (DADOS DE EXEMPLO) ───────────

function seedInicial() {
  const catCount = stmts.categoriasCount.get().c;
  if (catCount > 0) return;

  console.log('📦 Inserindo dados iniciais de exemplo...');

  const inserirSeed = db.transaction(() => {
    // Categorias
    stmts.categoriasCriar.run('Hambúrgueres', '🍔', 1);
    stmts.categoriasCriar.run('Pizzas', '🍕', 2);
    stmts.categoriasCriar.run('Porções', '🍟', 3);
    stmts.categoriasCriar.run('Bebidas', '🥤', 4);
    stmts.categoriasCriar.run('Sobremesas', '🍰', 5);
    stmts.categoriasCriar.run('Combos', '🎁', 6);

    // Produtos - Hambúrgueres
    stmts.produtosCriar.run(1, 'X-Burguer', 'Pão, hambúrguer, queijo, alface, tomate e maionese', 18.90, 1);
    stmts.produtosCriar.run(1, 'X-Bacon', 'Pão, hambúrguer, queijo, bacon crocante, alface, tomate e maionese', 22.90, 2);
    stmts.produtosCriar.run(1, 'X-Tudo', 'Pão, 2 hambúrgueres, queijo, bacon, ovo, presunto, alface, tomate, milho e maionese', 28.90, 3);
    stmts.produtosCriar.run(1, 'X-Salada', 'Pão, hambúrguer, queijo, alface, tomate, cebola e maionese', 16.90, 4);
    stmts.produtosCriar.run(1, 'X-Frango', 'Pão, filé de frango grelhado, queijo, alface, tomate e maionese especial', 20.90, 5);

    // Produtos - Pizzas
    stmts.produtosCriar.run(2, 'Pizza Calabresa', 'Molho, mussarela, calabresa e cebola', 35.90, 1);
    stmts.produtosCriar.run(2, 'Pizza Margherita', 'Molho, mussarela, tomate e manjericão', 33.90, 2);
    stmts.produtosCriar.run(2, 'Pizza Frango c/ Catupiry', 'Molho, mussarela, frango desfiado e catupiry', 38.90, 3);
    stmts.produtosCriar.run(2, 'Pizza Portuguesa', 'Molho, mussarela, presunto, ovo, cebola, azeitona e ervilha', 37.90, 4);

    // Produtos - Porções
    stmts.produtosCriar.run(3, 'Batata Frita', 'Porção de batata frita crocante (300g)', 15.90, 1);
    stmts.produtosCriar.run(3, 'Batata Frita c/ Cheddar e Bacon', 'Batata frita com cheddar cremoso e bacon (400g)', 22.90, 2);
    stmts.produtosCriar.run(3, 'Nuggets (12 un)', '12 nuggets de frango crocantes', 19.90, 3);
    stmts.produtosCriar.run(3, 'Onion Rings', 'Anéis de cebola empanados (250g)', 17.90, 4);

    // Produtos - Bebidas
    stmts.produtosCriar.run(4, 'Coca-Cola Lata', 'Coca-Cola 350ml', 6.00, 1);
    stmts.produtosCriar.run(4, 'Coca-Cola 600ml', 'Coca-Cola 600ml', 8.00, 2);
    stmts.produtosCriar.run(4, 'Guaraná Lata', 'Guaraná Antarctica 350ml', 5.50, 3);
    stmts.produtosCriar.run(4, 'Suco Natural', 'Suco natural de laranja 500ml', 9.90, 4);
    stmts.produtosCriar.run(4, 'Água Mineral', 'Água mineral 500ml', 3.50, 5);

    // Produtos - Sobremesas
    stmts.produtosCriar.run(5, 'Milk Shake Chocolate', 'Milk shake de chocolate 400ml', 14.90, 1);
    stmts.produtosCriar.run(5, 'Milk Shake Morango', 'Milk shake de morango 400ml', 14.90, 2);
    stmts.produtosCriar.run(5, 'Sundae', 'Sorvete com calda de chocolate e granulado', 10.90, 3);

    // Produtos - Combos
    stmts.produtosCriar.run(6, 'Combo 1 - X-Burguer', 'X-Burguer + Batata Frita + Coca Lata', 32.90, 1);
    stmts.produtosCriar.run(6, 'Combo 2 - X-Bacon', 'X-Bacon + Batata Frita + Coca Lata', 36.90, 2);
    stmts.produtosCriar.run(6, 'Combo 3 - X-Tudo', 'X-Tudo + Batata c/ Cheddar + Coca 600ml', 48.90, 3);

    // Adicionais
    stmts.adicionaisCriar.run('Bacon Extra', 4.00);
    stmts.adicionaisCriar.run('Queijo Extra', 3.00);
    stmts.adicionaisCriar.run('Ovo', 2.50);
    stmts.adicionaisCriar.run('Cheddar', 3.50);
    stmts.adicionaisCriar.run('Hambúrguer Extra', 6.00);
    stmts.adicionaisCriar.run('Catupiry', 3.00);
  });

  inserirSeed();
  console.log('✅ Dados iniciais inseridos com sucesso!');
}

seedInicial();

// ─── GRACEFUL SHUTDOWN ────────────────────────────

process.on('exit', () => {
  try { db.close(); } catch (e) { /* silenciar */ }
});

module.exports = {
  db,
  categorias,
  produtos,
  adicionais,
  clientes,
  pedidos,
  configuracoes,
  invalidarCache,
};
