/**
 * ============================================
 *  ROTAS DA API - Painel Administrativo
 *  (Otimizado para performance)
 * ============================================
 */

const express = require('express');
const router = express.Router();
const config = require('../config');
const { categorias, produtos, adicionais, clientes, pedidos, bairros, configuracoes } = require('../database/db');
const { enviarMensagem, getStatus } = require('../bot/whatsapp');
const { imprimirPedido } = require('../printer/thermal');

// ─── HELPERS ──────────────────────────────────────

/**
 * Parse itens JSON de um pedido (evita repetição)
 */
function parseItensPedido(pedido) {
  if (pedido && typeof pedido.itens === 'string') {
    pedido.itens = JSON.parse(pedido.itens);
  }
  return pedido;
}

function parseItensPedidos(lista) {
  for (let i = 0; i < lista.length; i++) {
    if (typeof lista[i].itens === 'string') {
      lista[i].itens = JSON.parse(lista[i].itens);
    }
  }
  return lista;
}

/**
 * Wrapper para handlers async (captura erros automaticamente)
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// ─── MIDDLEWARE DE AUTENTICAÇÃO ─────────────────

function authMiddleware(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  if (token && String(token) === String(config.servidor.senhaAdmin)) {
    return next();
  }
  res.status(401).json({ error: 'Não autorizado' });
}

// Aplicar auth em todas as rotas
router.use(authMiddleware);

// ─── STATUS DO BOT ──────────────────────────────

router.get('/status', (req, res) => {
  const status = getStatus();
  const stats = pedidos.estatisticasHoje();
  res.json({
    ...status,
    loja: config.loja,
    estatisticas: stats,
  });
});

// ─── CATEGORIAS ─────────────────────────────────

router.get('/categorias', (req, res) => {
  res.json(categorias.listarTodas());
});

router.post('/categorias', (req, res) => {
  try {
    const result = categorias.criar(req.body);
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/categorias/:id', (req, res) => {
  try {
    categorias.atualizar(req.params.id, req.body);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/categorias/:id', (req, res) => {
  categorias.excluir(req.params.id);
  res.json({ success: true });
});

// ─── PRODUTOS ───────────────────────────────────

router.get('/produtos', (req, res) => {
  res.json(produtos.listarTodos());
});

router.post('/produtos', (req, res) => {
  try {
    const result = produtos.criar(req.body);
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/produtos/:id', (req, res) => {
  try {
    produtos.atualizar(req.params.id, req.body);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/produtos/:id/toggle', (req, res) => {
  produtos.toggleDisponivel(req.params.id);
  res.json({ success: true });
});

router.delete('/produtos/:id', (req, res) => {
  produtos.excluir(req.params.id);
  res.json({ success: true });
});

// ─── ADICIONAIS ─────────────────────────────────

router.get('/adicionais', (req, res) => {
  res.json(adicionais.listarTodos());
});

router.post('/adicionais', (req, res) => {
  try {
    const result = adicionais.criar(req.body);
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/adicionais/:id', (req, res) => {
  try {
    adicionais.atualizar(req.params.id, req.body);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/adicionais/:id', (req, res) => {
  adicionais.excluir(req.params.id);
  res.json({ success: true });
});

// ─── BAIRROS (TAXA DE ENTREGA POR BAIRRO) ───────

router.get('/bairros', (req, res) => {
  res.json(bairros.listarTodos());
});

router.post('/bairros', (req, res) => {
  try {
    if (!req.body || !req.body.nome) {
      return res.status(400).json({ error: 'Nome do bairro é obrigatório' });
    }
    const result = bairros.criar(req.body);
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/bairros/:id', (req, res) => {
  try {
    bairros.atualizar(req.params.id, req.body);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/bairros/:id', (req, res) => {
  bairros.excluir(req.params.id);
  res.json({ success: true });
});

// ─── PEDIDOS ────────────────────────────────────
// Lookup de filtros (evita switch/case)
const filtrosPedidos = {
  pendentes: () => pedidos.listarPendentes(),
  hoje: () => pedidos.listarHoje(),
};

router.get('/pedidos', (req, res) => {
  const { filtro } = req.query;
  const fn = filtrosPedidos[filtro] || (() => pedidos.listarTodos(100));
  res.json(parseItensPedidos(fn()));
});

router.get('/pedidos/:id', (req, res) => {
  const pedido = pedidos.buscarPorCodigo(req.params.id);
  if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });
  res.json(parseItensPedido(pedido));
});

// Mensagens de status pré-definidas
const mensagensStatus = {
  confirmado: (codigo) => `✅ *Pedido #${codigo} CONFIRMADO!*\n\n🍳 Estamos preparando seu pedido!\n⏰ Previsão: ${config.loja.tempoEstimadoMin}-${config.loja.tempoEstimadoMax} minutos`,
  em_preparo: (codigo) => `🍳 *Pedido #${codigo} em preparo!*\n\nSeu pedido está sendo preparado com carinho! 😊`,
  saiu_entrega: (codigo) => `🏍️ *Pedido #${codigo} SAIU PARA ENTREGA!*\n\n📍 Nosso entregador está a caminho!\n⏰ Previsão de chegada: 15-25 minutos\n\nAguarde em seu endereço! 😊`,
  entregue: (codigo) => `✅ *Pedido #${codigo} ENTREGUE!*\n\nObrigado pela preferência! 🙏😋\n\n⭐ Avalie nosso atendimento de 1 a 5!`,
  cancelado: (codigo) => `❌ *Pedido #${codigo} foi cancelado.*\n\nSe precisar de algo, estamos à disposição!\nDigite *0* para ver o menu.`,
};

router.put('/pedidos/:id/status', asyncHandler(async (req, res) => {
  const { status } = req.body;
  const pedido = pedidos.atualizarStatus(req.params.id, status);

  if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });

  // Notificar cliente via WhatsApp (não bloqueia resposta)
  const gerarMensagem = mensagensStatus[status];
  if (gerarMensagem) {
    enviarMensagem(pedido.telefone, gerarMensagem(pedido.codigo)).catch(e => {
      console.error('Erro ao enviar notificação:', e.message);
    });
  }

  res.json({ success: true, pedido });
}));

// Operador informa que o PIX foi recebido → confirma o pedido e avisa o cliente
router.post('/pedidos/:id/pix-recebido', asyncHandler(async (req, res) => {
  const pedido = pedidos.confirmarPix(req.params.id);
  if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });

  const msg = `✅ *PIX recebido!*\n\nSeu *Pedido #${pedido.codigo}* está CONFIRMADO! 🍳\n⏰ Previsão: ${config.loja.tempoEstimadoMin}-${config.loja.tempoEstimadoMax} minutos.\n\nObrigado pela preferência! 🙏`;
  enviarMensagem(pedido.telefone, msg).catch(e => {
    console.error('Erro ao notificar PIX recebido:', e.message);
  });

  // O pedido já foi impresso automaticamente ao ser criado; aqui só reimprime
  // se por algum motivo ainda não tiver sido impresso.
  if (!pedido.impresso) {
    imprimirPedido(pedido)
      .then(r => { if (r && r.success) pedidos.marcarImpresso(pedido.id); })
      .catch(e => console.error('Erro ao imprimir após PIX:', e.message));
  }

  res.json({ success: true, pedido });
}));

router.post('/pedidos/:id/imprimir', asyncHandler(async (req, res) => {
  const pedido = pedidos.buscarPorCodigo(req.params.id);
  if (!pedido) return res.status(404).json({ error: 'Pedido não encontrado' });
  const result = await imprimirPedido(pedido);
  pedidos.marcarImpresso(pedido.id);
  res.json(result);
}));

// ─── CLIENTES ───────────────────────────────────

router.get('/clientes', (req, res) => {
  res.json(clientes.listar());
});

// ─── ESTATÍSTICAS ───────────────────────────────

router.get('/estatisticas', (req, res) => {
  res.json(pedidos.estatisticasHoje());
});

// ─── CONFIGURAÇÕES ──────────────────────────────

router.get('/config', (req, res) => {
  res.json(config);
});

// Atualiza QUALQUER parte da configuração (deep-merge) e persiste cifrado.
// Aceita um patch parcial, ex.: { pix: { chave: "..." } } ou { servidor: {...} }.
router.put('/config', (req, res) => {
  try {
    const patch = req.body || {};
    // Bloqueia sobrescrever os métodos internos
    delete patch.salvar;
    delete patch.atualizar;
    config.atualizar(patch);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Compatibilidade: salvar só os dados da loja (também persiste cifrado)
router.put('/config/loja', (req, res) => {
  config.atualizar({ loja: req.body || {} });
  res.json({ success: true });
});

// ─── ENVIAR MENSAGEM MANUAL ─────────────────────

router.post('/enviar-mensagem', asyncHandler(async (req, res) => {
  const { telefone, mensagem } = req.body;
  if (!telefone || !mensagem) {
    return res.status(400).json({ error: 'Telefone e mensagem são obrigatórios' });
  }
  await enviarMensagem(telefone, mensagem);
  res.json({ success: true });
}));

// ─── TRATAMENTO GLOBAL DE ERROS ─────────────────

router.use((err, req, res, next) => {
  console.error('❌ Erro na API:', err.message);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

module.exports = router;
