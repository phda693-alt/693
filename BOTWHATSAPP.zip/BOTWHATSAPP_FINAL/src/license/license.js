/**
 * ============================================
 *  SISTEMA DE LICENCIAMENTO
 *  Módulo do Cliente (roda dentro do bot)
 * ============================================
 * 
 * FLUXO:
 * 1. O sistema gera um WHID (identificador único da máquina)
 * 2. O sistema gera uma CONTRA-CHAVE (baseada no WHID)
 * 3. O cliente informa WHID + CONTRA-CHAVE ao administrador
 * 4. O administrador gera uma LICENÇA com data de expiração
 * 5. O cliente insere a LICENÇA no painel para ativar o sistema
 * 6. O sistema valida a licença e libera o uso até a data de expiração
 */

const crypto = require('crypto');
const os = require('os');
const fs = require('fs');
const path = require('path');

// ─── CHAVE SECRETA (compartilhada entre gerador e validador) ───
// Esta chave é embutida no código e no gerador. Nunca expor ao cliente.
const SECRET_KEY = 'FFB@2024#S3cR3t!K3y$LiC3nS3';
const CIPHER_ALGO = 'aes-256-cbc';

// Caminho do arquivo de licença
const LICENSE_DIR = path.join(__dirname, '..', '..', 'data');
const LICENSE_FILE = path.join(LICENSE_DIR, 'license.dat');
const WHID_FILE = path.join(LICENSE_DIR, 'whid.dat');

// ─── GERAR WHID (Hardware ID único da máquina) ─────────────────

function gerarWHID() {
  // Se já existe um WHID salvo, usar ele (para consistência)
  if (fs.existsSync(WHID_FILE)) {
    try {
      const saved = fs.readFileSync(WHID_FILE, 'utf8').trim();
      if (saved.length > 0) return saved;
    } catch (e) { /* regenerar */ }
  }

  // Coletar informações únicas da máquina
  const cpus = os.cpus();
  const networkInterfaces = os.networkInterfaces();

  // Montar fingerprint da máquina
  const fingerprint = [
    os.hostname(),
    os.platform(),
    os.arch(),
    os.totalmem().toString(),
    cpus.length > 0 ? cpus[0].model : 'unknown',
    cpus.length.toString(),
  ];

  // Adicionar MACs de interfaces de rede (exceto loopback)
  for (const [name, interfaces] of Object.entries(networkInterfaces)) {
    if (interfaces) {
      for (const iface of interfaces) {
        if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
          fingerprint.push(iface.mac);
        }
      }
    }
  }

  // Gerar hash do fingerprint
  const hash = crypto.createHash('sha256')
    .update(fingerprint.join('|'))
    .update(SECRET_KEY)
    .digest('hex');

  // Formatar WHID: XXXX-XXXX-XXXX-XXXX (16 caracteres hex em uppercase)
  const whid = hash.substring(0, 16).toUpperCase()
    .replace(/(.{4})/g, '$1-')
    .slice(0, -1); // remover último traço

  // Garantir diretório existe
  if (!fs.existsSync(LICENSE_DIR)) {
    fs.mkdirSync(LICENSE_DIR, { recursive: true });
  }

  // Salvar WHID para consistência futura
  fs.writeFileSync(WHID_FILE, whid, 'utf8');

  return whid;
}

// ─── GERAR CONTRA-CHAVE (baseada no WHID) ──────────────────────

function gerarContraChave(whid) {
  // A contra-chave é um hash derivado do WHID + SECRET
  // Serve como prova de que o WHID é legítimo
  const hash = crypto.createHmac('sha256', SECRET_KEY)
    .update(whid)
    .update('CONTRA-CHAVE')
    .digest('hex');

  // Formatar: XXXXXXXX (8 caracteres hex em uppercase)
  return hash.substring(0, 8).toUpperCase();
}

// ─── DERIVAR CHAVE DE CRIPTOGRAFIA ─────────────────────────────

function derivarChave(whid) {
  return crypto.scryptSync(SECRET_KEY + whid, 'fastfood-bot-salt', 32);
}

// ─── VALIDAR LICENÇA ────────────────────────────────────────────

function validarLicenca(licenseKey) {
  try {
    const whid = gerarWHID();
    const key = derivarChave(whid);

    // A licença é: IV(hex):ENCRYPTED(hex)
    const parts = licenseKey.trim().split(':');
    if (parts.length !== 2) {
      return { valida: false, erro: 'Formato de licença inválido' };
    }

    const iv = Buffer.from(parts[0], 'hex');
    const encrypted = Buffer.from(parts[1], 'hex');

    const decipher = crypto.createDecipheriv(CIPHER_ALGO, key, iv);
    let decrypted = decipher.update(encrypted, null, 'utf8');
    decrypted += decipher.final('utf8');

    // O conteúdo decriptado é JSON: { whid, contraChave, expiraEm, criadoEm }
    const dados = JSON.parse(decrypted);

    // Verificar WHID
    if (dados.whid !== whid) {
      return { valida: false, erro: 'Licença não pertence a esta máquina (WHID diferente)' };
    }

    // Verificar contra-chave
    const contraChaveEsperada = gerarContraChave(whid);
    if (dados.contraChave !== contraChaveEsperada) {
      return { valida: false, erro: 'Contra-chave inválida' };
    }

    // Verificar expiração
    const agora = new Date();
    const expira = new Date(dados.expiraEm);
    if (agora > expira) {
      return {
        valida: false,
        erro: 'Licença expirada',
        expiraEm: dados.expiraEm,
        diasRestantes: 0,
      };
    }

    // Calcular dias restantes
    const diffMs = expira - agora;
    const diasRestantes = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    return {
      valida: true,
      whid: dados.whid,
      expiraEm: dados.expiraEm,
      criadoEm: dados.criadoEm,
      diasRestantes,
    };
  } catch (error) {
    return { valida: false, erro: 'Licença inválida ou corrompida: ' + error.message };
  }
}

// ─── SALVAR LICENÇA ─────────────────────────────────────────────

function salvarLicenca(licenseKey) {
  // Garantir diretório existe
  if (!fs.existsSync(LICENSE_DIR)) {
    fs.mkdirSync(LICENSE_DIR, { recursive: true });
  }

  // Validar antes de salvar
  const resultado = validarLicenca(licenseKey);
  if (!resultado.valida) {
    return resultado;
  }

  // Salvar
  fs.writeFileSync(LICENSE_FILE, licenseKey.trim(), 'utf8');
  return resultado;
}

// ─── CARREGAR E VERIFICAR LICENÇA SALVA ─────────────────────────

function verificarLicencaSalva() {
  if (!fs.existsSync(LICENSE_FILE)) {
    return { valida: false, erro: 'Nenhuma licença encontrada. Ative o sistema no painel admin.', semLicenca: true };
  }

  try {
    const licenseKey = fs.readFileSync(LICENSE_FILE, 'utf8').trim();
    if (!licenseKey) {
      return { valida: false, erro: 'Arquivo de licença vazio', semLicenca: true };
    }
    return validarLicenca(licenseKey);
  } catch (error) {
    return { valida: false, erro: 'Erro ao ler licença: ' + error.message };
  }
}

// ─── OBTER INFORMAÇÕES DA LICENÇA ───────────────────────────────

function obterInfoLicenca() {
  const whid = gerarWHID();
  const contraChave = gerarContraChave(whid);
  const licenca = verificarLicencaSalva();

  return {
    whid,
    contraChave,
    licenca,
  };
}

// ─── REMOVER LICENÇA ────────────────────────────────────────────

function removerLicenca() {
  if (fs.existsSync(LICENSE_FILE)) {
    fs.unlinkSync(LICENSE_FILE);
  }
}

module.exports = {
  gerarWHID,
  gerarContraChave,
  validarLicenca,
  salvarLicenca,
  verificarLicencaSalva,
  obterInfoLicenca,
  removerLicenca,
  SECRET_KEY,
  CIPHER_ALGO,
};
