/**
 * ============================================
 *  IMPRESSORA TÉRMICA - ESC/POS
 *  (Otimizado para performance)
 *  (Compatível com Windows e Linux)
 *  
 *  Suporta 3 modos de conexão no Windows:
 *  1. Compartilhamento de rede: //localhost/NomeDaImpressora
 *  2. Envio RAW direto: raw:USB001 (via child_process)
 *  3. Driver nativo: printer:NomeDaImpressora (requer compilação)
 * ============================================
 */

const ThermalPrinter = require('node-thermal-printer').printer;
const PrinterTypes = require('node-thermal-printer').types;
const config = require('../config');
const dayjs = require('dayjs');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

let printer = null;
let modoRaw = false;      // Se true, usa child_process para enviar dados RAW
let rawPorta = '';         // Porta USB para modo RAW (ex: 'USB001')

/**
 * Formata um valor monetário de forma segura (nunca quebra com undefined/null).
 */
function money(v) {
  return (Number(v) || 0).toFixed(2);
}

/**
 * Garante que cada item tenha subtotal (preco * quantidade) e campos numéricos.
 */
function normalizarItens(itens) {
  const lista = typeof itens === 'string' ? JSON.parse(itens) : (itens || []);
  return lista.map(i => {
    const preco = Number(i.preco) || 0;
    const quantidade = Number(i.quantidade) || 1;
    const subtotal = Number(i.subtotal);
    return {
      ...i,
      preco,
      quantidade,
      subtotal: Number.isFinite(subtotal) ? subtotal : preco * quantidade,
    };
  });
}

// Mapa de tipos pré-definido (evita recriação)
const TIPO_MAP = {
  epson: PrinterTypes.EPSON,
  star: PrinterTypes.STAR,
  tanca: PrinterTypes.TANCA,
  daruma: PrinterTypes.DARUMA,
  brother: PrinterTypes.BROTHER,
  custom: PrinterTypes.CUSTOM,
};

/**
 * Tenta carregar o driver nativo de impressora (opcional)
 */
function carregarDriverImpressora() {
  const drivers = ['@thiagoelg/node-printer', 'printer'];
  for (const driverName of drivers) {
    try {
      return require(driverName);
    } catch (e) {
      // continuar tentando
    }
  }
  return null;
}

/**
 * Inicializar impressora
 */
function inicializarImpressora() {
  if (!config.impressora.habilitada) {
    console.log('🖨️  Impressora desabilitada nas configurações.');
    return false;
  }

  try {
    let interfaceStr = config.impressora.interface;

    // ─── MODO RAW (Windows - envio direto pela porta USB) ───
    // Interface no formato: 'raw:USB001'
    if (interfaceStr.startsWith('raw:')) {
      rawPorta = interfaceStr.substring(4); // ex: 'USB001'
      modoRaw = true;

      // No modo RAW, criamos o printer com uma interface temporária
      // apenas para gerar os comandos ESC/POS (getBuffer)
      // A escrita real será feita via child_process
      const tempFile = path.join(os.tmpdir(), 'fastfood_printer_temp.bin');

      printer = new ThermalPrinter({
        type: TIPO_MAP[config.impressora.tipo] || PrinterTypes.EPSON,
        interface: tempFile,
        characterSet: 'PC860_PORTUGUESE',
        removeSpecialCharacters: false,
        lineCharacter: '-',
        width: config.impressora.largura,
      });

      console.log('🖨️  Impressora inicializada (modo RAW direto)!');
      console.log(`   Porta: ${rawPorta}`);
      console.log('   Sistema: Windows (child_process)');
      return true;
    }

    // ─── MODO COMPARTILHAMENTO (//localhost/NomeDaImpressora) ───
    const isSharePath = interfaceStr.startsWith('//');
    const isPrinterInterface = interfaceStr.startsWith('printer:');

    const printerOptions = {
      type: TIPO_MAP[config.impressora.tipo] || PrinterTypes.EPSON,
      interface: interfaceStr,
      characterSet: 'PC860_PORTUGUESE',
      removeSpecialCharacters: false,
      lineCharacter: '-',
      width: config.impressora.largura,
    };

    // ─── MODO DRIVER NATIVO (printer:NomeDaImpressora) ───
    if (isPrinterInterface) {
      const driver = carregarDriverImpressora();
      if (driver) {
        printerOptions.driver = driver;
        console.log('🖨️  Driver nativo de impressora carregado com sucesso.');
      } else {
        console.error('');
        console.error('⚠️  Driver nativo de impressora não encontrado!');
        console.error('   O módulo @thiagoelg/node-printer não está instalado.');
        console.error('');
        console.error('   SOLUÇÃO RECOMENDADA (sem instalação extra):');
        console.error('   1. Compartilhe a impressora no Windows:');
        console.error('      Painel de Controle > Dispositivos e Impressoras');
        console.error('      Clique direito na impressora > Propriedades > Compartilhamento');
        console.error('      Marque "Compartilhar esta impressora"');
        console.error('   2. No arquivo src/config.js, altere a interface para:');
        console.error('      \'//localhost/NOME_DO_COMPARTILHAMENTO\'');
        console.error('');
        console.error('   SOLUÇÃO ALTERNATIVA:');
        console.error('   No arquivo src/config.js, altere a interface para:');
        console.error('   \'raw:USB001\' (substitua USB001 pela porta da sua impressora)');
        console.error('');
        return false;
      }
    }

    printer = new ThermalPrinter(printerOptions);

    const modoDesc = isSharePath ? 'compartilhamento de rede' : isPrinterInterface ? 'driver nativo' : 'arquivo';
    console.log(`🖨️  Impressora inicializada com sucesso!`);
    console.log(`   Interface: ${interfaceStr}`);
    console.log(`   Modo: ${modoDesc}`);
    console.log(`   Sistema: ${os.platform()}`);
    return true;
  } catch (error) {
    console.error('❌ Erro ao inicializar impressora:', error.message);
    return false;
  }
}

/**
 * Enviar dados RAW diretamente para a porta da impressora no Windows
 * Usa: copy /b arquivo \\.\PORTA
 */
function enviarRawWindows(buffer) {
  const tempFile = path.join(os.tmpdir(), `fastfood_print_${Date.now()}.bin`);
  try {
    // Escrever buffer no arquivo temporário
    fs.writeFileSync(tempFile, buffer);

    // Enviar para a porta da impressora via copy /b
    // \\.\USB001 é o caminho direto para a porta USB no Windows
    const comando = `copy /b "${tempFile}" "\\\\.\\${rawPorta}"`;
    execSync(comando, {
      windowsHide: true,
      timeout: 10000,
      stdio: 'pipe',
    });

    return true;
  } catch (error) {
    console.error(`❌ Erro ao enviar dados RAW para ${rawPorta}:`, error.message);
    return false;
  } finally {
    // Limpar arquivo temporário
    try { fs.unlinkSync(tempFile); } catch (e) { /* silenciar */ }
  }
}

/**
 * Imprimir pedido
 */
async function imprimirPedido(pedido) {
  if (!config.impressora.habilitada || !printer) {
    console.log('\n' + gerarTextoPedido(pedido) + '\n');
    return { success: true, method: 'console' };
  }

  try {
    // ─── Verificar conexão (apenas para modos não-RAW) ───
    if (!modoRaw) {
      let isConnected = false;
      try {
        isConnected = await printer.isPrinterConnected();
      } catch (connError) {
        // No Windows com compartilhamento, isPrinterConnected pode falhar
        // porque fs.existsSync não funciona bem com caminhos UNC
        // Vamos tentar imprimir mesmo assim
        if (os.platform() === 'win32') {
          console.log('⚠️  Verificação de conexão falhou (normal no Windows com compartilhamento).');
          console.log('   Tentando imprimir mesmo assim...');
          isConnected = true; // Forçar tentativa
        } else {
          console.error('⚠️  Erro ao verificar conexão:', connError.message || connError);
        }
      }

      // No Windows com caminho de compartilhamento, fs.existsSync pode retornar false
      // mesmo quando a impressora está disponível. Forçamos a tentativa.
      if (!isConnected && os.platform() === 'win32' && config.impressora.interface.startsWith('//')) {
        console.log('⚠️  isPrinterConnected retornou false para compartilhamento Windows.');
        console.log('   Isso é esperado. Tentando imprimir mesmo assim...');
        isConnected = true;
      }

      if (!isConnected) {
        console.error('❌ Impressora não conectada');
        console.error('   Verifique se a impressora está ligada e conectada.');
        console.error(`   Interface configurada: ${config.impressora.interface}`);
        return { success: false, error: 'Impressora não conectada' };
      }
    }

    // ─── Montar conteúdo da impressão ───
    const itens = normalizarItens(pedido.itens);
    const somaItens = itens.reduce((a, i) => a + i.subtotal, 0);
    const subtotalPedido = pedido.subtotal != null ? pedido.subtotal : somaItens;
    const largura = config.impressora.largura;
    const linha = '='.repeat(largura);
    const linhaThin = '-'.repeat(largura);
    const nomeLoja = config.loja.nome.replace(/[^\w\s\-\.]/g, '').trim();

    // ─── CABEÇALHO ───
    printer.alignCenter();
    printer.bold(true);
    printer.setTextSize(1, 1);
    printer.println(nomeLoja);
    printer.bold(false);
    printer.setTextNormal();
    printer.println(config.loja.endereco);
    printer.println(`Tel: ${config.loja.telefone}`);
    printer.println(linha);

    // ─── NÚMERO DO PEDIDO ───
    printer.alignCenter();
    printer.bold(true);
    printer.setTextSize(1, 1);
    printer.println(`PEDIDO #${pedido.codigo}`);
    printer.setTextNormal();
    printer.bold(false);
    printer.println(dayjs(pedido.hora_pedido).format('DD/MM/YYYY HH:mm'));
    printer.println(linha);

    // ─── DADOS DO CLIENTE ───
    printer.alignLeft();
    printer.bold(true);
    printer.println('CLIENTE:');
    printer.bold(false);
    if (pedido.nome_cliente) printer.println(`Nome: ${pedido.nome_cliente}`);
    printer.println(`Tel: ${formatarTelefone(pedido.telefone)}`);
    printer.println(`End: ${pedido.endereco}`);
    if (pedido.complemento) printer.println(`Comp: ${pedido.complemento}`);
    if (pedido.referencia) printer.println(`Ref: ${pedido.referencia}`);
    printer.println(linha);

    // ─── ITENS ───
    printer.bold(true);
    printer.println('ITENS DO PEDIDO:');
    printer.bold(false);
    printer.println(linhaThin);

    for (const item of itens) {
      printer.println(item.nome);
      printer.leftRight(`${item.quantidade}x R$${money(item.preco)}`, `R$${money(item.subtotal)}`);
    }

    printer.println(linhaThin);

    // ─── TOTAIS ───
    printer.leftRight('Subtotal:', `R$${money(subtotalPedido)}`);
    printer.leftRight('Taxa entrega:', `R$${money(pedido.taxa_entrega)}`);
    printer.bold(true);
    printer.setTextSize(0, 1);
    printer.leftRight('TOTAL:', `R$${money(pedido.total)}`);
    printer.setTextNormal();
    printer.bold(false);

    printer.println(linhaThin);

    // ─── PAGAMENTO ───
    printer.leftRight('Pagamento:', pedido.forma_pagamento);
    if (pedido.troco_para > 0) {
      printer.leftRight('Troco para:', `R$${money(pedido.troco_para)}`);
      printer.leftRight('Troco:', `R$${money(pedido.troco_para - pedido.total)}`);
    }

    // ─── OBSERVAÇÃO ───
    if (pedido.observacao) {
      printer.println(linhaThin);
      printer.bold(true);
      printer.println('OBSERVACAO:');
      printer.bold(false);
      printer.println(pedido.observacao);
    }

    printer.println(linha);
    printer.alignCenter();
    printer.println('Obrigado pela preferencia!');
    printer.println(nomeLoja);

    printer.cut();

    try { printer.openCashDrawer(); } catch (e) { /* silenciar */ }

    // ─── ENVIAR PARA IMPRESSORA ───
    if (modoRaw) {
      // Modo RAW: pegar o buffer e enviar via child_process
      const buffer = printer.getBuffer();
      printer.clear();

      const enviado = enviarRawWindows(buffer);
      if (enviado) {
        console.log(`🖨️  Pedido #${pedido.codigo} impresso com sucesso! (modo RAW)`);
        return { success: true, method: 'raw' };
      } else {
        return { success: false, error: `Falha ao enviar dados para porta ${rawPorta}` };
      }
    } else {
      // Modo normal: usar execute() da biblioteca
      await printer.execute();
      printer.clear();
      console.log(`🖨️  Pedido #${pedido.codigo} impresso com sucesso!`);
      return { success: true, method: 'thermal' };
    }
  } catch (error) {
    console.error('❌ Erro ao imprimir:', error.message);
    try { printer.clear(); } catch (e) { /* silenciar */ }
    return { success: false, error: error.message };
  }
}

/**
 * Gerar texto do pedido (para console/fallback)
 */
function gerarTextoPedido(pedido) {
  const itens = normalizarItens(pedido.itens);
  const somaItens = itens.reduce((a, i) => a + i.subtotal, 0);
  const subtotalPedido = pedido.subtotal != null ? pedido.subtotal : somaItens;
  const largura = 48;
  const linha = '='.repeat(largura);
  const linhaThin = '-'.repeat(largura);
  const nomeLoja = config.loja.nome.replace(/[^\w\s\-\.]/g, '').trim();

  const partes = [
    linha,
    centralizarTexto(nomeLoja, largura),
    centralizarTexto(config.loja.endereco, largura),
    linha,
    centralizarTexto(`PEDIDO #${pedido.codigo}`, largura),
    centralizarTexto(dayjs(pedido.hora_pedido).format('DD/MM/YYYY HH:mm'), largura),
    linha,
    'CLIENTE:',
  ];

  if (pedido.nome_cliente) partes.push(`Nome: ${pedido.nome_cliente}`);
  partes.push(`Tel: ${formatarTelefone(pedido.telefone)}`);
  partes.push(`End: ${pedido.endereco}`);
  if (pedido.complemento) partes.push(`Comp: ${pedido.complemento}`);
  if (pedido.referencia) partes.push(`Ref: ${pedido.referencia}`);
  partes.push(linha, 'ITENS DO PEDIDO:', linhaThin);

  for (const item of itens) {
    partes.push(item.nome);
    partes.push(`  ${item.quantidade}x R$${money(item.preco)}    R$${money(item.subtotal)}`);
  }

  partes.push(linhaThin);
  partes.push(`Subtotal:       R$${money(subtotalPedido)}`);
  partes.push(`Taxa entrega:   R$${money(pedido.taxa_entrega)}`);
  partes.push(`TOTAL:          R$${money(pedido.total)}`);
  partes.push(linhaThin);
  partes.push(`Pagamento: ${pedido.forma_pagamento}`);

  if (pedido.troco_para > 0) {
    partes.push(`Troco para: R$${money(pedido.troco_para)}`);
    partes.push(`Troco: R$${money(pedido.troco_para - pedido.total)}`);
  }
  if (pedido.observacao) {
    partes.push(linhaThin, `OBS: ${pedido.observacao}`);
  }
  partes.push(linha);

  return partes.join('\n');
}

function centralizarTexto(texto, largura) {
  const padding = Math.max(0, (largura - texto.length) >> 1);
  return ' '.repeat(padding) + texto;
}

function formatarTelefone(tel) {
  if (tel.length === 13) {
    return `(${tel.substring(2, 4)}) ${tel.substring(4, 5)} ${tel.substring(5, 9)}-${tel.substring(9)}`;
  }
  if (tel.length === 12) {
    return `(${tel.substring(2, 4)}) ${tel.substring(4, 8)}-${tel.substring(8)}`;
  }
  return tel;
}

module.exports = {
  inicializarImpressora,
  imprimirPedido,
  gerarTextoPedido,
};
