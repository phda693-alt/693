/**
 * ============================================
 *  🍔 FAST FOOD WHATSAPP BOT
 *  Servidor Principal (com Licenciamento)
 *  (Otimizado para performance)
 * ============================================
 */

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const config = require('./src/config');
const { iniciarWhatsApp } = require('./src/bot/whatsapp');
const { botEvents } = require('./src/bot/handlers');
const { inicializarImpressora, imprimirPedido } = require('./src/printer/thermal');
const { pedidos } = require('./src/database/db');
const apiRoutes = require('./src/routes/api');
const licenseModule = require('./src/license/license');

// ─── EXPRESS + SOCKET.IO ────────────────────────

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
  pingInterval: 25000,
  pingTimeout: 20000,
});

// Middleware
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'src', 'public'), {
  maxAge: '1h',
  etag: true,
}));

// ─── ESTADO DA LICENÇA ──────────────────────────

let licencaAtiva = false;
let licencaInfo = null;
let whatsappIniciado = false;

function verificarLicenca() {
  const info = licenseModule.obterInfoLicenca();
  licencaInfo = info;

  if (info.licenca.valida) {
    licencaAtiva = true;
    console.log(`🔑 Licença válida! Expira em: ${new Date(info.licenca.expiraEm).toLocaleDateString('pt-BR')} (${info.licenca.diasRestantes} dias restantes)`);

    if (info.licenca.diasRestantes <= 5) {
      console.log(`⚠️  ATENÇÃO: Sua licença expira em ${info.licenca.diasRestantes} dia(s)! Renove com o administrador.`);
    }
  } else {
    licencaAtiva = false;
    console.log(`🔒 ${info.licenca.erro}`);
  }

  return licencaAtiva;
}

// Verificar licença periodicamente (a cada 1 minuto)
const licencaCheckInterval = setInterval(() => {
  const estaAtiva = verificarLicenca();

  if (!estaAtiva && whatsappIniciado) {
    console.log('\n🔒 ═══════════════════════════════════════');
    console.log('🔒  LICENÇA EXPIRADA! Bot desativado.');
    console.log('🔒  Contate o administrador para renovar.');
    console.log('🔒 ═══════════════════════════════════════\n');
    io.emit('licenca_expirada', { mensagem: 'Licença expirada. Contate o administrador.' });
  }
}, 60 * 1000);

// ─── ROTAS DE LICENÇA (sem autenticação) ────────

app.get('/api/licenca/info', (req, res) => {
  const info = licenseModule.obterInfoLicenca();
  res.json({
    whid: info.whid,
    contraChave: info.contraChave,
    licenca: {
      valida: info.licenca.valida,
      erro: info.licenca.erro || null,
      expiraEm: info.licenca.expiraEm || null,
      diasRestantes: info.licenca.diasRestantes || 0,
      semLicenca: info.licenca.semLicenca || false,
    },
  });
});

app.post('/api/licenca/ativar', (req, res) => {
  const { licenseKey } = req.body;

  if (!licenseKey || licenseKey.trim().length === 0) {
    return res.status(400).json({ error: 'Chave de licença não informada' });
  }

  const resultado = licenseModule.salvarLicenca(licenseKey);

  if (resultado.valida) {
    licencaAtiva = true;
    licencaInfo = licenseModule.obterInfoLicenca();

    console.log('\n🔑 ═══════════════════════════════════════');
    console.log('🔑  LICENÇA ATIVADA COM SUCESSO!');
    console.log(`🔑  Expira em: ${new Date(resultado.expiraEm).toLocaleDateString('pt-BR')}`);
    console.log(`🔑  Dias restantes: ${resultado.diasRestantes}`);
    console.log('🔑 ═══════════════════════════════════════\n');

    if (!whatsappIniciado) {
      iniciarWhatsAppBot();
    }

    io.emit('licenca_ativada', {
      expiraEm: resultado.expiraEm,
      diasRestantes: resultado.diasRestantes,
    });

    res.json({
      success: true,
      expiraEm: resultado.expiraEm,
      diasRestantes: resultado.diasRestantes,
    });
  } else {
    res.status(400).json({ error: resultado.erro });
  }
});

// ─── MIDDLEWARE DE BLOQUEIO POR LICENÇA ─────────

function licenseMiddleware(req, res, next) {
  if (req.path.startsWith('/licenca') || req.path === '/status') {
    return next();
  }

  if (!licencaAtiva) {
    return res.status(403).json({
      error: 'Sistema bloqueado. Licença inválida ou expirada.',
      licencaExpirada: true,
    });
  }
  next();
}

// Aplicar middleware de licença nas rotas API
app.use('/api', licenseMiddleware, apiRoutes);

// Rota principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'public', 'index.html'));
});

// ─── SOCKET.IO EVENTS ──────────────────────────

io.on('connection', (socket) => {
  console.log('🌐 Painel admin conectado');

  const info = licenseModule.obterInfoLicenca();
  socket.emit('licenca_status', {
    valida: info.licenca.valida,
    whid: info.whid,
    contraChave: info.contraChave,
    expiraEm: info.licenca.expiraEm || null,
    diasRestantes: info.licenca.diasRestantes || 0,
    semLicenca: info.licenca.semLicenca || false,
    erro: info.licenca.erro || null,
  });

  socket.on('disconnect', () => {
    console.log('🌐 Painel admin desconectado');
  });
});

// ─── EVENTOS DO BOT ─────────────────────────────

botEvents.on('novo_pedido', async (pedido) => {
  if (!licencaAtiva) {
    console.log('🔒 Pedido ignorado - licença inativa');
    return;
  }

  console.log(`\n🔔 ═══════════════════════════════════`);
  console.log(`🔔  NOVO PEDIDO: #${pedido.codigo}`);
  console.log(`🔔  Cliente: ${pedido.nome_cliente}`);
  console.log(`🔔  Total: R$ ${pedido.total.toFixed(2)}`);
  console.log(`🔔 ═══════════════════════════════════\n`);

  // Emitir para o painel admin
  io.emit('novo_pedido', {
    ...pedido,
    itens: typeof pedido.itens === 'string' ? JSON.parse(pedido.itens) : pedido.itens,
  });

  // Sinal sonoro no terminal (beep simples, sem spawn de processos)
  tocarSinalSonoro();

  // Pedidos via PIX só vão pra cozinha (impressão) depois do PIX confirmado no painel
  if (pedido.pix_status === 'aguardando') {
    console.log(`💠 Pedido #${pedido.codigo} aguardando PIX — será impresso quando o pagamento for confirmado.`);
    return;
  }

  // Imprimir automaticamente (não bloqueia)
  imprimirPedido(pedido)
    .then(resultado => {
      if (resultado.success) {
        pedidos.marcarImpresso(pedido.id);
        console.log(`🖨️ Pedido #${pedido.codigo} impresso automaticamente!`);
      }
    })
    .catch(err => {
      console.error(`❌ Erro ao imprimir pedido #${pedido.codigo}:`, err.message);
    });
});

// ─── SINAL SONORO (otimizado - sem spawn de processos externos) ──

function tocarSinalSonoro() {
  process.stdout.write('\x07');
  let count = 0;
  const interval = setInterval(() => {
    process.stdout.write('\x07');
    if (++count >= 3) clearInterval(interval);
  }, 500);
}

// ─── INICIAR WHATSAPP ───────────────────────────

async function iniciarWhatsAppBot() {
  if (whatsappIniciado) return;
  try {
    console.log('📱 Iniciando conexão com WhatsApp...');
    await iniciarWhatsApp(io);
    whatsappIniciado = true;
  } catch (err) {
    console.error('❌ Erro ao iniciar WhatsApp:', err.message);
  }
}

// ─── INICIALIZAÇÃO ──────────────────────────────

async function iniciar() {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║    🍔 FAST FOOD WHATSAPP BOT v1.1.0     ║');
  console.log('║    Sistema de Pedidos Automatizado       ║');
  console.log('║    (Performance Otimizada)               ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log('║                                          ║');
  console.log(`║  📡 Servidor: http://localhost:${config.servidor.porta}       ║`);
  console.log('║                                          ║');
  console.log('╚══════════════════════════════════════════╝');
  console.log('');

  // Verificar licença
  const info = licenseModule.obterInfoLicenca();
  console.log(`🆔 WHID: ${info.whid}`);
  console.log(`🔐 Contra-Chave: ${info.contraChave}`);
  console.log('');

  const temLicenca = verificarLicenca();

  // Inicializar impressora
  inicializarImpressora();

  // Iniciar servidor web
  server.listen(config.servidor.porta, '0.0.0.0', () => {
    console.log(`🌐 Painel admin: http://localhost:${config.servidor.porta}`);
    console.log('');
  });

  // Só iniciar WhatsApp se a licença estiver ativa
  if (temLicenca) {
    await iniciarWhatsAppBot();
  } else {
    console.log('');
    console.log('╔══════════════════════════════════════════════════════╗');
    console.log('║  🔒 SISTEMA BLOQUEADO - LICENÇA NECESSÁRIA         ║');
    console.log('╠══════════════════════════════════════════════════════╣');
    console.log('║                                                      ║');
    console.log('║  Para ativar o sistema:                              ║');
    console.log('║                                                      ║');
    console.log('║  1. Acesse o painel admin no navegador               ║');
    console.log('║  2. Vá em "Licença"                                  ║');
    console.log('║  3. Informe o WHID e a Contra-Chave ao administrador ║');
    console.log('║  4. Cole a licença recebida e clique em "Ativar"     ║');
    console.log('║                                                      ║');
    console.log(`║  WHID: ${info.whid}                        ║`);
    console.log(`║  Contra-Chave: ${info.contraChave}                              ║`);
    console.log('║                                                      ║');
    console.log('╚══════════════════════════════════════════════════════╝');
    console.log('');
  }

  // Limpar sessões expiradas periodicamente
  const sessionManager = require('./src/bot/session');
  setInterval(() => sessionManager.limparExpiradas(), 5 * 60 * 1000);
}

// ─── TRATAMENTO DE ERROS ────────────────────────

process.on('uncaughtException', (err) => {
  console.error('❌ Erro não capturado:', err);
});

process.on('unhandledRejection', (err) => {
  console.error('❌ Promise rejeitada:', err);
});

function gracefulShutdown(signal) {
  console.log(`\n👋 Recebido ${signal}. Encerrando bot...`);
  clearInterval(licencaCheckInterval);
  server.close(() => {
    console.log('✅ Servidor encerrado.');
    process.exit(0);
  });
  // Forçar encerramento após 5 segundos
  setTimeout(() => process.exit(1), 5000);
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// ─── INICIAR ────────────────────────────────────

iniciar().catch(console.error);
