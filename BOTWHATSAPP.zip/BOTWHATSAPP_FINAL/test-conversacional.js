/**
 * ============================================================
 *  TESTE DO FLUXO 100% CONVERSACIONAL
 * ============================================================
 * Valida se o bot agora ignora o menu estruturado e
 * processa tudo via IA Lara.
 * ============================================================
 */

const { processarMensagem } = require('./src/bot/handlers');
const sessionManager = require('./src/bot/session');

async function testarFluxo() {
  const telefone = '5511999999999';
  sessionManager.reset(telefone);
  sessionManager.limparHistoricoIA(telefone);

  console.log('--- INICIANDO TESTE CONVERSACIONAL ---\n');

  // Teste 1: Número que antes era menu
  console.log('Entrada: "1" (Antigo ver cardápio)');
  const r1 = await processarMensagem(telefone, '1', 'João');
  console.log('Lara:', r1, '\n');

  // Teste 2: Pedido direto
  console.log('Entrada: "Quero um X-Bacon e uma Coca"');
  const r2 = await processarMensagem(telefone, 'Quero um X-Bacon e uma Coca', 'João');
  console.log('Lara:', r2, '\n');

  // Teste 3: Pergunta sobre entrega
  console.log('Entrada: "Quanto é a entrega para o centro?"');
  const r3 = await processarMensagem(telefone, 'Quanto é a entrega para o centro?', 'João');
  console.log('Lara:', r3, '\n');

  console.log('--- TESTE CONCLUÍDO ---');
}

testarFluxo().catch(console.error);
