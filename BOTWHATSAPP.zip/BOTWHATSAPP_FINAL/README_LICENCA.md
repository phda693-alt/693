# 🍔 Fast Food WhatsApp Bot v1.1.0 (com Licenciamento)

## Sistema Profissional de Atendimento e Pedidos para WhatsApp

Esta é uma versão atualizada do sistema, agora incluindo um **módulo completo de licenciamento**, permitindo que você alugue e gerencie o acesso ao software para seus clientes de forma segura e profissional.

---

### ✨ Novidades da Versão 1.1.0

Além de todas as funcionalidades da versão anterior, esta versão adiciona:

| Funcionalidade | Descrição |
| :--- | :--- |
| **Sistema de Licenciamento** | O bot agora requer uma licença válida para funcionar, que expira em uma data definida por você. |
| **Identificação Única (WHID)** | Cada instalação do bot gera um ID de Máquina (WHID) e uma Contra-Chave únicos. |
| **Gerador de Licenças** | Uma ferramenta exclusiva para você, administrador, gerar chaves de licença para seus clientes com base no WHID e na data de expiração. |
| **Painel de Ativação** | Seu cliente tem uma nova tela no painel administrativo para ver o WHID/Contra-Chave e ativar a licença que você fornecer. |
| **Bloqueio Automático** | Se a licença expirar, o bot para de responder e o painel é bloqueado, garantindo a renovação do aluguel. |

---

### 🚀 Como Funciona o Licenciamento

O fluxo é simples e seguro, dividido entre você (Administrador) e seu cliente.

#### Lado do Cliente (Seu Inquilino)

1.  **Instalação e Execução**: O cliente instala e executa o bot. Na primeira vez, o sistema estará **bloqueado**.
2.  **Obter Credenciais**: O cliente acessa o painel administrativo (que funcionará apenas para a tela de licença), vai até a nova aba **"Licença"** e vê duas informações: o **WHID** e a **Contra-Chave**.
3.  **Solicitar Licença**: O cliente copia e envia essas duas informações para você.
4.  **Ativar**: Após receber a chave de licença de você, ele a cola no campo apropriado e clica em "Ativar". O sistema é liberado instantaneamente e funcionará até a data de expiração definida.

#### Lado do Administrador (Você)

1.  **Receber Credenciais**: Você recebe o WHID e a Contra-Chave do seu cliente.
2.  **Gerar Licença**: Você utiliza o **Gerador de Licenças** (uma ferramenta separada inclusa no pacote) para criar uma chave. Você informa o WHID, a Contra-Chave e define a data de validade (ex: 30 dias).
3.  **Enviar Chave**: O gerador cria uma chave de licença única. Você copia e envia essa chave para seu cliente.

---

### 🔑 Usando o Gerador de Licenças

Dentro do projeto, há uma nova pasta chamada `gerador-licenca`. Você tem duas maneiras de usar esta ferramenta:

1.  **Interface Web (Recomendado)**:
    *   Navegue até a pasta `gerador-licenca` no seu terminal.
    *   Execute o comando: `node servidor.js`
    *   Abra seu navegador e acesse: **http://localhost:3001**
    *   Uma interface gráfica amigável permitirá que você cole o WHID, a Contra-Chave e escolha a data de expiração para gerar a licença facilmente.

2.  **Linha de Comando**:
    *   Navegue até a pasta `gerador-licenca`.
    *   Execute o comando: `node gerar-licenca.js`
    *   O script fará as perguntas (WHID, Contra-Chave, Data) diretamente no terminal.

---

### 📦 O que você recebe nesta atualização

*   **Código-Fonte Atualizado**: Todos os arquivos do bot com o sistema de licenciamento já integrado.
*   **Gerador de Licenças**: A pasta `gerador-licenca` com a ferramenta para você criar as chaves para seus clientes.
*   **Documentação Atualizada**: Este arquivo `README.md` explicando todo o novo processo.

Obrigado por utilizar o Fast Food WhatsApp Bot!
